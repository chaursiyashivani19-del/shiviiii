import { Order, PaymentDetails } from '../types';

export interface PaymentProvider {
  name: string;
  processPayment(params: {
    order: Order;
    onSuccess: (paymentDetails: PaymentDetails) => void;
    onError: (error: string) => void;
  }): Promise<void>;
}

export class DemoPaymentProvider implements PaymentProvider {
  name = 'Demo Instant Checkout (Razorpay Simulated)';

  async processPayment(params: {
    order: Order;
    onSuccess: (paymentDetails: PaymentDetails) => void;
    onError: (error: string) => void;
  }): Promise<void> {
    const { order, onSuccess } = params;

    // Simulate modal/gateway round-trip latency
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simulated successful Razorpay payload
    const mockPaymentDetails: PaymentDetails = {
      id: `pay_demo_${Date.now()}`,
      order_id: order.id,
      provider: 'demo_mock',
      provider_order_id: `order_rzp_${Math.random().toString(36).substring(2, 9)}`,
      provider_payment_id: `pay_${Math.random().toString(36).substring(2, 12)}`,
      amount_inr: order.total_inr,
      currency: 'INR',
      status: 'captured',
      verified_at: new Date().toISOString(),
    };

    onSuccess(mockPaymentDetails);
  }
}

export class RazorpayPaymentProvider implements PaymentProvider {
  name = 'Razorpay (India Gateway)';

  async processPayment(params: {
    order: Order;
    onSuccess: (paymentDetails: PaymentDetails) => void;
    onError: (error: string) => void;
  }): Promise<void> {
    const { order, onSuccess, onError } = params;
    const razorpayKeyId = import.meta.env.VITE_RAZORPAY_KEY_ID;

    if (!razorpayKeyId) {
      // Graceful fallback to demo mode when keys are not configured in environment
      console.warn('VITE_RAZORPAY_KEY_ID is missing. Falling back to simulated verification.');
      const demoProvider = new DemoPaymentProvider();
      return demoProvider.processPayment(params);
    }

    if (typeof window === 'undefined' || !(window as unknown as { Razorpay: unknown }).Razorpay) {
      onError('Razorpay SDK failed to load. Please check your network connection.');
      return;
    }

    try {
      const options = {
        key: razorpayKeyId,
        amount: Math.round(order.total_inr * 100), // paise
        currency: 'INR',
        name: 'ÉLÉVÉ ATELIER',
        description: `Order #${order.order_number}`,
        image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=200&q=80',
        order_id: (order as unknown as { razorpay_order_id?: string }).razorpay_order_id || '',
        prefill: {
          name: order.shipping_address.full_name,
          email: order.guest_email || '',
          contact: order.shipping_address.phone,
        },
        theme: {
          color: '#1A1A1A',
        },
        handler: (response: { razorpay_payment_id: string; razorpay_order_id: string; razorpay_signature: string }) => {
          onSuccess({
            id: response.razorpay_payment_id,
            order_id: order.id,
            provider: 'razorpay',
            provider_order_id: response.razorpay_order_id,
            provider_payment_id: response.razorpay_payment_id,
            amount_inr: order.total_inr,
            currency: 'INR',
            status: 'captured',
            verified_at: new Date().toISOString(),
          });
        },
        modal: {
          ondismiss: () => {
            onError('Payment was cancelled by the customer.');
          },
        },
      };

      const razorpayInstance = new (window as unknown as { Razorpay: new (opts: typeof options) => { open: () => void } }).Razorpay(options);
      razorpayInstance.open();
    } catch (err) {
      onError((err as Error).message || 'Razorpay checkout initialization failed.');
    }
  }
}
