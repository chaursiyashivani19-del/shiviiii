import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingBag } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export const CartDrawer: React.FC = () => {
  const { 
    items, 
    itemCount, 
    subtotal, 
    total, 
    discountAmount, 
    isCartDrawerOpen, 
    setIsCartDrawerOpen, 
    updateQuantity, 
    removeFromCart 
  } = useCart();
  const navigate = useNavigate();

  if (!isCartDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm transition-opacity animate-fade-in"
        onClick={() => setIsCartDrawerOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-ivory shadow-2xl flex flex-col justify-between border-l border-borderSoft">
          
          {/* Header */}
          <div className="px-6 py-5 border-b border-borderSoft flex items-center justify-between bg-white/70">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-charcoal" />
              <h2 className="font-editorial text-xl tracking-wider text-charcoal">
                Shopping Bag ({itemCount})
              </h2>
            </div>
            <button 
              onClick={() => setIsCartDrawerOpen(false)}
              className="p-1.5 text-mutedGrey hover:text-charcoal transition-colors rounded-full hover:bg-beige"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <span className="text-5xl">🛍️</span>
                <p className="font-editorial text-2xl text-charcoal">Your bag is empty</p>
                <p className="text-xs text-mutedGrey max-w-xs">
                  Explore our curated seasonal collection of corsets, dresses, and co-ords.
                </p>
                <Link
                  to="/shop"
                  onClick={() => setIsCartDrawerOpen(false)}
                  className="mt-2 inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-medium px-6 py-3 bg-charcoal text-white hover:bg-cherry-600 transition-colors rounded-full"
                >
                  <span>Explore The Atelier</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            ) : (
              items.map((item) => {
                const currentPrice = item.product.sale_price_inr ?? item.product.price_inr;
                const primaryImg = item.product.images.find(img => img.is_primary) || item.product.images[0];

                return (
                  <div 
                    key={item.variant_id} 
                    className="flex gap-4 p-3 bg-white/80 rounded-2xl border border-borderSoft/60 shadow-sm transition-all"
                  >
                    <img 
                      src={primaryImg.image_url} 
                      alt={item.product.title}
                      className="w-20 h-24 object-cover rounded-xl bg-beige/40 flex-shrink-0"
                    />
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <Link 
                            to={`/product/${item.product.slug}`}
                            onClick={() => setIsCartDrawerOpen(false)}
                            className="text-xs font-semibold uppercase tracking-wider text-charcoal hover:text-cherry-600 line-clamp-1"
                          >
                            {item.product.title}
                          </Link>
                          <button 
                            onClick={() => removeFromCart(item.variant_id)}
                            className="text-mutedGrey hover:text-cherry-600 transition-colors p-1"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-[11px] text-mutedGrey mt-1 flex items-center gap-2">
                          <span>Size: <strong>{item.variant.size}</strong></span>
                          <span>•</span>
                          <span>Color: <strong>{item.variant.color}</strong></span>
                        </div>
                        <p className="text-xs font-bold text-charcoal mt-1">
                          ₹{currentPrice.toLocaleString('en-IN')}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-borderSoft/40">
                        <div className="flex items-center border border-borderSoft rounded-lg bg-ivory">
                          <button 
                            onClick={() => updateQuantity(item.variant_id, item.quantity - 1)}
                            className="p-1 text-charcoal hover:bg-beige transition-colors rounded-l-lg"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-3 text-xs font-semibold text-charcoal">
                            {item.quantity}
                          </span>
                          <button 
                            onClick={() => updateQuantity(item.variant_id, item.quantity + 1)}
                            disabled={item.quantity >= item.variant.available_stock}
                            className="p-1 text-charcoal hover:bg-beige transition-colors rounded-r-lg disabled:opacity-40"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="text-xs text-mutedGrey">
                          {item.variant.available_stock} available
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Subtotal & Checkout */}
          {items.length > 0 && (
            <div className="px-6 py-5 border-t border-borderSoft bg-white/90 space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-mutedGrey">
                  <span>Subtotal</span>
                  <span className="font-medium text-charcoal">₹{subtotal.toLocaleString('en-IN')}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-cherry-600 font-medium">
                    <span>Discount</span>
                    <span>-₹{discountAmount.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between text-mutedGrey">
                  <span>Shipping</span>
                  <span>{subtotal > 3000 ? 'Complimentary' : '₹250'}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-charcoal pt-2 border-t border-borderSoft">
                  <span>Estimated Total</span>
                  <span>₹{total.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <Link
                  to="/cart"
                  onClick={() => setIsCartDrawerOpen(false)}
                  className="w-full py-3 px-4 border border-charcoal text-center text-xs uppercase tracking-luxury font-semibold text-charcoal hover:bg-beige transition-colors rounded-xl"
                >
                  View Bag
                </Link>
                <button
                  onClick={() => {
                    setIsCartDrawerOpen(false);
                    navigate('/checkout');
                  }}
                  className="w-full py-3 px-4 bg-charcoal text-center text-xs uppercase tracking-luxury font-semibold text-white hover:bg-cherry-600 transition-colors rounded-xl flex items-center justify-center gap-1.5 shadow-md"
                >
                  <span>Checkout</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <p className="text-[10px] text-center text-mutedGrey tracking-wider uppercase pt-1">
                Guaranteed Authenticity & Seamless Returns
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
