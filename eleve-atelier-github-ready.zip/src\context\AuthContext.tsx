import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  role: UserRole;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loginAs: (role: UserRole) => void;
  login: (email: string, pass: string) => Promise<boolean>;
  signup: (email: string, name: string, pass: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
}

const DEMO_CUSTOMER: UserProfile = {
  id: 'usr-customer-1',
  email: 'clara.atelier@example.com',
  full_name: 'Clara Delacroix',
  role: 'customer',
  phone: '+91 98765 43210',
  avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
};

const DEMO_ADMIN: UserProfile = {
  id: 'usr-admin-1',
  email: 'admin@eleveatelier.com',
  full_name: 'Genevieve Laurent (Director)',
  role: 'admin',
  phone: '+91 99999 88888',
  avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('eleve_current_user');
    return saved ? JSON.parse(saved) : DEMO_CUSTOMER;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('eleve_current_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('eleve_current_user');
    }
  }, [user]);

  const loginAs = (role: UserRole) => {
    if (role === 'admin') {
      setUser(DEMO_ADMIN);
    } else {
      setUser(DEMO_CUSTOMER);
    }
  };

  const login = async (email: string): Promise<boolean> => {
    if (email.toLowerCase().includes('admin')) {
      setUser(DEMO_ADMIN);
    } else {
      setUser({
        ...DEMO_CUSTOMER,
        email,
      });
    }
    return true;
  };

  const signup = async (email: string, name: string): Promise<boolean> => {
    setUser({
      id: `usr-${Date.now()}`,
      email,
      full_name: name,
      role: 'customer',
    });
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (user) {
      setUser({ ...user, ...updates });
    }
  };

  const role: UserRole = user?.role || 'customer';
  const isAuthenticated = Boolean(user);
  const isAdmin = role === 'admin';

  return (
    <AuthContext.Provider value={{
      user,
      role,
      isAuthenticated,
      isAdmin,
      loginAs,
      login,
      signup,
      logout,
      updateProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
