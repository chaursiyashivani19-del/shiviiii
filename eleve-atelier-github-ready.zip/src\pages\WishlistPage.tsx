import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { ProductCard } from '../components/shop/ProductCard';

export const WishlistPage: React.FC = () => {
  const { items, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="py-24 max-w-md mx-auto text-center px-4 space-y-4">
        <span className="text-6xl block">🤍</span>
        <h1 className="font-editorial text-3xl sm:text-4xl text-charcoal">Your Wishlist is Empty</h1>
        <p className="text-xs sm:text-sm text-mutedGrey font-light">
          Save your most coveted couture silhouettes here to view their stock availability.
        </p>
        <Link 
          to="/shop" 
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-cherry-600 transition-colors shadow-md"
        >
          <span>Explore The Catalogue</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-10 text-center sm:text-left">
        <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">
          Personal Curation
        </span>
        <h1 className="font-editorial text-3xl sm:text-5xl text-charcoal mt-1">
          Saved Silhouettes ({items.length})
        </h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
        {items.map(({ product }) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};
