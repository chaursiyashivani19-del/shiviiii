import React from 'react';
import { HeroSection } from '../components/home/HeroSection';
import { NewArrivals } from '../components/home/NewArrivals';
import { CategoryShowcase } from '../components/home/CategoryShowcase';
import { MoodboardSection } from '../components/home/MoodboardSection';
import { CampaignStory } from '../components/home/CampaignStory';

export const HomePage: React.FC = () => {
  return (
    <div className="space-y-0">
      <HeroSection />
      <NewArrivals />
      <CategoryShowcase />
      <MoodboardSection />
      <CampaignStory />
    </div>
  );
};
