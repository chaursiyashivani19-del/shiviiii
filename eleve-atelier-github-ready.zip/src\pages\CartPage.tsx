import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ArrowRight, Tag, ShieldCheck, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const CartPage: React.FC = () => {
  const { 
    items, 
    itemCount, 
    subtotal, 
    discountAmount, 
    shippingFee, 
    total, 
    appliedCoupon, 
    couponMessage, 
    updateQuantity, 
    removeFromCart, 
    applyCoupon, 
    removeCoupon 
  } = useCart();
  
  const [couponInput, setCouponInput] = useState('');
  const navigate = useNavigate();

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponInput.trim()) {
      applyCoupon(couponInput.trim());
      setCouponInput('');
    }
  };

  if (items.length === 0) {
    return (
      <div className="py-24 max-w-xl mx-auto px-4 text-center space-y-4">
        <span className="text-6xl block">🛍️</span>
        <h1 className="font-editorial text-3xl sm:text-4xl text-charcoal">Your Bag Is Empty</h1>
        <p className="text-xs sm:text-sm text-mutedGrey font-light max-w-md mx-auto">
          Explore our new arrivals and curated archival pieces to fill your personal fashion archive.
        </p>
        <Link 
          to="/shop" 
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-cherry-600 transition-colors shadow-md"
        >
          <span>Discover The Collection</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div className="mb-10 text-center sm:text-left">
        <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">
          Order Review
        </span>
        <h1 className="font-editorial text-3xl sm:text-5xl text-charcoal mt-1">
          Your Shopping Bag ({itemCount} {itemCount === 1 ? 'item' : 'items'})
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left: Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="hidden sm:grid grid-cols-12 text-xs uppercase tracking-luxury text-mutedGrey pb-3 border-b border-borderSoft font-semibold">
            <span className="col-span-6">Silhouette</span>
            <span className="col-span-2 text-center">Unit Price</span>
            <span className="col-span-2 text-center">Quantity</span>
            <span className="col-span-2 text-right">Subtotal</span>
          </div>

          <div className="space-y-4">
            {items.map((item) => {
              const currentPrice = item.product.sale_price_inr ?? item.product.price_inr;
              const primaryImg = item.product.images.find(img => img.is_primary) || item.product.images[0];
              const lineTotal = currentPrice * item.quantity;

              return (
                <div 
                  key={item.variant_id}
                  className="p-4 sm:p-5 bg-white/70 rounded-3xl border border-borderSoft/60 shadow-xs flex flex-col sm:grid sm:grid-cols-12 gap-4 items-center"
                >
                  {/* Product Info */}
                  <div className="col-span-6 w-full flex items-center gap-4">
                    <img 
                      src={primaryImg.image_url} 
                      alt={item.product.title} 
                      className="w-20 h-24 object-cover rounded-2xl bg-beige/40 flex-shrink-0"
                    />
                    <div className="space-y-1">
                      <Link 
                        to={`/product/${item.product.slug}`}
                        className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-charcoal hover:text-cherry-600 line-clamp-1"
                      >
                        {item.product.title}
                      </Link>
                      <div className="text-[11px] text-mutedGrey flex items-center gap-2">
                        <span>Size: <strong className="text-charcoal">{item.variant.size}</strong></span>
                        <span>•</span>
                        <span>Color: <strong className="text-charcoal">{item.variant.color}</strong></span>
                      </div>
                      <p className="text-[10px] text-mutedGrey font-mono">
                        SKU: {item.variant.sku}
                      </p>
                      <button
                        onClick={() => removeFromCart(item.variant_id)}
                        className="text-[11px] text-mutedGrey hover:text-cherry-600 flex items-center gap-1 transition-colors pt-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Remove piece</span>
                      </button>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="col-span-2 text-center text-xs font-semibold text-charcoal">
                    ₹{currentPrice.toLocaleString('en-IN')}
                  </div>

                  {/* Quantity Controller */}
                  <div className="col-span-2 flex justify-center">
                    <div className="flex items-center border border-borderSoft rounded-xl bg-ivory">
                      <button 
                        onClick={() => updateQuantity(item.variant_id, item.quantity - 1)}
                        className="p-1.5 text-charcoal hover:bg-beige transition-colors rounded-l-xl"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-3 text-xs font-bold text-charcoal">
                        {item.quantity}
                      </span>
                      <button 
                        onClick={() => updateQuantity(item.variant_id, item.quantity + 1)}
                        disabled={item.quantity >= item.variant.available_stock}
                        className="p-1.5 text-charcoal hover:bg-beige transition-colors rounded-r-xl disabled:opacity-30"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Line Total */}
                  <div className="col-span-2 text-right w-full sm:w-auto text-sm font-bold text-charcoal">
                    ₹{lineTotal.toLocaleString('en-IN')}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Order Summary & Coupon */}
        <div className="lg:col-span-4 space-y-6">
          <div className="p-6 bg-white/80 rounded-3xl border border-borderSoft/80 shadow-soft-luxury space-y-6">
            
            <h2 className="font-editorial text-xl text-charcoal tracking-wide pb-3 border-b border-borderSoft">
              Order Calculation
            </h2>

            {/* Promotional Code Form */}
            <div className="space-y-2">
              <label className="text-xs uppercase tracking-luxury font-semibold text-charcoal block">
                Promotional Code
              </label>
              
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-3 bg-blush-50 border border-blush-200 rounded-xl text-xs text-charcoal">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-cherry-600" />
                    <span>Applied: <strong>{appliedCoupon}</strong></span>
                  </div>
                  <button 
                    onClick={removeCoupon}
                    className="text-mutedGrey hover:text-cherry-600 font-semibold uppercase text-[10px]"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApply} className="flex gap-2">
                  <input 
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    placeholder="Try WELCOME10 or COQUETTE20"
                    className="flex-1 bg-ivory border border-borderSoft rounded-xl px-3 py-2 text-xs uppercase text-charcoal focus:outline-none focus:border-charcoal"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-xl hover:bg-cherry-600 transition-colors"
                  >
                    Apply
                  </button>
                </form>
              )}

              {couponMessage && (
                <p className={`text-[11px] ${appliedCoupon ? 'text-emerald-700' : 'text-cherry-600'}`}>
                  {couponMessage}
                </p>
              )}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-2.5 text-xs pt-3 border-t border-borderSoft">
              <div className="flex justify-between text-mutedGrey">
                <span>Subtotal ({itemCount} items)</span>
                <span className="font-semibold text-charcoal">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-cherry-600 font-semibold">
                  <span>Discount</span>
                  <span>-₹{discountAmount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-mutedGrey">
                <span>Domestic Express Shipping</span>
                <span>{shippingFee === 0 ? 'Complimentary' : `₹${shippingFee}`}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-charcoal pt-3 border-t border-borderSoft">
                <span>Total Amount (INR)</span>
                <span>₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Checkout Action */}
            <button
              onClick={() => navigate('/checkout')}
              className="w-full py-4 bg-charcoal hover:bg-cherry-600 text-white text-xs uppercase tracking-luxury font-semibold rounded-full shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>Proceed to Secure Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="pt-2 text-[10px] text-center text-mutedGrey space-y-1">
              <p className="flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>SSL Encrypted Checkout • Razorpay Architecture</span>
              </p>
              <p>Atomic Variant Reservation Prior To Payment</p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
