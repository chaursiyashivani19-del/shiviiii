import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Instagram, ShieldCheck, Sparkles } from 'lucide-react';
import { mockDb } from '../../services/supabase';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    mockDb.subscribeNewsletter(email);
    setSubscribed(true);
    setError('');
  };

  return (
    <footer className="bg-charcoal text-cream pt-20 pb-12 border-t border-charcoal/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Section: Brand Manifesto & Newsletter */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-white/10">
          
          <div className="lg:col-span-6 space-y-6">
            <span className="font-editorial text-3xl sm:text-4xl tracking-[0.2em] font-medium uppercase text-cream block">
              ÉLÉVÉ ATELIER
            </span>
            <p className="text-sm text-cream/70 max-w-md font-light leading-relaxed">
              An independent international couture label engineering digital romanticism,
              tactile coquette sensibilities, and soft luxury for modern connoisseurs worldwide.
            </p>
            <div className="flex items-center gap-6 pt-2 text-xs uppercase tracking-luxury text-cream/60">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blush-300" />
                Verified Atelier
              </span>
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-blush-300" />
                3D Interactive Fabric
              </span>
            </div>
          </div>

          <div className="lg:col-span-6 space-y-4">
            <h3 className="font-editorial text-xl tracking-wider text-cream">
              Subscribe to the Digital Gazette
            </h3>
            <p className="text-xs text-cream/70 max-w-sm">
              Receive private invitations to seasonal drops, archival previews, and 10% off your initial purchase.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2 p-3 bg-white/5 border border-blush-300/40 rounded-xl text-blush-200 text-xs">
                <CheckCircle2 className="w-4 h-4 text-blush-300" />
                <span>You have been added to the ÉLÉVÉ guestbook. Check your inbox.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="flex items-center gap-2">
                  <input 
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Enter your email address..."
                    className="flex-1 bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-xs text-cream placeholder-cream/40 focus:outline-none focus:border-blush-300 transition-colors"
                  />
                  <button
                    type="submit"
                    className="bg-blush-400 hover:bg-blush-500 text-charcoal font-semibold text-xs tracking-luxury uppercase px-6 py-3 rounded-xl transition-colors flex items-center gap-2"
                  >
                    <span>Join</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                {error && <p className="text-[11px] text-cherry-500">{error}</p>}
              </form>
            )}
          </div>

        </div>

        {/* Middle Navigation Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-16 border-b border-white/10 text-xs">
          
          <div className="space-y-3">
            <h4 className="font-editorial text-sm tracking-luxury uppercase text-cream font-semibold">Collections</h4>
            <ul className="space-y-2 text-cream/70 font-light">
              <li><Link to="/shop?category=dresses" className="hover:text-blush-200 transition-colors">Dresses & Evening Slips</Link></li>
              <li><Link to="/shop?category=tops" className="hover:text-blush-200 transition-colors">Corsets & Sculpted Blouses</Link></li>
              <li><Link to="/shop?category=coord" className="hover:text-blush-200 transition-colors">Bouclé & Tweed Co-ords</Link></li>
              <li><Link to="/shop?category=skirts" className="hover:text-blush-200 transition-colors">Bubble & Bias Skirts</Link></li>
              <li><Link to="/shop?category=accessories" className="hover:text-blush-200 transition-colors">Bow Bags & Fine Jewels</Link></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-editorial text-sm tracking-luxury uppercase text-cream font-semibold">Discovery</h4>
            <ul className="space-y-2 text-cream/70 font-light">
              <li><Link to="/#moodboard" className="hover:text-blush-200 transition-colors">Pinterest Moodboard</Link></li>
              <li><Link to="/shop?newArrival=true" className="hover:text-blush-200 transition-colors">New Arrivals (Winter 2026)</Link></li>
              <li><Link to="/#campaign" className="hover:text-blush-200 transition-colors">Editorial Storytelling</Link></li>
              <li><Link to="/shop" className="hover:text-blush-200 transition-colors">All 50+ Unique Pieces</Link></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-editorial text-sm tracking-luxury uppercase text-cream font-semibold">Client Care</h4>
            <ul className="space-y-2 text-cream/70 font-light">
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Bespoke Size Guide</span></li>
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Domestic Express Shipping (India)</span></li>
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Complimentary Returns</span></li>
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Payment Protection (Razorpay)</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-editorial text-sm tracking-luxury uppercase text-cream font-semibold">Atelier & Legal</h4>
            <ul className="space-y-2 text-cream/70 font-light">
              <li><Link to="/account" className="hover:text-blush-200 transition-colors">Customer Profile</Link></li>
              <li><Link to="/admin" className="hover:text-blush-200 transition-colors">Admin Console</Link></li>
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Privacy Charter</span></li>
              <li><span className="cursor-pointer hover:text-blush-200 transition-colors">Terms of Haute Couture</span></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-cream/50 tracking-wider">
          <p>© 2026 ÉLÉVÉ ATELIER. All rights reserved. Portfolio-First, Production-Ready Ecosystem.</p>
          <div className="flex items-center gap-4 mt-4 sm:mt-0">
            <span>CURRENCY: INR (₹)</span>
            <span>•</span>
            <span>THREE.JS & WEBGL ACCELERATED</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
