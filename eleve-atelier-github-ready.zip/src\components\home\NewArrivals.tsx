import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { mockDb } from '../../services/supabase';
import { ProductCard } from '../shop/ProductCard';

export const NewArrivals: React.FC = () => {
  const newArrivals = mockDb.getProducts({ isNewArrival: true, limit: 8 });

  return (
    <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-4 border-b border-borderSoft">
        <div>
          <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600 block mb-1">
            Section 04 • Curated Drop
          </span>
          <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl text-charcoal">
            New Silhouettes & Arrivals
          </h2>
        </div>
        <Link 
          to="/shop?newArrival=true"
          className="mt-4 md:mt-0 inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-charcoal hover:text-cherry-600 transition-colors group"
        >
          <span>View All 20+ New Releases</span>
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>

      {/* Product Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
        {newArrivals.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
};
