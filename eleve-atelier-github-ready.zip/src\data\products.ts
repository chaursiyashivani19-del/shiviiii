import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  // -------------------------------------------------------------
  // TOPS (8 products)
  // -------------------------------------------------------------
  {
    id: 'prod-01',
    title: 'Cherry Embroidered Bow Corset',
    slug: 'cherry-embroidered-bow-corset',
    description: 'Sculpted from double-layered blush twill featuring hand-embroidered cherry motifs and delicate grosgrain shoulder ribbons. Internal boning sculpts an iconic coquette silhouette.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 4499,
    sale_price_inr: 3899,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'A playful tribute to soft coquette romance and tactile craftsmanship.',
    fabric_details: '65% Cotton, 35% Silk twill with cotton lining and flex boning.',
    care_instructions: 'Dry clean only. Gentle steam on reverse side.',
    tags: ['coquette', 'corset', 'cherry', 'ribbon', 'embroidered'],
    created_at: '2026-11-01T10:00:00Z',
    images: [
      { id: 'img-01-1', product_id: 'prod-01', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true },
      { id: 'img-01-2', product_id: 'prod-01', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 2, is_primary: false },
      { id: 'img-01-3', product_id: 'prod-01', color: 'Ivory Cream', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 3, is_primary: false }
    ],
    variants: [
      { id: 'var-01-1', product_id: 'prod-01', sku: 'EAT-TOP-01-PNK-XS', size: 'XS', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 },
      { id: 'var-01-2', product_id: 'prod-01', sku: 'EAT-TOP-01-PNK-S', size: 'S', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 18, stock_reserved: 2, available_stock: 16, low_stock_threshold: 5 },
      { id: 'var-01-3', product_id: 'prod-01', sku: 'EAT-TOP-01-PNK-M', size: 'M', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 15, stock_reserved: 0, available_stock: 15, low_stock_threshold: 5 },
      { id: 'var-01-4', product_id: 'prod-01', sku: 'EAT-TOP-01-PNK-L', size: 'L', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 3 },
      { id: 'var-01-5', product_id: 'prod-01', sku: 'EAT-TOP-01-IVR-S', size: 'S', color: 'Ivory Cream', color_hex: '#FAF6F0', stock_on_hand: 10, stock_reserved: 1, available_stock: 9, low_stock_threshold: 4 },
      { id: 'var-01-6', product_id: 'prod-01', sku: 'EAT-TOP-01-IVR-M', size: 'M', color: 'Ivory Cream', color_hex: '#FAF6F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-02',
    title: 'Aurelia Organza Puffed Blouse',
    slug: 'aurelia-organza-puffed-blouse',
    description: 'Sheer iridescent organza blouse designed with dramatic balloon sleeves, high ruffled neckline, and mother-of-pearl buttons along the back spine.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 5299,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    editorial_quote: 'Dramatic ethereal sleeves that catch golden-hour light with a gossamer sheen.',
    fabric_details: '100% Silk organza with matching silk camisole included.',
    care_instructions: 'Hand wash in cold water with silk detergent. Dry flat.',
    tags: ['organza', 'balloon-sleeve', 'sheer', 'ethereal'],
    created_at: '2026-11-02T10:00:00Z',
    images: [
      { id: 'img-02-1', product_id: 'prod-02', color: 'Pearl White', image_url: 'https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true },
      { id: 'img-02-2', product_id: 'prod-02', color: 'Pearl White', image_url: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85', display_order: 2, is_primary: false }
    ],
    variants: [
      { id: 'var-02-1', product_id: 'prod-02', sku: 'EAT-TOP-02-PRL-XS', size: 'XS', color: 'Pearl White', color_hex: '#FCFBF7', stock_on_hand: 6, stock_reserved: 0, available_stock: 6, low_stock_threshold: 3 },
      { id: 'var-02-2', product_id: 'prod-02', sku: 'EAT-TOP-02-PRL-S', size: 'S', color: 'Pearl White', color_hex: '#FCFBF7', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 },
      { id: 'var-02-3', product_id: 'prod-02', sku: 'EAT-TOP-02-PRL-M', size: 'M', color: 'Pearl White', color_hex: '#FCFBF7', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-02-4', product_id: 'prod-02', sku: 'EAT-TOP-02-PRL-L', size: 'L', color: 'Pearl White', color_hex: '#FCFBF7', stock_on_hand: 4, stock_reserved: 0, available_stock: 4, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-03',
    title: 'Fleur Jacquard Halter Bustier',
    slug: 'fleur-jacquard-halter-bustier',
    description: 'Woven tapestry jacquard featuring delicate pastoral botanicals. Features an open criss-cross ribbon back and sweetheart neckline.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 3999,
    sale_price_inr: 3499,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    editorial_quote: 'Vintage tapestry elegance meets modern Gen-Z silhouette.',
    fabric_details: 'Custom woven jacquard weave with viscose backing.',
    care_instructions: 'Specialist dry clean.',
    tags: ['jacquard', 'tapestry', 'halter', 'vintage'],
    created_at: '2026-10-28T10:00:00Z',
    images: [
      { id: 'img-03-1', product_id: 'prod-03', color: 'Pastel Lavender', image_url: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-03-1', product_id: 'prod-03', sku: 'EAT-TOP-03-LAV-XS', size: 'XS', color: 'Pastel Lavender', color_hex: '#E8E0F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 },
      { id: 'var-03-2', product_id: 'prod-03', sku: 'EAT-TOP-03-LAV-S', size: 'S', color: 'Pastel Lavender', color_hex: '#E8E0F0', stock_on_hand: 12, stock_reserved: 1, available_stock: 11, low_stock_threshold: 4 },
      { id: 'var-03-3', product_id: 'prod-03', sku: 'EAT-TOP-03-LAV-M', size: 'M', color: 'Pastel Lavender', color_hex: '#E8E0F0', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 },
      { id: 'var-03-4', product_id: 'prod-03', sku: 'EAT-TOP-03-LAV-L', size: 'L', color: 'Pastel Lavender', color_hex: '#E8E0F0', stock_on_hand: 5, stock_reserved: 0, available_stock: 5, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-04',
    title: 'Satin Tie-Front Crop Blouse',
    slug: 'satin-tie-front-crop-blouse',
    description: 'Heavyweight liquid silk satin with exaggerated flared bell cuffs and an adjustable front keyhole bow tie.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 3699,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['satin', 'bell-cuff', 'minimalist', 'tie-front'],
    created_at: '2026-10-25T10:00:00Z',
    images: [
      { id: 'img-04-1', product_id: 'prod-04', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-04-1', product_id: 'prod-04', sku: 'EAT-TOP-04-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 15, stock_reserved: 0, available_stock: 15, low_stock_threshold: 4 },
      { id: 'var-04-2', product_id: 'prod-04', sku: 'EAT-TOP-04-IVR-M', size: 'M', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-05',
    title: 'Vintage Chantilly Lace Camisole',
    slug: 'vintage-chantilly-lace-camisole',
    description: 'French Chantilly lace draped over blush georgette silk. Features scalloped hemline and adjustable micro-spaghetti straps.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 2999,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['lace', 'camisole', 'french', 'boudoir'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-05-1', product_id: 'prod-05', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1502716119720-b23a93e5fe1b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-05-1', product_id: 'prod-05', sku: 'EAT-TOP-05-PNK-XS', size: 'XS', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-05-2', product_id: 'prod-05', sku: 'EAT-TOP-05-PNK-S', size: 'S', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 16, stock_reserved: 1, available_stock: 15, low_stock_threshold: 4 },
      { id: 'var-05-3', product_id: 'prod-05', sku: 'EAT-TOP-05-PNK-M', size: 'M', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-06',
    title: 'Ruched Asymmetrical Mesh Top',
    slug: 'ruched-asymmetrical-mesh-top',
    description: 'Sculptural one-shoulder top crafted from stretch tulle mesh with fluid contour ruching across the bodice.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 3299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['mesh', 'ruched', 'asymmetrical', 'modern'],
    created_at: '2026-10-20T10:00:00Z',
    images: [
      { id: 'img-06-1', product_id: 'prod-06', color: 'Charcoal Black', image_url: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-06-1', product_id: 'prod-06', sku: 'EAT-TOP-06-CHR-S', size: 'S', color: 'Charcoal Black', color_hex: '#1A1A1A', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 },
      { id: 'var-06-2', product_id: 'prod-06', sku: 'EAT-TOP-06-CHR-M', size: 'M', color: 'Charcoal Black', color_hex: '#1A1A1A', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-07',
    title: 'Scallop Pearl Knit Cardigan Crop',
    slug: 'scallop-pearl-knit-cardigan-crop',
    description: 'Fine-gauge merino wool blend knit accented by real baroque seed pearls hand-threaded into the scalloped collar and cuffs.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 5499,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    tags: ['knitwear', 'pearl', 'scalloped', 'merino'],
    created_at: '2026-11-05T10:00:00Z',
    images: [
      { id: 'img-07-1', product_id: 'prod-07', color: 'Soft Beige', image_url: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-07-1', product_id: 'prod-07', sku: 'EAT-TOP-07-BGE-XS', size: 'XS', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 5, stock_reserved: 0, available_stock: 5, low_stock_threshold: 2 },
      { id: 'var-07-2', product_id: 'prod-07', sku: 'EAT-TOP-07-BGE-S', size: 'S', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 },
      { id: 'var-07-3', product_id: 'prod-07', sku: 'EAT-TOP-07-BGE-M', size: 'M', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-08',
    title: 'Coquette Velvet Ribbon Bustier',
    slug: 'coquette-velvet-ribbon-bustier',
    description: 'Plush crimson velvet with contrast cream satin bow accents, underwire cups, and adjustable hook-and-eye back closure.',
    category_id: 'cat-tops',
    category_name: 'Tops & Blouses',
    price_inr: 4799,
    sale_price_inr: 4199,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['velvet', 'cherry', 'bustier', 'underwire'],
    created_at: '2026-10-15T10:00:00Z',
    images: [
      { id: 'img-08-1', product_id: 'prod-08', color: 'Cherry Red', image_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-08-1', product_id: 'prod-08', sku: 'EAT-TOP-08-RED-S', size: 'S', color: 'Cherry Red', color_hex: '#C92A42', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 },
      { id: 'var-08-2', product_id: 'prod-08', sku: 'EAT-TOP-08-RED-M', size: 'M', color: 'Cherry Red', color_hex: '#C92A42', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 3 }
    ]
  },

  // -------------------------------------------------------------
  // DRESSES (10 products)
  // -------------------------------------------------------------
  {
    id: 'prod-09',
    title: 'Juliette Silk Slip Maxi Dress',
    slug: 'juliette-silk-slip-maxi-dress',
    description: 'Cut on the true bias in 22mm Mulberry silk for an effortless drape that skims the hips. Designed with a gentle cowl neckline, low scoop back, and side thigh slit.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 8999,
    sale_price_inr: 7499,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'An archival slip dress cut on the bias to move like liquid moonlight.',
    fabric_details: '100% Grade 6A Mulberry Silk.',
    care_instructions: 'Hand wash cold or organic dry clean.',
    tags: ['silk', 'slip-dress', 'maxi', 'bias-cut', 'soft-luxury'],
    created_at: '2026-11-01T12:00:00Z',
    images: [
      { id: 'img-09-1', product_id: 'prod-09', color: 'Champagne Ivory', image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true },
      { id: 'img-09-2', product_id: 'prod-09', color: 'Champagne Ivory', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 2, is_primary: false }
    ],
    variants: [
      { id: 'var-09-1', product_id: 'prod-09', sku: 'EAT-DRS-09-IVR-XS', size: 'XS', color: 'Champagne Ivory', color_hex: '#FAF6F0', stock_on_hand: 8, stock_reserved: 1, available_stock: 7, low_stock_threshold: 3 },
      { id: 'var-09-2', product_id: 'prod-09', sku: 'EAT-DRS-09-IVR-S', size: 'S', color: 'Champagne Ivory', color_hex: '#FAF6F0', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 },
      { id: 'var-09-3', product_id: 'prod-09', sku: 'EAT-DRS-09-IVR-M', size: 'M', color: 'Champagne Ivory', color_hex: '#FAF6F0', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 4 },
      { id: 'var-09-4', product_id: 'prod-09', sku: 'EAT-DRS-09-IVR-L', size: 'L', color: 'Champagne Ivory', color_hex: '#FAF6F0', stock_on_hand: 5, stock_reserved: 0, available_stock: 5, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-10',
    title: 'Coquette Tiered Tulle Ballerina Dress',
    slug: 'coquette-tiered-tulle-ballerina-dress',
    description: 'Seven layers of ethereal pleated micro-tulle with a velvet-corseted bodice and oversized back satin bow.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 11999,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'A fantasy ball gown miniaturized for high-fashion digital romantics.',
    fabric_details: 'Polyester micro-tulle with silk velvet bodice lining.',
    care_instructions: 'Professional dry clean.',
    tags: ['tulle', 'ballerina', 'coquette', 'tiered', 'gown'],
    created_at: '2026-11-03T11:00:00Z',
    images: [
      { id: 'img-10-1', product_id: 'prod-10', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-10-1', product_id: 'prod-10', sku: 'EAT-DRS-10-PNK-XS', size: 'XS', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 5, stock_reserved: 0, available_stock: 5, low_stock_threshold: 2 },
      { id: 'var-10-2', product_id: 'prod-10', sku: 'EAT-DRS-10-PNK-S', size: 'S', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-10-3', product_id: 'prod-10', sku: 'EAT-DRS-10-PNK-M', size: 'M', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 6, stock_reserved: 0, available_stock: 6, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-11',
    title: 'Madeleine Bow-Back Linen Midi Dress',
    slug: 'madeleine-bow-back-linen-midi-dress',
    description: 'European washed linen midi dress featuring a tailored sweetheart bustier, side pockets, and triple trailing bow closures across the back.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 6499,
    sale_price_inr: 5499,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['linen', 'midi', 'bow-back', 'summer'],
    created_at: '2026-10-22T10:00:00Z',
    images: [
      { id: 'img-11-1', product_id: 'prod-11', color: 'Natural Oatmeal', image_url: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-11-1', product_id: 'prod-11', sku: 'EAT-DRS-11-OTM-S', size: 'S', color: 'Natural Oatmeal', color_hex: '#F5EBE1', stock_on_hand: 16, stock_reserved: 0, available_stock: 16, low_stock_threshold: 4 },
      { id: 'var-11-2', product_id: 'prod-11', sku: 'EAT-DRS-11-OTM-M', size: 'M', color: 'Natural Oatmeal', color_hex: '#F5EBE1', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-12',
    title: 'Ophelia Velvet Corset Evening Gown',
    slug: 'ophelia-velvet-corset-evening-gown',
    description: 'Sumptuous deep burgundy velvet sculpted into a floor-sweeping column gown with antique gold grommet lace-up sides.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 13499,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    tags: ['velvet', 'corset', 'burgundy', 'evening-wear'],
    created_at: '2026-11-06T10:00:00Z',
    images: [
      { id: 'img-12-1', product_id: 'prod-12', color: 'Cherry Burgundy', image_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-12-1', product_id: 'prod-12', sku: 'EAT-DRS-12-BUR-XS', size: 'XS', color: 'Cherry Burgundy', color_hex: '#871626', stock_on_hand: 4, stock_reserved: 0, available_stock: 4, low_stock_threshold: 2 },
      { id: 'var-12-2', product_id: 'prod-12', sku: 'EAT-DRS-12-BUR-S', size: 'S', color: 'Cherry Burgundy', color_hex: '#871626', stock_on_hand: 8, stock_reserved: 1, available_stock: 7, low_stock_threshold: 3 },
      { id: 'var-12-3', product_id: 'prod-12', sku: 'EAT-DRS-12-BUR-M', size: 'M', color: 'Cherry Burgundy', color_hex: '#871626', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-13',
    title: 'Serena Babydoll Organza Mini Dress',
    slug: 'serena-babydoll-organza-mini-dress',
    description: 'Voluminous puff-sleeve babydoll mini rendered in pastel lilac micro-jacquard with empire waistline and keyhole neckline.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 5799,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['babydoll', 'organza', 'lilac', 'mini-dress'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-13-1', product_id: 'prod-13', color: 'Pastel Lilac', image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-13-1', product_id: 'prod-13', sku: 'EAT-DRS-13-LIL-S', size: 'S', color: 'Pastel Lilac', color_hex: '#E8E0F0', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 },
      { id: 'var-13-2', product_id: 'prod-13', sku: 'EAT-DRS-13-LIL-M', size: 'M', color: 'Pastel Lilac', color_hex: '#E8E0F0', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-14',
    title: 'Genevieve Pleated Chiffon Tiered Dress',
    slug: 'genevieve-pleated-chiffon-tiered-dress',
    description: 'Sunburst pleated chiffon descending in cascading tiers, completed with a velvet neckband and crystal clasp.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 7899,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['chiffon', 'pleated', 'tiered', 'romantic'],
    created_at: '2026-10-18T10:00:00Z',
    images: [
      { id: 'img-14-1', product_id: 'prod-14', color: 'Ivory Cream', image_url: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-14-1', product_id: 'prod-14', sku: 'EAT-DRS-14-IVR-S', size: 'S', color: 'Ivory Cream', color_hex: '#FAF6F0', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 },
      { id: 'var-14-2', product_id: 'prod-14', sku: 'EAT-DRS-14-IVR-M', size: 'M', color: 'Ivory Cream', color_hex: '#FAF6F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-15',
    title: 'Vivienne Cut-Out Column Satin Gown',
    slug: 'vivienne-cut-out-column-satin-gown',
    description: 'Modern asymmetric midriff cutout gown in midnight charcoal heavy satin with high halter collar.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 9499,
    sale_price_inr: 8299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['column', 'cut-out', 'satin', 'noir'],
    created_at: '2026-10-12T10:00:00Z',
    images: [
      { id: 'img-15-1', product_id: 'prod-15', color: 'Midnight Noir', image_url: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-15-1', product_id: 'prod-15', sku: 'EAT-DRS-15-NOI-XS', size: 'XS', color: 'Midnight Noir', color_hex: '#1A1A1A', stock_on_hand: 6, stock_reserved: 0, available_stock: 6, low_stock_threshold: 2 },
      { id: 'var-15-2', product_id: 'prod-15', sku: 'EAT-DRS-15-NOI-S', size: 'S', color: 'Midnight Noir', color_hex: '#1A1A1A', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 },
      { id: 'var-15-3', product_id: 'prod-15', sku: 'EAT-DRS-15-NOI-M', size: 'M', color: 'Midnight Noir', color_hex: '#1A1A1A', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-16',
    title: 'Margot Floral Jacquard Tea Dress',
    slug: 'margot-floral-jacquard-tea-dress',
    description: 'Vintage-inspired A-line tea dress featuring woven cherry blossom jacquard, puffed short sleeves, and decorative covered buttons.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 6299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['tea-dress', 'jacquard', 'floral', 'vintage'],
    created_at: '2026-10-09T10:00:00Z',
    images: [
      { id: 'img-16-1', product_id: 'prod-16', color: 'Blush Cream', image_url: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-16-1', product_id: 'prod-16', sku: 'EAT-DRS-16-BLS-S', size: 'S', color: 'Blush Cream', color_hex: '#FBE8EC', stock_on_hand: 13, stock_reserved: 0, available_stock: 13, low_stock_threshold: 4 },
      { id: 'var-16-2', product_id: 'prod-16', sku: 'EAT-DRS-16-BLS-M', size: 'M', color: 'Blush Cream', color_hex: '#FBE8EC', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-17',
    title: 'Celeste Backless Liquid Slip Dress',
    slug: 'celeste-backless-liquid-slip-dress',
    description: 'Ultra-low backless slip dress with gossamer cross-straps and draped front neckline in silver-grey liquid viscose.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 7199,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['backless', 'liquid', 'silver', 'minimalist'],
    created_at: '2026-11-05T10:00:00Z',
    images: [
      { id: 'img-17-1', product_id: 'prod-17', color: 'Liquid Silver', image_url: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-17-1', product_id: 'prod-17', sku: 'EAT-DRS-17-SLV-XS', size: 'XS', color: 'Liquid Silver', color_hex: '#E8E0F0', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 3 },
      { id: 'var-17-2', product_id: 'prod-17', sku: 'EAT-DRS-17-SLV-S', size: 'S', color: 'Liquid Silver', color_hex: '#E8E0F0', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-18',
    title: 'Chloe Smocked Linen Prairie Dress',
    slug: 'chloe-smocked-linen-prairie-dress',
    description: 'Artisanal hand-smocked bodice, flutter ruffle sleeves, and tiered hemline in washed organic buttercup linen.',
    category_id: 'cat-dresses',
    category_name: 'Dresses',
    price_inr: 5899,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['smocked', 'prairie', 'linen', 'buttercup'],
    created_at: '2026-10-05T10:00:00Z',
    images: [
      { id: 'img-18-1', product_id: 'prod-18', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-18-1', product_id: 'prod-18', sku: 'EAT-DRS-18-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 15, stock_reserved: 0, available_stock: 15, low_stock_threshold: 4 },
      { id: 'var-18-2', product_id: 'prod-18', sku: 'EAT-DRS-18-IVR-M', size: 'M', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 }
    ]
  },

  // -------------------------------------------------------------
  // SKIRTS (7 products)
  // -------------------------------------------------------------
  {
    id: 'prod-19',
    title: 'Giselle Pleated Bubble Mini Skirt',
    slug: 'giselle-pleated-bubble-mini-skirt',
    description: 'Voluminous sculptural bubble hem constructed with knife-pleated taffeta over soft lining. Finished with hidden side zipper and fitted yoke.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 3899,
    sale_price_inr: 3299,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'A playful architectural cloud skirt that defines contemporary Gen-Z silhouettes.',
    tags: ['bubble-skirt', 'mini', 'pleated', 'coquette'],
    created_at: '2026-11-02T10:00:00Z',
    images: [
      { id: 'img-19-1', product_id: 'prod-19', color: 'Cloud White', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-19-1', product_id: 'prod-19', sku: 'EAT-SKT-19-WHT-XS', size: 'XS', color: 'Cloud White', color_hex: '#FCFBF7', stock_on_hand: 10, stock_reserved: 1, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-19-2', product_id: 'prod-19', sku: 'EAT-SKT-19-WHT-S', size: 'S', color: 'Cloud White', color_hex: '#FCFBF7', stock_on_hand: 15, stock_reserved: 0, available_stock: 15, low_stock_threshold: 4 },
      { id: 'var-19-3', product_id: 'prod-19', sku: 'EAT-SKT-19-WHT-M', size: 'M', color: 'Cloud White', color_hex: '#FCFBF7', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-20',
    title: 'Rosalie Bias-Cut Silk Maxi Skirt',
    slug: 'rosalie-bias-cut-silk-maxi-skirt',
    description: 'Floor-length pure silk charmeuse maxi skirt with internal elasticated waistband for a seamless, figure-hugging line.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 5999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['silk', 'maxi-skirt', 'bias-cut', 'soft-luxury'],
    created_at: '2026-10-20T10:00:00Z',
    images: [
      { id: 'img-20-1', product_id: 'prod-20', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-20-1', product_id: 'prod-20', sku: 'EAT-SKT-20-PNK-S', size: 'S', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 },
      { id: 'var-20-2', product_id: 'prod-20', sku: 'EAT-SKT-20-PNK-M', size: 'M', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-21',
    title: 'Antoinette Ruffled Tiered Lace Skirt',
    slug: 'antoinette-ruffled-tiered-lace-skirt',
    description: 'Three cascading asymmetric ruffles edged with scalloped micro-lace on semi-sheer georgette.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 4299,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['ruffle', 'lace', 'coquette', 'tiered'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-21-1', product_id: 'prod-21', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-21-1', product_id: 'prod-21', sku: 'EAT-SKT-21-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-22',
    title: 'Amelie Micro-Pleated Tennis Skort',
    slug: 'amelie-micro-pleated-tennis-skort',
    description: 'High-waisted tailored skort featuring precision knife pleats and built-in stretch shorts with side ribbon detail.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 3199,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['skort', 'pleated', 'tennis', 'preppy'],
    created_at: '2026-10-15T10:00:00Z',
    images: [
      { id: 'img-22-1', product_id: 'prod-22', color: 'Soft Lavender', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-22-1', product_id: 'prod-22', sku: 'EAT-SKT-22-LAV-XS', size: 'XS', color: 'Soft Lavender', color_hex: '#E8E0F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 },
      { id: 'var-22-2', product_id: 'prod-22', sku: 'EAT-SKT-22-LAV-S', size: 'S', color: 'Soft Lavender', color_hex: '#E8E0F0', stock_on_hand: 13, stock_reserved: 0, available_stock: 13, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-23',
    title: 'Colette Satin Column Maxi Skirt',
    slug: 'colette-satin-column-maxi-skirt',
    description: 'Clean minimalist column silhouette in deep charcoal satin with back walking vent.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 4999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['column', 'satin', 'noir', 'chic'],
    created_at: '2026-10-10T10:00:00Z',
    images: [
      { id: 'img-23-1', product_id: 'prod-23', color: 'Charcoal Black', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-23-1', product_id: 'prod-23', sku: 'EAT-SKT-23-CHR-S', size: 'S', color: 'Charcoal Black', color_hex: '#1A1A1A', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-24',
    title: 'Dahlia Embroidered Tulle Midi Skirt',
    slug: 'dahlia-embroidered-tulle-midi-skirt',
    description: 'Frothy sheer midi skirt layered with embroidered floral vines and velvet waistband.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 5499,
    sale_price_inr: 4699,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['tulle', 'embroidered', 'midi', 'romantic'],
    created_at: '2026-11-03T10:00:00Z',
    images: [
      { id: 'img-24-1', product_id: 'prod-24', color: 'Blush Rose', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-24-1', product_id: 'prod-24', sku: 'EAT-SKT-24-ROS-S', size: 'S', color: 'Blush Rose', color_hex: '#EEA2B2', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-25',
    title: 'Scarlett Velvet Low-Rise Mini Skirt',
    slug: 'scarlett-velvet-low-rise-mini-skirt',
    description: 'Y2K-inspired low-rise micro mini in cherry red velvet adorned with dainty satin ribbon bow buckles.',
    category_id: 'cat-skirts',
    category_name: 'Skirts',
    price_inr: 3499,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['velvet', 'cherry', 'y2k', 'micro-mini'],
    created_at: '2026-10-18T10:00:00Z',
    images: [
      { id: 'img-25-1', product_id: 'prod-25', color: 'Cherry Red', image_url: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-25-1', product_id: 'prod-25', sku: 'EAT-SKT-25-RED-XS', size: 'XS', color: 'Cherry Red', color_hex: '#C92A42', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-25-2', product_id: 'prod-25', sku: 'EAT-SKT-25-RED-S', size: 'S', color: 'Cherry Red', color_hex: '#C92A42', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 }
    ]
  },

  // -------------------------------------------------------------
  // BOTTOMS (7 products)
  // -------------------------------------------------------------
  {
    id: 'prod-26',
    title: 'Parisienne Wide-Leg Pleated Trousers',
    slug: 'parisienne-wide-leg-pleated-trousers',
    description: 'Impeccably tailored from virgin wool-blend gabardine with deep double front pleats, high waistline, and relaxed wide-leg drape.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 6499,
    sale_price_inr: 5499,
    status: 'published',
    is_featured: true,
    is_new_arrival: false,
    editorial_quote: 'Sharply tailored volume meeting effortless Parisian nonchalance.',
    tags: ['tailored', 'wide-leg', 'pleated', 'neutral'],
    created_at: '2026-10-25T10:00:00Z',
    images: [
      { id: 'img-26-1', product_id: 'prod-26', color: 'Soft Beige', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-26-1', product_id: 'prod-26', sku: 'EAT-BTM-26-BGE-S', size: 'S', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 16, stock_reserved: 0, available_stock: 16, low_stock_threshold: 4 },
      { id: 'var-26-2', product_id: 'prod-26', sku: 'EAT-BTM-26-BGE-M', size: 'M', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-27',
    title: 'L\'Amour Satin Cargo Pants',
    slug: 'lamour-satin-cargo-pants',
    description: 'Elevated streetwear cargo pant reimagined in liquid blush satin with oversized patch pockets and ribbon tie ankle cuffs.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 5499,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['cargo', 'satin', 'streetwear', 'ribbon'],
    created_at: '2026-11-01T10:00:00Z',
    images: [
      { id: 'img-27-1', product_id: 'prod-27', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-27-1', product_id: 'prod-27', sku: 'EAT-BTM-27-PNK-S', size: 'S', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 },
      { id: 'var-27-2', product_id: 'prod-27', sku: 'EAT-BTM-27-PNK-M', size: 'M', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-28',
    title: 'Bianca Flared Slit-Hem Trousers',
    slug: 'bianca-flared-slit-hem-trousers',
    description: 'Form-fitting stretch crepe trousers with tailored front seams and knee-to-ankle inner split hem to showcase footwear.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 4999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['split-hem', 'flared', 'crepe', 'noir'],
    created_at: '2026-10-15T10:00:00Z',
    images: [
      { id: 'img-28-1', product_id: 'prod-28', color: 'Charcoal Black', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-28-1', product_id: 'prod-28', sku: 'EAT-BTM-28-CHR-S', size: 'S', color: 'Charcoal Black', color_hex: '#1A1A1A', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-29',
    title: 'Odette Relaxed Pleated Linen Culottes',
    slug: 'odette-relaxed-pleated-linen-culottes',
    description: 'Breezy wide cropped culottes cut from washed French linen with drawstring waistband and deep slant pockets.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 4499,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['culottes', 'linen', 'relaxed', 'summer'],
    created_at: '2026-10-08T10:00:00Z',
    images: [
      { id: 'img-29-1', product_id: 'prod-29', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-29-1', product_id: 'prod-29', sku: 'EAT-BTM-29-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-30',
    title: 'Capucine High-Waist Tailored Shorts',
    slug: 'capucine-high-waist-tailored-shorts',
    description: 'Structured wool-blend city shorts with double front tucks and cuffed hem, tailored for an elegant high-fashion silhouette.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 3799,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['shorts', 'tailored', 'high-waist', 'preppy'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-30-1', product_id: 'prod-30', color: 'Soft Beige', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-30-1', product_id: 'prod-30', sku: 'EAT-BTM-30-BGE-S', size: 'S', color: 'Soft Beige', color_hex: '#F5EBE1', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-31',
    title: 'Camille Ribbon Embroidered Denim Jeans',
    slug: 'camille-ribbon-embroidered-denim-jeans',
    description: 'Vintage light wash 100% cotton denim straight jeans with delicate pastel pink ribbon bows hand-embroidered down both outer leg seams.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 5899,
    sale_price_inr: 4999,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    tags: ['denim', 'embroidered', 'ribbon', 'coquette-jeans'],
    created_at: '2026-11-05T10:00:00Z',
    images: [
      { id: 'img-31-1', product_id: 'prod-31', color: 'Light Wash Denim', image_url: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-31-1', product_id: 'prod-31', sku: 'EAT-BTM-31-DNM-26', size: 'XS', color: 'Light Wash Denim', color_hex: '#A4BFE0', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 },
      { id: 'var-31-2', product_id: 'prod-31', sku: 'EAT-BTM-31-DNM-28', size: 'S', color: 'Light Wash Denim', color_hex: '#A4BFE0', stock_on_hand: 16, stock_reserved: 1, available_stock: 15, low_stock_threshold: 4 },
      { id: 'var-31-3', product_id: 'prod-31', sku: 'EAT-BTM-31-DNM-30', size: 'M', color: 'Light Wash Denim', color_hex: '#A4BFE0', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-32',
    title: 'Sylvie Crepe Straight-Leg Pants',
    slug: 'sylvie-crepe-straight-leg-pants',
    description: 'Understated luxury straight pants in heavy ivory crepe with concealed hook fastening and pressed center creases.',
    category_id: 'cat-bottoms',
    category_name: 'Bottoms & Trousers',
    price_inr: 5299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['crepe', 'straight-leg', 'minimalist', 'ivory'],
    created_at: '2026-10-14T10:00:00Z',
    images: [
      { id: 'img-32-1', product_id: 'prod-32', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-32-1', product_id: 'prod-32', sku: 'EAT-BTM-32-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 }
    ]
  },

  // -------------------------------------------------------------
  // CO-ORD SETS (7 products)
  // -------------------------------------------------------------
  {
    id: 'prod-33',
    title: 'Valerie Bouclé Tweed Vest & Skirt Set',
    slug: 'valerie-boucle-tweed-vest-and-skirt-set',
    description: 'Iconic two-piece ensemble featuring a tailored cropped bouclé vest with ornate pearl crest buttons paired with a matching A-line micro skirt.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 8999,
    sale_price_inr: 7999,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'A modern tribute to French atelier tailoring in luminous pastel blush tweed.',
    tags: ['coord', 'tweed', 'boucle', 'pearl-buttons', 'vest-set'],
    created_at: '2026-11-03T10:00:00Z',
    images: [
      { id: 'img-33-1', product_id: 'prod-33', color: 'Blush Tweed', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-33-1', product_id: 'prod-33', sku: 'EAT-SET-33-TWD-XS', size: 'XS', color: 'Blush Tweed', color_hex: '#F6CED7', stock_on_hand: 6, stock_reserved: 0, available_stock: 6, low_stock_threshold: 2 },
      { id: 'var-33-2', product_id: 'prod-33', sku: 'EAT-SET-33-TWD-S', size: 'S', color: 'Blush Tweed', color_hex: '#F6CED7', stock_on_hand: 12, stock_reserved: 1, available_stock: 11, low_stock_threshold: 4 },
      { id: 'var-33-3', product_id: 'prod-33', sku: 'EAT-SET-33-TWD-M', size: 'M', color: 'Blush Tweed', color_hex: '#F6CED7', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-34',
    title: 'Solene Linen Wrap Top & Wide Pant Set',
    slug: 'solene-linen-wrap-top-and-wide-pant-set',
    description: 'Resort-ready two-piece set in pure washed ivory linen with tie-waist wrap kimono top and pooling palazzo pants.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 8499,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['linen', 'resort', 'palazzo', 'wrap-top'],
    created_at: '2026-10-20T10:00:00Z',
    images: [
      { id: 'img-34-1', product_id: 'prod-34', color: 'Warm Ivory', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-34-1', product_id: 'prod-34', sku: 'EAT-SET-34-IVR-S', size: 'S', color: 'Warm Ivory', color_hex: '#FAF6F0', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-35',
    title: 'Coquette Cherry Knit Cardigan & Mini Set',
    slug: 'coquette-cherry-knit-cardigan-and-mini-set',
    description: 'Soft brushed alpaca-blend cropped button cardigan with matching ribbed knit mini skirt, embroidered with cherry twin motifs.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 7299,
    sale_price_inr: 6499,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    tags: ['knit-set', 'cherry', 'alpaca', 'coquette'],
    created_at: '2026-11-05T10:00:00Z',
    images: [
      { id: 'img-35-1', product_id: 'prod-35', color: 'Cream & Cherry', image_url: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-35-1', product_id: 'prod-35', sku: 'EAT-SET-35-CHR-S', size: 'S', color: 'Cream & Cherry', color_hex: '#FAF6F0', stock_on_hand: 11, stock_reserved: 0, available_stock: 11, low_stock_threshold: 3 },
      { id: 'var-35-2', product_id: 'prod-35', sku: 'EAT-SET-35-CHR-M', size: 'M', color: 'Cream & Cherry', color_hex: '#FAF6F0', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-36',
    title: 'Elodie Organza Peplum & Trouser Duo',
    slug: 'elodie-organza-peplum-and-trouser-duo',
    description: 'Dramatic flared peplum top in structured organza accompanied by sleek cigarette trousers in matching lilac sheen.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 9899,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['peplum', 'organza', 'trousers', 'lilac'],
    created_at: '2026-10-18T10:00:00Z',
    images: [
      { id: 'img-36-1', product_id: 'prod-36', color: 'Pastel Lilac', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-36-1', product_id: 'prod-36', sku: 'EAT-SET-36-LIL-S', size: 'S', color: 'Pastel Lilac', color_hex: '#E8E0F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-37',
    title: 'Mirabelle Satin Corset & Maxi Skirt Set',
    slug: 'mirabelle-satin-corset-and-maxi-skirt-set',
    description: 'Sculpted boned satin corset with sweetheart neckline and flowing bias maxi skirt in soft vintage rose.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 9499,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['satin-set', 'corset', 'maxi-skirt', 'rose'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-37-1', product_id: 'prod-37', color: 'Vintage Rose', image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-37-1', product_id: 'prod-37', sku: 'EAT-SET-37-ROS-S', size: 'S', color: 'Vintage Rose', color_hex: '#EEA2B2', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-38',
    title: 'Celine Tailored Blazer & Pleated Skort Set',
    slug: 'celine-tailored-blazer-and-pleated-skort-set',
    description: 'Oversized boxy blazer with double breasted mother-of-pearl buttons paired with a micro pleated skort in neutral oat wool.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 10499,
    sale_price_inr: 9299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['blazer-set', 'skort', 'tailored', 'oversized'],
    created_at: '2026-10-12T10:00:00Z',
    images: [
      { id: 'img-38-1', product_id: 'prod-38', color: 'Oatmeal Wool', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-38-1', product_id: 'prod-38', sku: 'EAT-SET-38-OAT-S', size: 'S', color: 'Oatmeal Wool', color_hex: '#F5EBE1', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-39',
    title: 'Cosette Knit Halter & Cardigan Twin-Set',
    slug: 'cosette-knit-halter-and-cardigan-twin-set',
    description: 'Fine ribbed cotton silk knit halter neck cami paired with a coordinating cropped button-down bolero cardigan.',
    category_id: 'cat-coord',
    category_name: 'Co-ord Sets',
    price_inr: 6199,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['twin-set', 'bolero', 'knit', 'chic'],
    created_at: '2026-10-06T10:00:00Z',
    images: [
      { id: 'img-39-1', product_id: 'prod-39', color: 'Blush Cream', image_url: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-39-1', product_id: 'prod-39', sku: 'EAT-SET-39-BLS-S', size: 'S', color: 'Blush Cream', color_hex: '#FBE8EC', stock_on_hand: 13, stock_reserved: 0, available_stock: 13, low_stock_threshold: 4 }
    ]
  },

  // -------------------------------------------------------------
  // STREETWEAR & OUTERWEAR (7 products)
  // -------------------------------------------------------------
  {
    id: 'prod-40',
    title: 'Distressed Vintage Leather Biker Bomber',
    slug: 'distressed-vintage-leather-biker-bomber',
    description: 'Substantial vegan leather treated for a weathered patina, designed with an oversized bomber fit, silver hardware, and soft quilted blush satin interior lining.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 9999,
    sale_price_inr: 8499,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'Grounded rebellion balancing romantic coquette lace with heavy hardware.',
    tags: ['leather', 'bomber', 'biker', 'streetwear', 'distressed'],
    created_at: '2026-11-01T10:00:00Z',
    images: [
      { id: 'img-40-1', product_id: 'prod-40', color: 'Distressed Charcoal', image_url: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-40-1', product_id: 'prod-40', sku: 'EAT-OUT-40-CHR-S', size: 'S', color: 'Distressed Charcoal', color_hex: '#2D2D2D', stock_on_hand: 9, stock_reserved: 0, available_stock: 9, low_stock_threshold: 3 },
      { id: 'var-40-2', product_id: 'prod-40', sku: 'EAT-OUT-40-CHR-M', size: 'M', color: 'Distressed Charcoal', color_hex: '#2D2D2D', stock_on_hand: 12, stock_reserved: 0, available_stock: 12, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-41',
    title: 'Coquette Ribbon Oversized Wool Coat',
    slug: 'coquette-ribbon-oversized-wool-coat',
    description: 'Double-faced heavyweight wool blend trench coat finished with oversized grosgrain ribbon cuff buckles and wide lapels.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 14999,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    tags: ['wool-coat', 'trench', 'ribbon', 'statement'],
    created_at: '2026-11-05T10:00:00Z',
    images: [
      { id: 'img-41-1', product_id: 'prod-41', color: 'Powder Blush', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-41-1', product_id: 'prod-41', sku: 'EAT-OUT-41-BLS-S', size: 'S', color: 'Powder Blush', color_hex: '#F6CED7', stock_on_hand: 5, stock_reserved: 0, available_stock: 5, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-42',
    title: 'Cropped Satin Puffer Jacket',
    slug: 'cropped-satin-puffer-jacket',
    description: 'Ultra-lightweight down alternative puffer jacket encased in lustrous pale pink satin with high funnel collar and bungee waist cincher.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 7999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['puffer', 'satin', 'cropped', 'winter-chic'],
    created_at: '2026-10-22T10:00:00Z',
    images: [
      { id: 'img-42-1', product_id: 'prod-42', color: 'Soft Pink', image_url: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-42-1', product_id: 'prod-42', sku: 'EAT-OUT-42-PNK-S', size: 'S', color: 'Soft Pink', color_hex: '#EEA2B2', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-43',
    title: 'Oversized Editorial Gabardine Trench',
    slug: 'oversized-editorial-gabardine-trench',
    description: 'Water-resistant structured cotton gabardine trench coat with storm flaps, epaulettes, and tortoiseshell D-ring belt.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 12999,
    sale_price_inr: 10999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['trench', 'gabardine', 'editorial', 'timeless'],
    created_at: '2026-10-15T10:00:00Z',
    images: [
      { id: 'img-43-1', product_id: 'prod-43', color: 'Warm Honey Beige', image_url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-43-1', product_id: 'prod-43', sku: 'EAT-OUT-43-BGE-S', size: 'S', color: 'Warm Honey Beige', color_hex: '#F5EBE1', stock_on_hand: 10, stock_reserved: 0, available_stock: 10, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-44',
    title: 'French Terry Embroidered Bow Hoodie',
    slug: 'french-terry-embroidered-bow-hoodie',
    description: '450 GSM heavyweight organic French terry oversized hoodie with tonal satin bow appliqués on sleeves and kangaroo pocket.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 4999,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['hoodie', 'french-terry', 'bow', 'streetwear'],
    created_at: '2026-11-03T10:00:00Z',
    images: [
      { id: 'img-44-1', product_id: 'prod-44', color: 'Cream Ivory', image_url: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-44-1', product_id: 'prod-44', sku: 'EAT-OUT-44-IVR-OS', size: 'OS', color: 'Cream Ivory', color_hex: '#FAF6F0', stock_on_hand: 20, stock_reserved: 0, available_stock: 20, low_stock_threshold: 5 }
    ]
  },
  {
    id: 'prod-45',
    title: 'Cropped Tweed Pilot Jacket',
    slug: 'cropped-tweed-pilot-jacket',
    description: 'Structured short pilot jacket in ivory bouclé tweed with detachable shearling collar and silver zip detailing.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 8999,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['pilot-jacket', 'tweed', 'shearling', 'cropped'],
    created_at: '2026-10-10T10:00:00Z',
    images: [
      { id: 'img-45-1', product_id: 'prod-45', color: 'Ivory Tweed', image_url: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-45-1', product_id: 'prod-45', sku: 'EAT-OUT-45-TWD-S', size: 'S', color: 'Ivory Tweed', color_hex: '#FAF6F0', stock_on_hand: 7, stock_reserved: 0, available_stock: 7, low_stock_threshold: 2 }
    ]
  },
  {
    id: 'prod-46',
    title: 'Moto Faux-Fur Trim Aviator Jacket',
    slug: 'moto-faux-fur-trim-aviator-jacket',
    description: 'Vintage brown cracked faux leather aviator jacket lined with plush ivory faux shearling and twin buckle neck straps.',
    category_id: 'cat-streetwear',
    category_name: 'Streetwear & Outerwear',
    price_inr: 10999,
    sale_price_inr: 9499,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['aviator', 'faux-fur', 'moto', 'winter'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-46-1', product_id: 'prod-46', color: 'Vintage Cocoa', image_url: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-46-1', product_id: 'prod-46', sku: 'EAT-OUT-46-BRN-S', size: 'S', color: 'Vintage Cocoa', color_hex: '#3D2F28', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },

  // -------------------------------------------------------------
  // ACCESSORIES (7 products)
  // -------------------------------------------------------------
  {
    id: 'prod-47',
    title: 'The Mini Ribbon Bow Metallic Clutch',
    slug: 'the-mini-ribbon-bow-metallic-clutch',
    description: 'Handcrafted sculptural hard-case mini evening bag in mirror silver chrome featuring an exaggerated sculpted ribbon bow clasp and detachable snake chain.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 5999,
    sale_price_inr: 4999,
    status: 'published',
    is_featured: true,
    is_new_arrival: true,
    editorial_quote: 'A gleaming chrome jewel box shaped like a delicate couture bow.',
    tags: ['handbag', 'metallic', 'chrome', 'bow-bag', 'evening'],
    created_at: '2026-11-01T10:00:00Z',
    images: [
      { id: 'img-47-1', product_id: 'prod-47', color: 'Mirror Silver', image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-47-1', product_id: 'prod-47', sku: 'EAT-ACC-47-SLV-OS', size: 'OS', color: 'Mirror Silver', color_hex: '#D1D5DB', stock_on_hand: 15, stock_reserved: 1, available_stock: 14, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-48',
    title: 'Baroque Freshwater Pearl Drop Choker',
    slug: 'baroque-freshwater-pearl-drop-choker',
    description: 'Asymmetric natural baroque freshwater pearls hand-strung on silk thread with an 18K gold-plated vermeil cherry charm drop.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 3499,
    status: 'published',
    is_featured: true,
    is_new_arrival: false,
    tags: ['pearl', 'choker', 'baroque', 'gold', 'cherry'],
    created_at: '2026-10-20T10:00:00Z',
    images: [
      { id: 'img-48-1', product_id: 'prod-48', color: 'Pearl & Gold', image_url: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-48-1', product_id: 'prod-48', sku: 'EAT-ACC-48-GLD-OS', size: 'OS', color: 'Pearl & Gold', color_hex: '#F9F5EC', stock_on_hand: 22, stock_reserved: 0, available_stock: 22, low_stock_threshold: 5 }
    ]
  },
  {
    id: 'prod-49',
    title: 'Coquette Silk Satin Hair Bow Clip',
    slug: 'coquette-silk-satin-hair-bow-clip',
    description: 'Generous oversized French barrette hair bow in 100% heavy silk satin with trailing floor-grazing ribbon tails.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 1799,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['hair-bow', 'barrette', 'silk', 'ribbon'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-49-1', product_id: 'prod-49', color: 'Blush Pink', image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-49-1', product_id: 'prod-49', sku: 'EAT-ACC-49-PNK-OS', size: 'OS', color: 'Blush Pink', color_hex: '#F6CED7', stock_on_hand: 30, stock_reserved: 0, available_stock: 30, low_stock_threshold: 6 }
    ]
  },
  {
    id: 'prod-50',
    title: 'Crystal Heart Embellished Chain Belt',
    slug: 'crystal-heart-embellished-chain-belt',
    description: 'Multi-strand silver rolo chain hip belt with dangling faceted crystal heart charms and lobster clasp closure.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 2899,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['chain-belt', 'crystal', 'heart', 'y2k'],
    created_at: '2026-10-18T10:00:00Z',
    images: [
      { id: 'img-50-1', product_id: 'prod-50', color: 'Silver Chrome', image_url: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-50-1', product_id: 'prod-50', sku: 'EAT-ACC-50-SLV-OS', size: 'OS', color: 'Silver Chrome', color_hex: '#E5E7EB', stock_on_hand: 14, stock_reserved: 0, available_stock: 14, low_stock_threshold: 4 }
    ]
  },
  {
    id: 'prod-51',
    title: 'Quilted Lambskin Chain Shoulder Bag',
    slug: 'quilted-lambskin-chain-shoulder-bag',
    description: 'Pillow-quilted ultra-soft leather baguette shoulder bag featuring gold chain strap and magnetic flap closure.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 8999,
    sale_price_inr: 7799,
    status: 'published',
    is_featured: true,
    is_new_arrival: false,
    tags: ['handbag', 'quilted', 'leather', 'shoulder-bag'],
    created_at: '2026-10-12T10:00:00Z',
    images: [
      { id: 'img-51-1', product_id: 'prod-51', color: 'Ivory Butter', image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-51-1', product_id: 'prod-51', sku: 'EAT-ACC-51-IVR-OS', size: 'OS', color: 'Ivory Butter', color_hex: '#FAF6F0', stock_on_hand: 8, stock_reserved: 0, available_stock: 8, low_stock_threshold: 3 }
    ]
  },
  {
    id: 'prod-52',
    title: 'Ribbed Cashmere Knee-High Socks Set',
    slug: 'ribbed-cashmere-knee-high-socks-set',
    description: 'Two-pair set of ultra-fine Mongolian cashmere ribbed knee socks with delicate ruffled lace top cuffs.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 2299,
    status: 'published',
    is_featured: false,
    is_new_arrival: true,
    tags: ['cashmere', 'socks', 'lace-cuff', 'coquette'],
    created_at: '2026-11-04T10:00:00Z',
    images: [
      { id: 'img-52-1', product_id: 'prod-52', color: 'Cream & Blush', image_url: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-52-1', product_id: 'prod-52', sku: 'EAT-ACC-52-SET-OS', size: 'OS', color: 'Cream & Blush', color_hex: '#FBE8EC', stock_on_hand: 25, stock_reserved: 0, available_stock: 25, low_stock_threshold: 5 }
    ]
  },
  {
    id: 'prod-53',
    title: 'Sculptural Molten Gold Baroque Earrings',
    slug: 'sculptural-molten-gold-baroque-earrings',
    description: 'Organic molten drop earrings dipped in 24K gold with detachable freshwater baroque drop pearls.',
    category_id: 'cat-accessories',
    category_name: 'Accessories',
    price_inr: 3299,
    status: 'published',
    is_featured: false,
    is_new_arrival: false,
    tags: ['earrings', 'gold', 'baroque', 'molten'],
    created_at: '2026-10-15T10:00:00Z',
    images: [
      { id: 'img-53-1', product_id: 'prod-53', color: '24K Gold Plated', image_url: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=85', display_order: 1, is_primary: true }
    ],
    variants: [
      { id: 'var-53-1', product_id: 'prod-53', sku: 'EAT-ACC-53-GLD-OS', size: 'OS', color: '24K Gold Plated', color_hex: '#E5C158', stock_on_hand: 16, stock_reserved: 0, available_stock: 16, low_stock_threshold: 4 }
    ]
  }
];
