import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Hero3DScene } from '../3d/Hero3DScene';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:py-20 bg-gradient-to-b from-ivory via-blush-50/40 to-ivory border-b border-borderSoft/60">
      
      {/* Subtle background decorative radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-blush-200/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Editorial Copy */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left z-10">
            
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-blush-200 backdrop-blur-md shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-cherry-600 animate-spin" style={{ animationDuration: '6s' }} />
              <span className="text-[11px] font-semibold tracking-luxury uppercase text-charcoal">
                Winter Couture • 50+ New Silhouettes
              </span>
            </div>

            <h1 className="font-editorial text-4xl sm:text-6xl xl:text-7xl tracking-tight text-charcoal leading-[1.08] font-normal">
              Soft armor for modern <br />
              <span className="italic font-serif font-light text-cherry-600">romantics</span>
            </h1>

            <p className="text-sm sm:text-base text-charcoal/70 font-light max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Explore an editorial sanctuary where Parisian haute tailoring converges with 
              coquette bows, sheer organza, and real-time variant inventory.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-3">
              <Link 
                to="/shop" 
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-charcoal text-cream text-xs uppercase tracking-luxury font-semibold hover:bg-cherry-600 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-3 group"
              >
                <span>Explore The Collection</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
              
              <a 
                href="#moodboard" 
                className="w-full sm:w-auto px-8 py-4 rounded-full border border-charcoal/30 text-charcoal text-xs uppercase tracking-luxury font-medium hover:border-charcoal hover:bg-white/60 transition-colors text-center"
              >
                View Moodboard
              </a>
            </div>

            {/* Quick Metrics */}
            <div className="pt-8 border-t border-borderSoft/60 grid grid-cols-3 gap-6 text-center lg:text-left">
              <div>
                <p className="font-editorial text-2xl sm:text-3xl text-charcoal">53+</p>
                <p className="text-[10px] uppercase tracking-luxury text-mutedGrey mt-0.5">Unique Designs</p>
              </div>
              <div>
                <p className="font-editorial text-2xl sm:text-3xl text-charcoal">100%</p>
                <p className="text-[10px] uppercase tracking-luxury text-mutedGrey mt-0.5">Atomic Stock Lock</p>
              </div>
              <div>
                <p className="font-editorial text-2xl sm:text-3xl text-charcoal">WebGL</p>
                <p className="text-[10px] uppercase tracking-luxury text-mutedGrey mt-0.5">3D Interactive</p>
              </div>
            </div>

          </div>

          {/* Right 3D Interactive Canvas & Fashion Spotlight */}
          <div className="lg:col-span-6 relative">
            <div className="relative w-full h-[460px] sm:h-[540px] lg:h-[620px] rounded-3xl overflow-hidden border border-borderSoft/60 bg-gradient-to-br from-cream via-blush-50/50 to-beige/30 shadow-card-elevated">
              
              {/* 3D WebGL Canvas */}
              <Hero3DScene />

              {/* Floating Pill Label */}
              <div className="absolute bottom-5 left-5 right-5 p-3.5 bg-white/85 backdrop-blur-md rounded-2xl border border-borderSoft/60 flex items-center justify-between pointer-events-none shadow-sm">
                <div>
                  <p className="text-[10px] uppercase tracking-luxury text-mutedGrey font-medium">Interactive 3D Object</p>
                  <p className="text-xs font-semibold text-charcoal">Couture Blush Ribbon & Chrome Clutch</p>
                </div>
                <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-blush-100 text-charcoal tracking-wider uppercase">
                  Rotate & Inspect
                </span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
