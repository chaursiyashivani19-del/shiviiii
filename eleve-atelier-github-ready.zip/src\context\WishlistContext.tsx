import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, WishlistItem } from '../types';

interface WishlistContextType {
  items: WishlistItem[];
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;
  removeFromWishlist: (productId: string) => void;
  itemCount: number;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<WishlistItem[]>(() => {
    try {
      const saved = localStorage.getItem('eleve_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('eleve_wishlist', JSON.stringify(items));
    } catch (e) {
      console.warn(e);
    }
  }, [items]);

  const toggleWishlist = (product: Product) => {
    setItems(prev => {
      const exists = prev.some(i => i.product_id === product.id);
      if (exists) {
        return prev.filter(i => i.product_id !== product.id);
      } else {
        return [
          ...prev,
          {
            id: `wl-${Date.now()}`,
            product_id: product.id,
            product,
            added_at: new Date().toISOString(),
          },
        ];
      }
    });
  };

  const removeFromWishlist = (productId: string) => {
    setItems(prev => prev.filter(i => i.product_id !== productId));
  };

  const isInWishlist = (productId: string): boolean => {
    return items.some(i => i.product_id === productId);
  };

  return (
    <WishlistContext.Provider value={{
      items,
      toggleWishlist,
      isInWishlist,
      removeFromWishlist,
      itemCount: items.length,
    }}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
