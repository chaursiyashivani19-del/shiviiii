import { createClient } from '@supabase/supabase-js';
import { INITIAL_PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { 
  Product, 
  ProductVariant, 
  Category, 
  Order, 
  InventoryMovement, 
  DiscountCode, 
  UserProfile, 
  OrderStatus 
} from '../types';

// Supabase Environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseAnonKey && 
  !supabaseUrl.includes('placeholder') &&
  !supabaseUrl.includes('your-project')
);

// Real Supabase client instance (used when configured)
export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey) 
  : null;

// ==============================================================================
// LOCAL DEMO MOCK DATABASE ENGINE
// Provides 100% operational e-commerce, atomic inventory, audit logging,
// and orders persistence even before cloud Supabase keys are entered!
// ==============================================================================

const STORAGE_KEYS = {
  PRODUCTS: 'eleve_atelier_products',
  CATEGORIES: 'eleve_atelier_categories',
  ORDERS: 'eleve_atelier_orders',
  INVENTORY_MOVEMENTS: 'eleve_atelier_movements',
  DISCOUNTS: 'eleve_atelier_discounts',
  PROFILES: 'eleve_atelier_profiles',
};

// Initial Seed Discount Codes
const INITIAL_DISCOUNTS: DiscountCode[] = [
  { id: 'disc-1', code: 'WELCOME10', discount_percent: 10, min_order_amount_inr: 2000, is_active: true },
  { id: 'disc-2', code: 'COQUETTE20', discount_percent: 20, min_order_amount_inr: 5000, is_active: true },
  { id: 'disc-3', code: 'FREESHIP', fixed_amount_inr: 250, min_order_amount_inr: 1500, is_active: true },
];

class MockDatabaseEngine {
  private products: Product[] = [];
  private categories: Category[] = CATEGORIES;
  private orders: Order[] = [];
  private movements: InventoryMovement[] = [];
  private discounts: DiscountCode[] = INITIAL_DISCOUNTS;
  private subscribers: string[] = [];

  constructor() {
    this.initDatabase();
  }

  private initDatabase() {
    try {
      const storedProducts = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (storedProducts) {
        this.products = JSON.parse(storedProducts);
      } else {
        this.products = [...INITIAL_PRODUCTS];
        this.saveProducts();
      }

      const storedOrders = localStorage.getItem(STORAGE_KEYS.ORDERS);
      if (storedOrders) {
        this.orders = JSON.parse(storedOrders);
      } else {
        // Initial sample historical orders for analytics demonstration
        this.orders = [
          {
            id: 'ord-1001',
            order_number: 'EA-2026-8801',
            user_id: 'user-demo-1',
            guest_email: 'clara.fashion@example.com',
            shipping_address: {
              id: 'addr-1',
              full_name: 'Clara Delacroix',
              phone: '+91 98765 43210',
              street_address: '42 Rue Des Rêves, Bandra West',
              city: 'Mumbai',
              state: 'Maharashtra',
              postal_code: '400050',
              country: 'India',
              is_default: true,
            },
            subtotal_inr: 8999,
            discount_amount_inr: 899.90,
            shipping_fee_inr: 0,
            total_inr: 8099.10,
            discount_code_applied: 'WELCOME10',
            status: 'delivered',
            items: [
              {
                id: 'item-1',
                order_id: 'ord-1001',
                product_id: 'prod-09',
                variant_id: 'var-09-2',
                product_title_snapshot: 'Juliette Silk Slip Maxi Dress',
                sku_snapshot: 'EAT-DRS-09-IVR-S',
                size_snapshot: 'S',
                color_snapshot: 'Champagne Ivory',
                unit_price_inr_snapshot: 8999,
                quantity: 1,
                total_price_inr: 8999,
                image_url: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=600&q=80',
              }
            ],
            created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
          },
          {
            id: 'ord-1002',
            order_number: 'EA-2026-8802',
            user_id: 'user-demo-2',
            guest_email: 'sophie.couture@example.com',
            shipping_address: {
              id: 'addr-2',
              full_name: 'Sophie Laurent',
              phone: '+91 91234 56789',
              street_address: '18 Vasant Vihar Marg',
              city: 'New Delhi',
              state: 'Delhi',
              postal_code: '110057',
              country: 'India',
              is_default: true,
            },
            subtotal_inr: 10498,
            discount_amount_inr: 2099.60,
            shipping_fee_inr: 0,
            total_inr: 8398.40,
            discount_code_applied: 'COQUETTE20',
            status: 'confirmed',
            items: [
              {
                id: 'item-2',
                order_id: 'ord-1002',
                product_id: 'prod-01',
                variant_id: 'var-01-2',
                product_title_snapshot: 'Cherry Embroidered Bow Corset',
                sku_snapshot: 'EAT-TOP-01-PNK-S',
                size_snapshot: 'S',
                color_snapshot: 'Blush Pink',
                unit_price_inr_snapshot: 4499,
                quantity: 1,
                total_price_inr: 4499,
                image_url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80',
              },
              {
                id: 'item-3',
                order_id: 'ord-1002',
                product_id: 'prod-47',
                variant_id: 'var-47-1',
                product_title_snapshot: 'The Mini Ribbon Bow Metallic Clutch',
                sku_snapshot: 'EAT-ACC-47-SLV-OS',
                size_snapshot: 'OS',
                color_snapshot: 'Mirror Silver',
                unit_price_inr_snapshot: 5999,
                quantity: 1,
                total_price_inr: 5999,
                image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80',
              }
            ],
            created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
          }
        ];
        this.saveOrders();
      }

      const storedMovements = localStorage.getItem(STORAGE_KEYS.INVENTORY_MOVEMENTS);
      if (storedMovements) {
        this.movements = JSON.parse(storedMovements);
      } else {
        this.movements = [
          {
            id: 'mov-1',
            variant_id: 'var-01-2',
            product_title: 'Cherry Embroidered Bow Corset',
            sku: 'EAT-TOP-01-PNK-S',
            movement_type: 'initial_stock',
            quantity_change: 20,
            stock_on_hand_after: 20,
            stock_reserved_after: 0,
            notes: 'Initial production batch arrival at warehouse',
            created_at: '2026-11-01T08:00:00Z',
          },
          {
            id: 'mov-2',
            variant_id: 'var-01-2',
            product_title: 'Cherry Embroidered Bow Corset',
            sku: 'EAT-TOP-01-PNK-S',
            movement_type: 'order_reservation',
            quantity_change: 2,
            stock_on_hand_after: 18,
            stock_reserved_after: 2,
            reference_id: 'EA-2026-8802',
            notes: 'Atomic reservation for pending order',
            created_at: '2026-11-21T14:30:00Z',
          }
        ];
        this.saveMovements();
      }
    } catch {
      this.products = [...INITIAL_PRODUCTS];
    }
  }

  private saveProducts() {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(this.products));
    } catch (e) {
      console.warn('Storage quota error', e);
    }
  }

  private saveOrders() {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(this.orders));
    } catch (e) {
      console.warn('Storage quota error', e);
    }
  }

  private saveMovements() {
    try {
      localStorage.setItem(STORAGE_KEYS.INVENTORY_MOVEMENTS, JSON.stringify(this.movements));
    } catch (e) {
      console.warn('Storage quota error', e);
    }
  }

  // --- Products & Discovery ---
  public getProducts(params?: {
    search?: string;
    category?: string;
    size?: string;
    color?: string;
    minPrice?: number;
    maxPrice?: number;
    inStockOnly?: boolean;
    sortBy?: 'price-asc' | 'price-desc' | 'newest' | 'popularity';
    isFeatured?: boolean;
    isNewArrival?: boolean;
    limit?: number;
  }): Product[] {
    let result = [...this.products].filter(p => p.status === 'published');

    if (params?.search) {
      const q = params.search.toLowerCase().trim();
      result = result.filter(p => 
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.tags?.some(t => t.toLowerCase().includes(q)) ||
        p.variants.some(v => v.sku.toLowerCase().includes(q))
      );
    }

    if (params?.category && params.category !== 'all') {
      const cat = CATEGORIES.find(c => c.slug === params.category || c.id === params.category);
      if (cat) {
        result = result.filter(p => p.category_id === cat.id || p.category_name?.toLowerCase().includes(cat.name.toLowerCase()));
      }
    }

    if (params?.size && params.size !== 'all') {
      result = result.filter(p => p.variants.some(v => v.size === params.size && v.available_stock > 0));
    }

    if (params?.color && params.color !== 'all') {
      result = result.filter(p => p.variants.some(v => v.color.toLowerCase().includes(params.color!.toLowerCase())));
    }

    if (params?.minPrice !== undefined) {
      result = result.filter(p => (p.sale_price_inr ?? p.price_inr) >= params.minPrice!);
    }

    if (params?.maxPrice !== undefined) {
      result = result.filter(p => (p.sale_price_inr ?? p.price_inr) <= params.maxPrice!);
    }

    if (params?.inStockOnly) {
      result = result.filter(p => p.variants.some(v => v.available_stock > 0));
    }

    if (params?.isFeatured) {
      result = result.filter(p => p.is_featured);
    }

    if (params?.isNewArrival) {
      result = result.filter(p => p.is_new_arrival);
    }

    // Sorting
    if (params?.sortBy === 'price-asc') {
      result.sort((a, b) => (a.sale_price_inr ?? a.price_inr) - (b.sale_price_inr ?? b.price_inr));
    } else if (params?.sortBy === 'price-desc') {
      result.sort((a, b) => (b.sale_price_inr ?? b.price_inr) - (a.sale_price_inr ?? a.price_inr));
    } else if (params?.sortBy === 'popularity') {
      result.sort((a, b) => (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0));
    } else {
      // Default: newest
      result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }

    if (params?.limit) {
      result = result.slice(0, params.limit);
    }

    return result;
  }

  public getProductBySlug(slug: string): Product | null {
    return this.products.find(p => p.slug === slug || p.id === slug) || null;
  }

  public getCategories(): Category[] {
    return this.categories;
  }

  // --- Atomic Inventory Engine ---
  public reserveStockAtomic(variantId: string, quantity: number, orderId: string): boolean {
    for (const product of this.products) {
      const variant = product.variants.find(v => v.id === variantId);
      if (variant) {
        if (variant.available_stock < quantity) {
          return false; // Insufficient stock
        }
        variant.stock_reserved += quantity;
        variant.available_stock = variant.stock_on_hand - variant.stock_reserved;
        
        // Record audit
        this.movements.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          variant_id: variant.id,
          product_title: product.title,
          sku: variant.sku,
          movement_type: 'order_reservation',
          quantity_change: quantity,
          stock_on_hand_after: variant.stock_on_hand,
          stock_reserved_after: variant.stock_reserved,
          reference_id: orderId,
          notes: `Atomic reservation for order ${orderId}`,
          created_at: new Date().toISOString(),
        });

        this.saveProducts();
        this.saveMovements();
        return true;
      }
    }
    return false;
  }

  public releaseStockReservation(variantId: string, quantity: number, orderId: string): boolean {
    for (const product of this.products) {
      const variant = product.variants.find(v => v.id === variantId);
      if (variant) {
        variant.stock_reserved = Math.max(0, variant.stock_reserved - quantity);
        variant.available_stock = variant.stock_on_hand - variant.stock_reserved;

        this.movements.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          variant_id: variant.id,
          product_title: product.title,
          sku: variant.sku,
          movement_type: 'order_cancellation',
          quantity_change: -quantity,
          stock_on_hand_after: variant.stock_on_hand,
          stock_reserved_after: variant.stock_reserved,
          reference_id: orderId,
          notes: `Released reservation for order ${orderId}`,
          created_at: new Date().toISOString(),
        });

        this.saveProducts();
        this.saveMovements();
        return true;
      }
    }
    return false;
  }

  public commitStockDeduction(variantId: string, quantity: number, orderId: string): boolean {
    for (const product of this.products) {
      const variant = product.variants.find(v => v.id === variantId);
      if (variant) {
        variant.stock_on_hand = Math.max(0, variant.stock_on_hand - quantity);
        variant.stock_reserved = Math.max(0, variant.stock_reserved - quantity);
        variant.available_stock = variant.stock_on_hand - variant.stock_reserved;

        this.movements.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          variant_id: variant.id,
          product_title: product.title,
          sku: variant.sku,
          movement_type: 'order_fulfillment',
          quantity_change: -quantity,
          stock_on_hand_after: variant.stock_on_hand,
          stock_reserved_after: variant.stock_reserved,
          reference_id: orderId,
          notes: `Payment verified & stock fulfilled for order ${orderId}`,
          created_at: new Date().toISOString(),
        });

        this.saveProducts();
        this.saveMovements();
        return true;
      }
    }
    return false;
  }

  public adjustStockManual(params: {
    variantId: string;
    delta: number;
    type: 'manual_addition' | 'manual_deduction' | 'inventory_correction' | 'return_restock';
    notes: string;
    userId?: string;
  }): boolean {
    for (const product of this.products) {
      const variant = product.variants.find(v => v.id === params.variantId);
      if (variant) {
        const nextStock = variant.stock_on_hand + params.delta;
        if (nextStock < 0) return false;

        variant.stock_on_hand = nextStock;
        variant.available_stock = variant.stock_on_hand - variant.stock_reserved;

        this.movements.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          variant_id: variant.id,
          product_title: product.title,
          sku: variant.sku,
          movement_type: params.type,
          quantity_change: params.delta,
          stock_on_hand_after: variant.stock_on_hand,
          stock_reserved_after: variant.stock_reserved,
          notes: params.notes,
          created_by: params.userId || 'admin',
          created_at: new Date().toISOString(),
        });

        this.saveProducts();
        this.saveMovements();
        return true;
      }
    }
    return false;
  }

  // --- Orders & Checkout ---
  public createOrder(orderData: Omit<Order, 'id' | 'created_at'>): Order {
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      created_at: new Date().toISOString(),
    };

    this.orders.unshift(newOrder);
    this.saveOrders();
    return newOrder;
  }

  public getOrders(userId?: string): Order[] {
    if (userId) {
      return this.orders.filter(o => o.user_id === userId);
    }
    return this.orders;
  }

  public updateOrderStatus(orderId: string, status: OrderStatus): boolean {
    const order = this.orders.find(o => o.id === orderId);
    if (order) {
      order.status = status;
      order.updated_at = new Date().toISOString();
      this.saveOrders();
      return true;
    }
    return false;
  }

  // --- Inventory Movements Audit ---
  public getInventoryMovements(variantId?: string): InventoryMovement[] {
    if (variantId) {
      return this.movements.filter(m => m.variant_id === variantId);
    }
    return this.movements;
  }

  // --- Discount Codes ---
  public validateDiscount(code: string, subtotal: number): { valid: boolean; discountAmount: number; message: string } {
    const normalized = code.toUpperCase().trim();
    const discount = this.discounts.find(d => d.code === normalized && d.is_active);

    if (!discount) {
      return { valid: false, discountAmount: 0, message: 'Invalid or inactive promotional code.' };
    }

    if (subtotal < discount.min_order_amount_inr) {
      return { 
        valid: false, 
        discountAmount: 0, 
        message: `Requires minimum order value of ₹${discount.min_order_amount_inr.toLocaleString('en-IN')}.` 
      };
    }

    let amount = 0;
    if (discount.discount_percent) {
      amount = (subtotal * discount.discount_percent) / 100;
    } else if (discount.fixed_amount_inr) {
      amount = discount.fixed_amount_inr;
    }

    return { 
      valid: true, 
      discountAmount: Math.min(amount, subtotal), 
      message: `Code ${discount.code} applied successfully!` 
    };
  }

  // --- Newsletter ---
  public subscribeNewsletter(email: string): boolean {
    if (!email || !email.includes('@')) return false;
    if (!this.subscribers.includes(email.toLowerCase())) {
      this.subscribers.push(email.toLowerCase());
    }
    return true;
  }

  // --- Admin Analytics & Management ---
  public getAdminMetrics() {
    const totalOrders = this.orders.length;
    const totalRevenue = this.orders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? o.total_inr : 0), 0);
    const pendingOrders = this.orders.filter(o => o.status === 'pending' || o.status === 'processing').length;
    const completedOrders = this.orders.filter(o => o.status === 'delivered').length;

    let totalProducts = this.products.length;
    let totalInventoryUnits = 0;
    let lowStockVariants = 0;
    let outOfStockVariants = 0;

    for (const p of this.products) {
      for (const v of p.variants) {
        totalInventoryUnits += v.stock_on_hand;
        if (v.available_stock <= 0) {
          outOfStockVariants++;
        } else if (v.available_stock <= v.low_stock_threshold) {
          lowStockVariants++;
        }
      }
    }

    return {
      totalOrders,
      totalRevenue,
      pendingOrders,
      completedOrders,
      totalProducts,
      totalInventoryUnits,
      lowStockVariants,
      outOfStockVariants,
      recentOrders: this.orders.slice(0, 5),
    };
  }

  public createProduct(productData: Omit<Product, 'id' | 'created_at'>): Product {
    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    this.products.unshift(newProduct);
    this.saveProducts();
    return newProduct;
  }

  public updateProduct(productId: string, updates: Partial<Product>): boolean {
    const idx = this.products.findIndex(p => p.id === productId);
    if (idx !== -1) {
      this.products[idx] = { ...this.products[idx], ...updates, updated_at: new Date().toISOString() };
      this.saveProducts();
      return true;
    }
    return false;
  }

  public archiveProduct(productId: string): boolean {
    return this.updateProduct(productId, { status: 'archived' });
  }

  public getAllProductsForAdmin(): Product[] {
    return this.products;
  }
}

export const mockDb = new MockDatabaseEngine();
