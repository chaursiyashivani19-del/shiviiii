import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart3, 
  Package, 
  Layers, 
  ShoppingBag, 
  History, 
  AlertTriangle, 
  CheckCircle, 
  Plus, 
  ArrowUpRight, 
  RotateCcw, 
  Filter, 
  Search,
  Shield,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { mockDb } from '../../services/supabase';
import { Product, ProductVariant, OrderStatus, InventoryMovementType } from '../../types';

export const AdminDashboard: React.FC = () => {
  const { user, isAdmin, loginAs } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'inventory' | 'orders' | 'audit'>('overview');

  // Metrics
  const metrics = mockDb.getAdminMetrics();
  const allProducts = mockDb.getAllProductsForAdmin();
  const allOrders = mockDb.getOrders();
  const movements = mockDb.getInventoryMovements();

  // Inventory adjustment modal state
  const [adjustModalOpen, setAdjustModalOpen] = useState(false);
  const [selectedVariantForAdjust, setSelectedVariantForAdjust] = useState<{ variant: ProductVariant; productTitle: string } | null>(null);
  const [adjustDelta, setAdjustDelta] = useState<number>(5);
  const [adjustType, setAdjustType] = useState<InventoryMovementType>('manual_addition');
  const [adjustNotes, setAdjustNotes] = useState('');
  const [inventorySearch, setInventorySearch] = useState('');
  const [inventoryStatusFilter, setInventoryStatusFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'out_of_stock'>('all');

  // If not admin, render protection notice with instant switch button for reviewer
  if (!isAdmin) {
    return (
      <div className="py-24 max-w-lg mx-auto px-4 text-center space-y-4">
        <div className="w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto border border-red-200">
          <Shield className="w-8 h-8" />
        </div>
        <h1 className="font-editorial text-3xl text-charcoal">Protected Atelier Administration</h1>
        <p className="text-xs sm:text-sm text-mutedGrey font-light">
          This portal is restricted to authorized creative directors and inventory managers.
        </p>
        <button
          onClick={() => loginAs('admin')}
          className="px-6 py-3 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-cherry-600 transition-colors shadow-md"
        >
          Authenticate as Director (Admin Mode)
        </button>
      </div>
    );
  }

  // Handle stock adjustment
  const handleExecuteStockAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVariantForAdjust) return;

    const ok = mockDb.adjustStockManual({
      variantId: selectedVariantForAdjust.variant.id,
      delta: adjustType === 'manual_deduction' ? -Math.abs(adjustDelta) : Math.abs(adjustDelta),
      type: adjustType as any,
      notes: adjustNotes || 'Manual administrative stock rebalance',
      userId: user?.id,
    });

    if (ok) {
      setAdjustModalOpen(false);
      setSelectedVariantForAdjust(null);
      setAdjustNotes('');
    }
  };

  // Flatten variants for inventory table
  const allVariants = allProducts.flatMap(p => 
    p.variants.map(v => ({
      ...v,
      productTitle: p.title,
      productCategory: p.category_name,
      productStatus: p.status,
    }))
  );

  const filteredVariants = allVariants.filter(v => {
    const matchSearch = v.productTitle.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      v.sku.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      v.color.toLowerCase().includes(inventorySearch.toLowerCase());

    if (!matchSearch) return false;

    if (inventoryStatusFilter === 'out_of_stock') return v.available_stock <= 0;
    if (inventoryStatusFilter === 'low_stock') return v.available_stock > 0 && v.available_stock <= v.low_stock_threshold;
    if (inventoryStatusFilter === 'in_stock') return v.available_stock > v.low_stock_threshold;

    return true;
  });

  return (
    <div className="min-h-screen bg-[#F7F4EF] py-8 text-charcoal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Top Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white rounded-3xl border border-borderSoft/80 shadow-sm">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] uppercase tracking-luxury font-bold text-mutedGrey">
                PostgreSQL • Live Inventory Authority
              </span>
            </div>
            <h1 className="font-editorial text-3xl sm:text-4xl text-charcoal mt-1">
              Atelier Management Console
            </h1>
            <p className="text-xs text-mutedGrey mt-0.5">
              Welcome, {user?.full_name} • Role: <strong className="text-charcoal uppercase">Director / Admin</strong>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link 
              to="/shop" 
              className="px-4 py-2 bg-ivory border border-borderSoft rounded-full text-xs font-semibold text-charcoal hover:bg-beige transition-colors flex items-center gap-1.5"
            >
              <span>View Storefront</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
            <button
              onClick={() => loginAs('customer')}
              className="px-4 py-2 bg-charcoal text-white rounded-full text-xs font-semibold tracking-wider uppercase hover:bg-cherry-600 transition-colors"
            >
              Switch to Customer View
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-borderSoft pb-4">
          {[
            { id: 'overview', label: 'Overview Metrics', icon: BarChart3 },
            { id: 'inventory', label: `Inventory Management (${allVariants.length} SKUs)`, icon: Layers },
            { id: 'products', label: `Product Catalogue (${allProducts.length})`, icon: Package },
            { id: 'orders', label: `Orders (${allOrders.length})`, icon: ShoppingBag },
            { id: 'audit', label: 'Inventory Audit Trail', icon: History },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-semibold tracking-wider uppercase flex items-center gap-2 transition-all ${
                  isActive 
                    ? 'bg-charcoal text-white shadow-sm' 
                    : 'bg-white/80 text-mutedGrey hover:text-charcoal hover:bg-white border border-borderSoft/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW METRICS */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-fade-in">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              
              <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-1">
                <span className="text-[11px] font-semibold tracking-luxury uppercase text-mutedGrey">Total Revenue</span>
                <p className="font-editorial text-3xl font-bold text-charcoal">
                  ₹{metrics.totalRevenue.toLocaleString('en-IN')}
                </p>
                <p className="text-[10px] text-emerald-600 font-medium">Realized from verified orders</p>
              </div>

              <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-1">
                <span className="text-[11px] font-semibold tracking-luxury uppercase text-mutedGrey">Total Orders</span>
                <p className="font-editorial text-3xl font-bold text-charcoal">
                  {metrics.totalOrders}
                </p>
                <p className="text-[10px] text-mutedGrey">{metrics.pendingOrders} pending fulfillment</p>
              </div>

              <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-1">
                <span className="text-[11px] font-semibold tracking-luxury uppercase text-mutedGrey">Total Physical Units</span>
                <p className="font-editorial text-3xl font-bold text-charcoal">
                  {metrics.totalInventoryUnits}
                </p>
                <p className="text-[10px] text-mutedGrey">Across {allVariants.length} SKUs</p>
              </div>

              <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-1">
                <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">Stock Alerts</span>
                <p className="font-editorial text-3xl font-bold text-cherry-600">
                  {metrics.lowStockVariants + metrics.outOfStockVariants}
                </p>
                <p className="text-[10px] text-amber-700">
                  {metrics.lowStockVariants} low, {metrics.outOfStockVariants} out of stock
                </p>
              </div>

            </div>

            {/* Recent Orders Overview */}
            <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-borderSoft">
                <h3 className="font-editorial text-xl text-charcoal">Recent Customer Transactions</h3>
                <button onClick={() => setActiveTab('orders')} className="text-xs text-cherry-600 font-semibold hover:underline">
                  View All Orders →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="text-[10px] uppercase tracking-luxury text-mutedGrey border-b border-borderSoft">
                    <tr>
                      <th className="py-2.5">Order ID</th>
                      <th>Customer</th>
                      <th>Destination</th>
                      <th>Total (INR)</th>
                      <th>Status</th>
                      <th>Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-borderSoft/60">
                    {metrics.recentOrders.map(o => (
                      <tr key={o.id} className="hover:bg-ivory/50">
                        <td className="py-3 font-mono font-bold">{o.order_number}</td>
                        <td>{o.shipping_address.full_name}</td>
                        <td>{o.shipping_address.city}, {o.shipping_address.state}</td>
                        <td className="font-bold text-charcoal">₹{o.total_inr.toLocaleString('en-IN')}</td>
                        <td>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800">
                            {o.status}
                          </span>
                        </td>
                        <td className="text-mutedGrey">{new Date(o.created_at).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: INVENTORY MANAGEMENT */}
        {activeTab === 'inventory' && (
          <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-6 animate-fade-in">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-borderSoft">
              <div>
                <h2 className="font-editorial text-2xl text-charcoal">Variant-Level Stock Authority</h2>
                <p className="text-xs text-mutedGrey mt-0.5">
                  Real-time PostgreSQL atomic inventory records. Every size and color possesses a unique SKU.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-mutedGrey absolute left-3 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text"
                    value={inventorySearch}
                    onChange={e => setInventorySearch(e.target.value)}
                    placeholder="Filter by SKU or Silhouette..."
                    className="pl-9 pr-3 py-1.5 bg-ivory border border-borderSoft rounded-xl text-xs text-charcoal focus:outline-none focus:border-charcoal"
                  />
                </div>

                <select
                  value={inventoryStatusFilter}
                  onChange={e => setInventoryStatusFilter(e.target.value as any)}
                  className="bg-ivory border border-borderSoft rounded-xl px-3 py-1.5 text-xs text-charcoal focus:outline-none"
                >
                  <option value="all">All Statuses</option>
                  <option value="in_stock">In Stock</option>
                  <option value="low_stock">Low Stock (≤5)</option>
                  <option value="out_of_stock">Out of Stock</option>
                </select>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="text-[10px] uppercase tracking-luxury text-mutedGrey border-b border-borderSoft">
                  <tr>
                    <th className="py-3">SKU</th>
                    <th>Product Silhouette</th>
                    <th>Size</th>
                    <th>Color</th>
                    <th className="text-center">On Hand</th>
                    <th className="text-center">Reserved</th>
                    <th className="text-center font-bold">Available</th>
                    <th>Status</th>
                    <th className="text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-borderSoft/60">
                  {filteredVariants.map((v) => {
                    const isOut = v.available_stock <= 0;
                    const isLow = v.available_stock > 0 && v.available_stock <= v.low_stock_threshold;

                    return (
                      <tr key={v.id} className="hover:bg-ivory/60 transition-colors">
                        <td className="py-3 font-mono font-bold text-charcoal">{v.sku}</td>
                        <td className="font-semibold text-charcoal max-w-xs truncate">{v.productTitle}</td>
                        <td><span className="font-bold px-2 py-0.5 rounded bg-beige/60">{v.size}</span></td>
                        <td>
                          <span className="inline-flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full border border-black/10" style={{ backgroundColor: v.color_hex }} />
                            <span>{v.color}</span>
                          </span>
                        </td>
                        <td className="text-center font-medium">{v.stock_on_hand}</td>
                        <td className="text-center text-amber-700">{v.stock_reserved}</td>
                        <td className="text-center font-bold text-charcoal text-sm">{v.available_stock}</td>
                        <td>
                          {isOut ? (
                            <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-bold text-[10px] uppercase">
                              Out of Stock
                            </span>
                          ) : isLow ? (
                            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[10px] uppercase">
                              Low Stock
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] uppercase">
                              In Stock
                            </span>
                          )}
                        </td>
                        <td className="text-right">
                          <button
                            onClick={() => {
                              setSelectedVariantForAdjust({ variant: v, productTitle: v.productTitle });
                              setAdjustModalOpen(true);
                            }}
                            className="px-3 py-1 bg-charcoal text-white rounded-lg text-[11px] font-medium hover:bg-cherry-600 transition-colors"
                          >
                            Adjust Stock
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* TAB 3: PRODUCTS CATALOGUE */}
        {activeTab === 'products' && (
          <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-6 animate-fade-in">
            <div className="flex justify-between items-center pb-4 border-b border-borderSoft">
              <div>
                <h2 className="font-editorial text-2xl text-charcoal">Curated Product Catalogue</h2>
                <p className="text-xs text-mutedGrey mt-0.5">53 authentic unique fashion pieces with full variant matrix.</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="text-[10px] uppercase tracking-luxury text-mutedGrey border-b border-borderSoft">
                  <tr>
                    <th className="py-3">Silhouette</th>
                    <th>Category</th>
                    <th>Price (INR)</th>
                    <th>Variants</th>
                    <th>Status</th>
                    <th>Featured</th>
                    <th className="text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-borderSoft/60">
                  {allProducts.map(p => (
                    <tr key={p.id} className="hover:bg-ivory/60 transition-colors">
                      <td className="py-3 flex items-center gap-3">
                        <img 
                          src={(p.images.find(i => i.is_primary) || p.images[0]).image_url} 
                          alt="" 
                          className="w-10 h-12 object-cover rounded-lg bg-beige/40 flex-shrink-0"
                        />
                        <div>
                          <p className="font-semibold text-charcoal line-clamp-1">{p.title}</p>
                          <p className="text-[10px] text-mutedGrey font-mono">slug: {p.slug}</p>
                        </div>
                      </td>
                      <td>{p.category_name}</td>
                      <td className="font-bold text-charcoal">
                        {p.sale_price_inr ? (
                          <span>₹{p.sale_price_inr} <span className="line-through text-mutedGrey text-[10px]">₹{p.price_inr}</span></span>
                        ) : (
                          <span>₹{p.price_inr}</span>
                        )}
                      </td>
                      <td>{p.variants.length} SKUs</td>
                      <td>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px] uppercase">
                          {p.status}
                        </span>
                      </td>
                      <td>{p.is_featured ? '★ Yes' : 'No'}</td>
                      <td className="text-right">
                        <Link 
                          to={`/product/${p.slug}`}
                          className="text-xs text-cherry-600 font-semibold hover:underline"
                        >
                          View Detail →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: ORDERS */}
        {activeTab === 'orders' && (
          <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-6 animate-fade-in">
            <div className="flex justify-between items-center pb-4 border-b border-borderSoft">
              <div>
                <h2 className="font-editorial text-2xl text-charcoal">Order Operations</h2>
                <p className="text-xs text-mutedGrey mt-0.5">Authoritative order records with immutable pricing snapshots.</p>
              </div>
            </div>

            <div className="space-y-4">
              {allOrders.map(order => (
                <div key={order.id} className="p-5 bg-ivory rounded-2xl border border-borderSoft/80 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-borderSoft gap-2 text-xs">
                    <div>
                      <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Order</span>
                      <p className="font-mono font-bold text-sm text-charcoal">{order.order_number}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Customer</span>
                      <p className="font-semibold text-charcoal">{order.shipping_address.full_name} ({order.shipping_address.phone})</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Total (INR)</span>
                      <p className="font-bold text-cherry-600">₹{order.total_inr.toLocaleString('en-IN')}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        value={order.status}
                        onChange={(e) => mockDb.updateOrderStatus(order.id, e.target.value as OrderStatus)}
                        className="bg-white border border-borderSoft rounded-lg px-2.5 py-1 text-xs font-semibold text-charcoal uppercase"
                      >
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {order.items.map(it => (
                      <div key={it.id} className="flex items-center gap-3 p-2 bg-white rounded-xl border border-borderSoft/60">
                        {it.image_url && <img src={it.image_url} alt="" className="w-10 h-12 object-cover rounded-lg" />}
                        <div>
                          <p className="font-semibold text-charcoal line-clamp-1">{it.product_title_snapshot}</p>
                          <p className="text-[10px] text-mutedGrey">{it.sku_snapshot} • Qty: {it.quantity} • ₹{it.total_price_inr.toLocaleString('en-IN')}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: AUDIT TRAIL */}
        {activeTab === 'audit' && (
          <div className="p-6 bg-white rounded-3xl border border-borderSoft shadow-xs space-y-6 animate-fade-in">
            <div className="pb-4 border-b border-borderSoft">
              <h2 className="font-editorial text-2xl text-charcoal">Chronological Inventory Audit Trail</h2>
              <p className="text-xs text-mutedGrey mt-0.5">
                Every stock movement, reservation, fulfillment, and manual correction is permanently recorded.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="text-[10px] uppercase tracking-luxury text-mutedGrey border-b border-borderSoft">
                  <tr>
                    <th className="py-2.5">Timestamp</th>
                    <th>SKU</th>
                    <th>Movement Type</th>
                    <th className="text-center">Delta</th>
                    <th className="text-center">On Hand After</th>
                    <th className="text-center">Reserved After</th>
                    <th>Notes & Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-borderSoft/60">
                  {movements.map(m => (
                    <tr key={m.id} className="hover:bg-ivory/50">
                      <td className="py-3 text-mutedGrey">{new Date(m.created_at).toLocaleString()}</td>
                      <td className="font-mono font-bold text-charcoal">{m.sku || m.variant_id}</td>
                      <td>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          m.movement_type === 'order_fulfillment' 
                            ? 'bg-emerald-100 text-emerald-800'
                            : m.movement_type === 'order_reservation'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {m.movement_type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className={`text-center font-bold ${m.quantity_change > 0 ? 'text-emerald-600' : 'text-cherry-600'}`}>
                        {m.quantity_change > 0 ? `+${m.quantity_change}` : m.quantity_change}
                      </td>
                      <td className="text-center font-medium">{m.stock_on_hand_after}</td>
                      <td className="text-center text-mutedGrey">{m.stock_reserved_after}</td>
                      <td className="text-charcoal max-w-sm truncate">{m.notes} {m.reference_id && `(Ref: ${m.reference_id})`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Manual Stock Adjust Modal */}
      {adjustModalOpen && selectedVariantForAdjust && (
        <div 
          className="fixed inset-0 z-50 bg-charcoal/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setAdjustModalOpen(false)}
        >
          <div 
            className="bg-ivory max-w-md w-full rounded-3xl p-6 border border-borderSoft shadow-2xl space-y-4"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-3 border-b border-borderSoft">
              <h3 className="font-editorial text-xl text-charcoal">Adjust Variant Inventory</h3>
              <button onClick={() => setAdjustModalOpen(false)} className="p-1 text-mutedGrey hover:text-charcoal">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-white rounded-xl border border-borderSoft text-xs space-y-1">
              <p className="font-bold text-charcoal">{selectedVariantForAdjust.productTitle}</p>
              <p className="text-[11px] text-mutedGrey font-mono">SKU: {selectedVariantForAdjust.variant.sku}</p>
              <p className="text-[11px]">Size: <strong>{selectedVariantForAdjust.variant.size}</strong> • Color: <strong>{selectedVariantForAdjust.variant.color}</strong></p>
              <p className="text-xs pt-1">Current On Hand: <strong>{selectedVariantForAdjust.variant.stock_on_hand}</strong> • Available: <strong>{selectedVariantForAdjust.variant.available_stock}</strong></p>
            </div>

            <form onSubmit={handleExecuteStockAdjust} className="space-y-4 text-xs">
              <div>
                <label className="uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  Movement Type
                </label>
                <select
                  value={adjustType}
                  onChange={e => setAdjustType(e.target.value as any)}
                  className="w-full bg-white border border-borderSoft rounded-xl px-3 py-2 text-xs text-charcoal"
                >
                  <option value="manual_addition">Manual Addition (Warehouse Restock)</option>
                  <option value="manual_deduction">Manual Deduction (Damaged / Sample)</option>
                  <option value="inventory_correction">Inventory Physical Audit Correction</option>
                  <option value="return_restock">Customer Return Restock</option>
                </select>
              </div>

              <div>
                <label className="uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  Quantity Adjustment Units
                </label>
                <input 
                  type="number"
                  min={1}
                  required
                  value={adjustDelta}
                  onChange={e => setAdjustDelta(Number(e.target.value))}
                  className="w-full bg-white border border-borderSoft rounded-xl px-3 py-2 text-xs text-charcoal"
                />
              </div>

              <div>
                <label className="uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  Audit Reason / Notes *
                </label>
                <textarea 
                  required
                  rows={2}
                  value={adjustNotes}
                  onChange={e => setAdjustNotes(e.target.value)}
                  placeholder="e.g. Received new shipment batch #408 from atelier..."
                  className="w-full bg-white border border-borderSoft rounded-xl p-3 text-xs text-charcoal"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAdjustModalOpen(false)}
                  className="flex-1 py-2.5 border border-charcoal rounded-xl text-charcoal font-semibold uppercase tracking-luxury"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-charcoal text-white rounded-xl font-semibold uppercase tracking-luxury hover:bg-cherry-600 transition-colors shadow-sm"
                >
                  Commit Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
