import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Check } from 'lucide-react';
import { Product, ProductVariant } from '../../types';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  const primaryImage = product.images.find(img => img.is_primary) || product.images[0];
  const secondaryImage = product.images[1] || primaryImage;
  const isWishlisted = isInWishlist(product.id);

  // Group unique colors
  const uniqueColors = Array.from(new Set(product.variants.map(v => v.color_hex)));

  const handleQuickAdd = (variant: ProductVariant, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const ok = addToCart(product, variant, 1);
    if (ok) {
      setAddedSuccess(true);
      setTimeout(() => {
        setAddedSuccess(false);
        setShowQuickAdd(false);
      }, 1200);
    }
  };

  return (
    <div 
      className="group relative flex flex-col transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowQuickAdd(false);
      }}
    >
      {/* Product Image Frame */}
      <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-beige/30 border border-borderSoft/40 transition-shadow group-hover:shadow-soft-luxury">
        <Link to={`/product/${product.slug}`} className="block w-full h-full">
          <img 
            src={isHovered && secondaryImage ? secondaryImage.image_url : primaryImage.image_url} 
            alt={product.title}
            className="w-full h-full object-cover object-center transition-all duration-700 group-hover:scale-105"
            loading="lazy"
          />
        </Link>

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none">
          {product.is_new_arrival && (
            <span className="bg-white/90 backdrop-blur-md text-charcoal text-[10px] font-semibold tracking-luxury uppercase px-2.5 py-1 rounded-full shadow-sm">
              New In
            </span>
          )}
          {product.sale_price_inr && (
            <span className="bg-cherry-600 text-white text-[10px] font-bold tracking-luxury uppercase px-2.5 py-1 rounded-full shadow-sm">
              Sale
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2.5 rounded-full backdrop-blur-md transition-all shadow-sm ${
            isWishlisted 
              ? 'bg-cherry-600 text-white' 
              : 'bg-white/80 hover:bg-white text-charcoal hover:text-cherry-600'
          }`}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : 'stroke-[1.5]'}`} />
        </button>

        {/* Quick Add Overlay on Hover */}
        <div className={`absolute bottom-3 inset-x-3 transition-all duration-300 ${isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'}`}>
          {!showQuickAdd ? (
            <button
              onClick={(e) => {
                e.preventDefault();
                setShowQuickAdd(true);
              }}
              className="w-full py-2.5 px-4 bg-charcoal/90 hover:bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-xl backdrop-blur-md shadow-lg flex items-center justify-center gap-2 transition-all"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Quick Add</span>
            </button>
          ) : (
            <div className="bg-white/95 backdrop-blur-md p-3 rounded-xl border border-borderSoft shadow-xl animate-fade-in">
              {addedSuccess ? (
                <div className="flex items-center justify-center gap-1.5 py-1 text-xs font-semibold text-charcoal">
                  <Check className="w-4 h-4 text-cherry-600" />
                  <span>Added to Bag!</span>
                </div>
              ) : (
                <div>
                  <p className="text-[10px] text-mutedGrey uppercase tracking-wider mb-2 font-medium text-center">
                    Select Size:
                  </p>
                  <div className="flex flex-wrap gap-1.5 justify-center">
                    {product.variants.map((v) => (
                      <button
                        key={v.id}
                        disabled={v.available_stock <= 0}
                        onClick={(e) => handleQuickAdd(v, e)}
                        className={`text-[11px] font-semibold px-2.5 py-1 rounded-md border transition-all ${
                          v.available_stock > 0
                            ? 'border-borderSoft hover:border-charcoal hover:bg-charcoal hover:text-white'
                            : 'border-dashed border-gray-300 text-gray-300 cursor-not-allowed line-through'
                        }`}
                      >
                        {v.size}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Product Information */}
      <div className="pt-3 pb-1 flex flex-col flex-1 justify-between">
        <div>
          {/* Color Indicators */}
          <div className="flex items-center gap-1 mb-1.5">
            {uniqueColors.slice(0, 4).map((hex, i) => (
              <span 
                key={i} 
                className="w-2.5 h-2.5 rounded-full border border-black/10 inline-block shadow-xs"
                style={{ backgroundColor: hex }}
              />
            ))}
            {uniqueColors.length > 4 && (
              <span className="text-[10px] text-mutedGrey">+{uniqueColors.length - 4}</span>
            )}
          </div>

          <Link to={`/product/${product.slug}`}>
            <h3 className="text-xs sm:text-sm font-medium tracking-wide uppercase text-charcoal line-clamp-1 hover:text-cherry-600 transition-colors">
              {product.title}
            </h3>
          </Link>
          
          <p className="text-[11px] text-mutedGrey line-clamp-1 mt-0.5 font-light">
            {product.category_name}
          </p>
        </div>

        {/* Pricing */}
        <div className="mt-2 flex items-baseline gap-2">
          {product.sale_price_inr ? (
            <>
              <span className="text-xs sm:text-sm font-bold text-cherry-600">
                ₹{product.sale_price_inr.toLocaleString('en-IN')}
              </span>
              <span className="text-[11px] text-mutedGrey line-through font-light">
                ₹{product.price_inr.toLocaleString('en-IN')}
              </span>
            </>
          ) : (
            <span className="text-xs sm:text-sm font-bold text-charcoal">
              ₹{product.price_inr.toLocaleString('en-IN')}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
