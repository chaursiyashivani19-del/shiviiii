import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import confetti from 'canvas-confetti';
import { 
  ShieldCheck, 
  CreditCard, 
  Lock, 
  CheckCircle2, 
  ArrowLeft, 
  Sparkles, 
  AlertCircle 
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { mockDb } from '../services/supabase';
import { DemoPaymentProvider, RazorpayPaymentProvider } from '../services/payment';
import { Address, Order, OrderItem } from '../types';

export const CheckoutPage: React.FC = () => {
  const { items, subtotal, discountAmount, shippingFee, total, appliedCoupon, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Form State
  const [fullName, setFullName] = useState(user?.full_name || 'Clara Delacroix');
  const [email, setEmail] = useState(user?.email || 'clara.atelier@example.com');
  const [phone, setPhone] = useState(user?.phone || '+91 98765 43210');
  const [streetAddress, setStreetAddress] = useState('42 Rue Des Rêves, Bandra West');
  const [city, setCity] = useState('Mumbai');
  const [stateName, setStateName] = useState('Maharashtra');
  const [postalCode, setPostalCode] = useState('400050');
  const [paymentProviderType, setPaymentProviderType] = useState<'demo' | 'razorpay'>('demo');

  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  if (items.length === 0 && !confirmedOrder) {
    return (
      <div className="py-24 max-w-md mx-auto text-center px-4 space-y-4">
        <span className="text-5xl">🛍️</span>
        <h2 className="font-editorial text-2xl text-charcoal">Your bag is empty</h2>
        <p className="text-xs text-mutedGrey">
          Please select at least one garment before proceeding to checkout.
        </p>
        <Link 
          to="/shop" 
          className="inline-block px-6 py-3 bg-charcoal text-white text-xs uppercase tracking-luxury rounded-full"
        >
          Return to Catalogue
        </Link>
      </div>
    );
  }

  // Handle Complete Checkout Flow with Atomic Inventory Locks
  const handleProceedToPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!fullName || !email || !phone || !streetAddress || !city || !postalCode) {
      setErrorMessage('Please fill in all required shipping address fields.');
      return;
    }

    setIsProcessing(true);

    try {
      const tempOrderNumber = `EA-2026-${Math.floor(1000 + Math.random() * 9000)}`;

      // Step 1: ATOMIC STOCK RESERVATION
      // Acquire exclusive locks & verify sufficient stock on all items
      for (const item of items) {
        const reservedOk = mockDb.reserveStockAtomic(item.variant_id, item.quantity, tempOrderNumber);
        if (!reservedOk) {
          throw new Error(`Insufficient stock for "${item.product.title}" (${item.variant.size}). Please adjust quantity.`);
        }
      }

      // Prepare Order snapshot items
      const orderItems: OrderItem[] = items.map((item, idx) => ({
        id: `oi-${Date.now()}-${idx}`,
        order_id: '',
        product_id: item.product.id,
        variant_id: item.variant.id,
        product_title_snapshot: item.product.title,
        sku_snapshot: item.variant.sku,
        size_snapshot: item.variant.size,
        color_snapshot: item.variant.color,
        unit_price_inr_snapshot: item.product.sale_price_inr ?? item.product.price_inr,
        quantity: item.quantity,
        total_price_inr: (item.product.sale_price_inr ?? item.product.price_inr) * item.quantity,
        image_url: (item.product.images.find(img => img.is_primary) || item.product.images[0]).image_url,
      }));

      const shippingAddress: Address = {
        id: `addr-${Date.now()}`,
        user_id: user?.id,
        full_name: fullName,
        phone,
        street_address: streetAddress,
        city,
        state: stateName,
        postal_code: postalCode,
        country: 'India',
        is_default: true,
      };

      const orderData: Omit<Order, 'id' | 'created_at'> = {
        order_number: tempOrderNumber,
        user_id: user?.id,
        guest_email: email,
        shipping_address: shippingAddress,
        subtotal_inr: subtotal,
        discount_amount_inr: discountAmount,
        shipping_fee_inr: shippingFee,
        total_inr: total,
        discount_code_applied: appliedCoupon || undefined,
        status: 'confirmed',
        items: orderItems,
      };

      // Step 2: PROCESS PAYMENT
      const provider = paymentProviderType === 'razorpay'
        ? new RazorpayPaymentProvider()
        : new DemoPaymentProvider();

      await provider.processPayment({
        order: { ...orderData, id: 'temp-id', created_at: new Date().toISOString() },
        onSuccess: (paymentDetails) => {
          // Step 3: ATOMIC STOCK COMMIT & DEDUCTION (Payment Verified)
          for (const item of items) {
            mockDb.commitStockDeduction(item.variant_id, item.quantity, tempOrderNumber);
          }

          // Step 4: Persist Order in Authoritative Database
          const createdOrder = mockDb.createOrder(orderData);
          setConfirmedOrder(createdOrder);
          clearCart();
          setIsProcessing(false);

          // Confetti celebration
          try {
            confetti({
              particleCount: 90,
              spread: 60,
              origin: { y: 0.6 },
              colors: ['#EEA2B2', '#C92A42', '#FAF6F0', '#1A1A1A'],
            });
          } catch {
            // ignore if canvas not supported
          }
        },
        onError: (err) => {
          // Step 3 (Failure): Release reservations
          for (const item of items) {
            mockDb.releaseStockReservation(item.variant_id, item.quantity, tempOrderNumber);
          }
          setErrorMessage(err || 'Payment processing could not be completed.');
          setIsProcessing(false);
        },
      });

    } catch (err) {
      setErrorMessage((err as Error).message);
      setIsProcessing(false);
    }
  };

  // SUCCESS CONFIRMATION VIEW
  if (confirmedOrder) {
    return (
      <div className="py-16 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 bg-white/90 rounded-3xl border border-borderSoft/80 shadow-2xl text-center space-y-6 animate-fade-in">
          
          <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
          </div>

          <div className="space-y-1">
            <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">
              Payment Confirmed & Verified
            </span>
            <h1 className="font-editorial text-3xl sm:text-4xl text-charcoal">
              Merci, {confirmedOrder.shipping_address.full_name}
            </h1>
            <p className="text-xs sm:text-sm text-mutedGrey font-light">
              Your garments have been reserved in the warehouse and queued for hand inspection.
            </p>
          </div>

          <div className="p-4 bg-ivory rounded-2xl border border-borderSoft/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div>
              <span className="text-[10px] text-mutedGrey uppercase tracking-luxury block">Order Number</span>
              <strong className="font-mono text-sm text-charcoal">{confirmedOrder.order_number}</strong>
            </div>
            <div>
              <span className="text-[10px] text-mutedGrey uppercase tracking-luxury block">Amount Paid (INR)</span>
              <strong className="text-sm text-cherry-600 font-bold">₹{confirmedOrder.total_inr.toLocaleString('en-IN')}</strong>
            </div>
            <div>
              <span className="text-[10px] text-mutedGrey uppercase tracking-luxury block">Status</span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold uppercase text-[10px]">
                {confirmedOrder.status}
              </span>
            </div>
          </div>

          {/* Purchased Items List */}
          <div className="space-y-3 text-left">
            <h3 className="text-xs uppercase tracking-luxury font-semibold text-charcoal pb-2 border-b border-borderSoft">
              Archived Order Items
            </h3>
            {confirmedOrder.items.map((it) => (
              <div key={it.id} className="flex items-center justify-between text-xs py-2 border-b border-borderSoft/40">
                <div className="flex items-center gap-3">
                  {it.image_url && (
                    <img src={it.image_url} alt="" className="w-10 h-12 object-cover rounded-lg" />
                  )}
                  <div>
                    <p className="font-semibold text-charcoal">{it.product_title_snapshot}</p>
                    <p className="text-[11px] text-mutedGrey">{it.size_snapshot} • {it.color_snapshot} • Qty: {it.quantity}</p>
                  </div>
                </div>
                <span className="font-bold text-charcoal">₹{it.total_price_inr.toLocaleString('en-IN')}</span>
              </div>
            ))}
          </div>

          <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/account"
              className="px-6 py-3 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-cherry-600 transition-colors"
            >
              View Order in Account
            </Link>
            <Link
              to="/shop"
              className="px-6 py-3 border border-charcoal text-charcoal text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-beige transition-colors"
            >
              Continue Browsing
            </Link>
          </div>

        </div>
      </div>
    );
  }

  return (
    <div className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      <div className="mb-8">
        <Link to="/cart" className="inline-flex items-center gap-1.5 text-xs text-mutedGrey hover:text-charcoal transition-colors uppercase tracking-wider mb-2">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Return to Bag</span>
        </Link>
        <h1 className="font-editorial text-3xl sm:text-5xl text-charcoal">
          Atelier Checkout
        </h1>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-red-700 text-xs">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleProceedToPayment} className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Shipping Address & Payment Selection */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Shipping Form */}
          <div className="p-6 sm:p-8 bg-white/80 rounded-3xl border border-borderSoft/80 shadow-soft-luxury space-y-5">
            <h2 className="font-editorial text-xl text-charcoal tracking-wide pb-2 border-b border-borderSoft">
              1. Delivery Destination
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  Full Name *
                </label>
                <input 
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
                />
              </div>

              <div>
                <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  Email for Confirmation *
                </label>
                <input 
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                Phone Number (for Courier SMS Tracking) *
              </label>
              <input 
                type="tel"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
              />
            </div>

            <div>
              <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                Street Address *
              </label>
              <input 
                type="text"
                required
                value={streetAddress}
                onChange={e => setStreetAddress(e.target.value)}
                placeholder="Apartment, suite, unit, building, floor, street..."
                className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  City *
                </label>
                <input 
                  type="text"
                  required
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
                />
              </div>
              <div>
                <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  State *
                </label>
                <input 
                  type="text"
                  required
                  value={stateName}
                  onChange={e => setStateName(e.target.value)}
                  className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
                />
              </div>
              <div>
                <label className="text-[11px] uppercase tracking-luxury font-semibold text-charcoal block mb-1">
                  PIN Code *
                </label>
                <input 
                  type="text"
                  required
                  value={postalCode}
                  onChange={e => setPostalCode(e.target.value)}
                  className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
                />
              </div>
            </div>

          </div>

          {/* Payment Provider Selection */}
          <div className="p-6 sm:p-8 bg-white/80 rounded-3xl border border-borderSoft/80 shadow-soft-luxury space-y-4">
            <h2 className="font-editorial text-xl text-charcoal tracking-wide pb-2 border-b border-borderSoft">
              2. Payment Provider Selection
            </h2>

            <div className="space-y-3">
              <label 
                className={`p-4 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  paymentProviderType === 'demo'
                    ? 'border-charcoal bg-beige/30 shadow-xs'
                    : 'border-borderSoft bg-ivory hover:border-charcoal/40'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input 
                    type="radio" 
                    name="paymentProvider" 
                    checked={paymentProviderType === 'demo'}
                    onChange={() => setPaymentProviderType('demo')}
                    className="accent-charcoal"
                  />
                  <div>
                    <span className="text-xs font-semibold text-charcoal flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cherry-600" />
                      Instant Portfolio Demo Checkout
                    </span>
                    <p className="text-[11px] text-mutedGrey mt-0.5">
                      Simulates authentic Razorpay authorization & verifies atomic reservation instantly.
                    </p>
                  </div>
                </div>
                <span className="text-[10px] uppercase font-bold tracking-luxury px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded">
                  Recommended
                </span>
              </label>

              <label 
                className={`p-4 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  paymentProviderType === 'razorpay'
                    ? 'border-charcoal bg-beige/30 shadow-xs'
                    : 'border-borderSoft bg-ivory hover:border-charcoal/40'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input 
                    type="radio" 
                    name="paymentProvider" 
                    checked={paymentProviderType === 'razorpay'}
                    onChange={() => setPaymentProviderType('razorpay')}
                    className="accent-charcoal"
                  />
                  <div>
                    <span className="text-xs font-semibold text-charcoal flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-charcoal" />
                      Live Razorpay Gateway (India UPI / Cards / NetBanking)
                    </span>
                    <p className="text-[11px] text-mutedGrey mt-0.5">
                      Production mode for live merchant credentials.
                    </p>
                  </div>
                </div>
              </label>
            </div>
          </div>

        </div>

        {/* Right Column: Order Summary & Place Order Button */}
        <div className="lg:col-span-5">
          <div className="p-6 sm:p-8 bg-white/80 rounded-3xl border border-borderSoft/80 shadow-soft-luxury space-y-6 sticky top-28">
            <h2 className="font-editorial text-xl text-charcoal tracking-wide pb-2 border-b border-borderSoft">
              Order Snapshot
            </h2>

            {/* Items mini list */}
            <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
              {items.map((item) => {
                const currentPrice = item.product.sale_price_inr ?? item.product.price_inr;
                const img = (item.product.images.find(i => i.is_primary) || item.product.images[0]).image_url;

                return (
                  <div key={item.variant_id} className="flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5">
                      <img src={img} alt="" className="w-10 h-12 object-cover rounded-lg bg-beige/30" />
                      <div>
                        <p className="font-semibold text-charcoal line-clamp-1">{item.product.title}</p>
                        <p className="text-[10px] text-mutedGrey">{item.variant.size} • {item.variant.color} • Qty: {item.quantity}</p>
                      </div>
                    </div>
                    <span className="font-bold text-charcoal">
                      ₹{(currentPrice * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Price Calculations */}
            <div className="space-y-2 text-xs pt-3 border-t border-borderSoft">
              <div className="flex justify-between text-mutedGrey">
                <span>Subtotal</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-cherry-600 font-semibold">
                  <span>Discount ({appliedCoupon})</span>
                  <span>-₹{discountAmount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between text-mutedGrey">
                <span>Domestic Express Shipping</span>
                <span>{shippingFee === 0 ? 'Complimentary' : `₹${shippingFee}`}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-charcoal pt-3 border-t border-borderSoft">
                <span>Payable Total</span>
                <span>₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Place Order CTA */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-4 bg-charcoal hover:bg-cherry-600 disabled:bg-gray-400 text-white text-xs uppercase tracking-luxury font-semibold rounded-full shadow-lg transition-all flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <span>Executing Atomic Stock Lock...</span>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Authorize & Pay ₹{total.toLocaleString('en-IN')}</span>
                </>
              )}
            </button>

            <div className="text-[10px] text-center text-mutedGrey tracking-wider uppercase">
              <span className="flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Atomic Concurrency Safe • Zero Negative Stock
              </span>
            </div>

          </div>
        </div>

      </form>

    </div>
  );
};
