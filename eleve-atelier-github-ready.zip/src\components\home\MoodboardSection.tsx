import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Tag, Sparkles, ArrowRight } from 'lucide-react';

interface PinItem {
  id: string;
  imageUrl: string;
  aspect: string;
  title: string;
  aesthetic: string;
  linkedProductSlug: string;
  productPrice: number;
}

const PINS: PinItem[] = [
  {
    id: 'pin-1',
    imageUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[3/4]',
    title: 'The Coquette Ribbon Bustier & Pearls',
    aesthetic: 'Soft Balletcore',
    linkedProductSlug: 'cherry-embroidered-bow-corset',
    productPrice: 3899,
  },
  {
    id: 'pin-2',
    imageUrl: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[4/5]',
    title: 'Mirror Chrome Mini Evening Box',
    aesthetic: 'Futuristic Luxury',
    linkedProductSlug: 'the-mini-ribbon-bow-metallic-clutch',
    productPrice: 4999,
  },
  {
    id: 'pin-3',
    imageUrl: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[9/16]',
    title: '22mm Mulberry Bias Silk Slip',
    aesthetic: '90s Archival Slip',
    linkedProductSlug: 'juliette-silk-slip-maxi-dress',
    productPrice: 7499,
  },
  {
    id: 'pin-4',
    imageUrl: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[3/4]',
    title: 'Distressed Biker Leather Over Lace',
    aesthetic: 'Soft Armor Rebellious',
    linkedProductSlug: 'distressed-vintage-leather-biker-bomber',
    productPrice: 8499,
  },
  {
    id: 'pin-5',
    imageUrl: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[4/5]',
    title: 'Knife Pleat Bubble Taffeta Cloud',
    aesthetic: 'Gen-Z Architectural',
    linkedProductSlug: 'giselle-pleated-bubble-mini-skirt',
    productPrice: 3299,
  },
  {
    id: 'pin-6',
    imageUrl: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80',
    aspect: 'aspect-[3/4]',
    title: 'Pastel Tweed Tailored Duo',
    aesthetic: 'Parisian Neoclassic',
    linkedProductSlug: 'valerie-boucle-tweed-vest-and-skirt-set',
    productPrice: 7999,
  },
];

export const MoodboardSection: React.FC = () => {
  const [activePin, setActivePin] = useState<string | null>(null);

  return (
    <section id="moodboard" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Section 06 • Visual Discovery</span>
          </div>
          <h2 className="font-editorial text-3xl sm:text-5xl text-charcoal">
            The Pinterest Girl Moodboard
          </h2>
          <p className="text-xs sm:text-sm text-mutedGrey max-w-lg font-light">
            Every inspiration frame links directly to its authentic silhouette in our catalogue.
            Tap any tag to inspect and shop.
          </p>
        </div>

        <Link
          to="/shop"
          className="mt-6 md:mt-0 inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-charcoal hover:text-cherry-600 transition-colors"
        >
          <span>Explore All 53 Mood Pieces</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      {/* Masonry Columns */}
      <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
        {PINS.map((pin) => (
          <div 
            key={pin.id}
            className="break-inside-avoid group relative rounded-3xl overflow-hidden bg-beige/30 border border-borderSoft/60 shadow-sm hover:shadow-soft-luxury transition-all duration-500 cursor-pointer"
            onClick={() => setActivePin(activePin === pin.id ? null : pin.id)}
          >
            <img 
              src={pin.imageUrl} 
              alt={pin.title}
              className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
            />

            {/* Aesthetic Tag Pill */}
            <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-semibold tracking-luxury uppercase text-charcoal shadow-sm">
              {pin.aesthetic}
            </div>

            {/* Shoppable Hotspot Tag */}
            <div className="absolute bottom-4 left-4 right-4 bg-ivory/95 backdrop-blur-md p-3.5 rounded-2xl border border-borderSoft/80 shadow-lg flex items-center justify-between transition-all">
              <div>
                <p className="text-xs font-semibold text-charcoal uppercase tracking-wide line-clamp-1">
                  {pin.title}
                </p>
                <p className="text-[11px] font-bold text-cherry-600 mt-0.5">
                  ₹{pin.productPrice.toLocaleString('en-IN')}
                </p>
              </div>

              <Link
                to={`/product/${pin.linkedProductSlug}`}
                onClick={(e) => e.stopPropagation()}
                className="p-2 rounded-xl bg-charcoal hover:bg-cherry-600 text-white transition-colors"
                title="View Silhouette"
              >
                <Tag className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        ))}
      </div>

    </section>
  );
};
