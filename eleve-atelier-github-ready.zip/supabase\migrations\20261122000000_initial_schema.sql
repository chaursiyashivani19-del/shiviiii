-- ==============================================================================
-- ÉLÉVÉ ATELIER — MASTER DATABASE ARCHITECTURE MIGRATION
-- Authoritative PostgreSQL Schema with RLS, Atomic RPCs, and Audit Logs
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES TABLE (linked to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    avatar_url TEXT,
    phone TEXT,
    role TEXT DEFAULT 'customer' CHECK (role IN ('customer', 'admin', 'inventory_manager')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. USER ROLES TABLE
CREATE TABLE IF NOT EXISTS public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('customer', 'admin', 'inventory_manager')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, role)
);

-- 3. CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT,
    image_url TEXT,
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
    price_inr NUMERIC(10,2) NOT NULL CHECK (price_inr >= 0),
    sale_price_inr NUMERIC(10,2) CHECK (sale_price_inr IS NULL OR sale_price_inr >= 0),
    status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'archived')) DEFAULT 'published',
    is_featured BOOLEAN DEFAULT false,
    is_new_arrival BOOLEAN DEFAULT false,
    editorial_quote TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. PRODUCT VARIANTS TABLE (Variant-level inventory with SKU and available_stock)
CREATE TABLE IF NOT EXISTS public.product_variants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    sku TEXT UNIQUE NOT NULL,
    size TEXT NOT NULL,
    color TEXT NOT NULL,
    color_hex TEXT NOT NULL,
    stock_on_hand INT NOT NULL DEFAULT 0 CHECK (stock_on_hand >= 0),
    stock_reserved INT NOT NULL DEFAULT 0 CHECK (stock_reserved >= 0),
    available_stock INT GENERATED ALWAYS AS (stock_on_hand - stock_reserved) STORED,
    low_stock_threshold INT NOT NULL DEFAULT 5 CHECK (low_stock_threshold >= 0),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(product_id, size, color)
);

-- 6. PRODUCT IMAGES TABLE
CREATE TABLE IF NOT EXISTS public.product_images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    color TEXT,
    image_url TEXT NOT NULL,
    alt_text TEXT,
    display_order INT DEFAULT 0,
    is_primary BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. CARTS & CART ITEMS
CREATE TABLE IF NOT EXISTS public.carts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    session_token TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.cart_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cart_id UUID NOT NULL REFERENCES public.carts(id) ON DELETE CASCADE,
    variant_id UUID NOT NULL REFERENCES public.product_variants(id) ON DELETE RESTRICT,
    quantity INT NOT NULL CHECK (quantity > 0),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(cart_id, variant_id)
);

-- 8. WISHLISTS & WISHLIST ITEMS
CREATE TABLE IF NOT EXISTS public.wishlists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id)
);

CREATE TABLE IF NOT EXISTS public.wishlist_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wishlist_id UUID NOT NULL REFERENCES public.wishlists(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(wishlist_id, product_id)
);

-- 9. ADDRESSES
CREATE TABLE IF NOT EXISTS public.addresses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    street_address TEXT NOT NULL,
    apartment TEXT,
    city TEXT NOT NULL,
    state TEXT NOT NULL,
    postal_code TEXT NOT NULL,
    country TEXT DEFAULT 'India',
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. DISCOUNT CODES
CREATE TABLE IF NOT EXISTS public.discount_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    discount_percent NUMERIC(5,2) CHECK (discount_percent IS NULL OR (discount_percent > 0 AND discount_percent <= 100)),
    fixed_amount_inr NUMERIC(10,2) CHECK (fixed_amount_inr IS NULL OR fixed_amount_inr >= 0),
    min_order_amount_inr NUMERIC(10,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    starts_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    usage_limit INT,
    times_used INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number TEXT UNIQUE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    guest_email TEXT,
    shipping_address JSONB NOT NULL,
    subtotal_inr NUMERIC(10,2) NOT NULL CHECK (subtotal_inr >= 0),
    discount_amount_inr NUMERIC(10,2) DEFAULT 0 CHECK (discount_amount_inr >= 0),
    shipping_fee_inr NUMERIC(10,2) DEFAULT 0 CHECK (shipping_fee_inr >= 0),
    total_inr NUMERIC(10,2) NOT NULL CHECK (total_inr >= 0),
    discount_code_applied TEXT,
    status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled')) DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. ORDER ITEMS TABLE (Immutable historical snapshot)
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    variant_id UUID REFERENCES public.product_variants(id) ON DELETE SET NULL,
    product_title_snapshot TEXT NOT NULL,
    sku_snapshot TEXT NOT NULL,
    size_snapshot TEXT NOT NULL,
    color_snapshot TEXT NOT NULL,
    unit_price_inr_snapshot NUMERIC(10,2) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    total_price_inr NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    provider TEXT NOT NULL CHECK (provider IN ('razorpay', 'demo_mock')),
    provider_order_id TEXT NOT NULL,
    provider_payment_id TEXT,
    provider_signature TEXT,
    amount_inr NUMERIC(10,2) NOT NULL CHECK (amount_inr >= 0),
    currency TEXT DEFAULT 'INR',
    status TEXT NOT NULL CHECK (status IN ('pending', 'authorized', 'captured', 'failed', 'refunded')) DEFAULT 'pending',
    error_message TEXT,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. INVENTORY MOVEMENTS AUDIT LOG
CREATE TABLE IF NOT EXISTS public.inventory_movements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    variant_id UUID NOT NULL REFERENCES public.product_variants(id) ON DELETE CASCADE,
    movement_type TEXT NOT NULL CHECK (movement_type IN (
        'initial_stock',
        'manual_addition',
        'manual_deduction',
        'order_reservation',
        'order_fulfillment',
        'order_cancellation',
        'return_restock',
        'inventory_correction'
    )),
    quantity_change INT NOT NULL,
    stock_on_hand_after INT NOT NULL,
    stock_reserved_after INT NOT NULL,
    reference_id TEXT,
    notes TEXT,
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. NEWSLETTER SUBSCRIBERS TABLE
CREATE TABLE IF NOT EXISTS public.newsletter_subscribers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT true,
    source TEXT DEFAULT 'footer_form',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- INDEXES FOR MAXIMUM QUERY PERFORMANCE
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON public.products(status);
CREATE INDEX IF NOT EXISTS idx_products_featured ON public.products(is_featured);
CREATE INDEX IF NOT EXISTS idx_products_new_arrival ON public.products(is_new_arrival);
CREATE INDEX IF NOT EXISTS idx_product_variants_product ON public.product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_product_variants_sku ON public.product_variants(sku);
CREATE INDEX IF NOT EXISTS idx_product_images_product ON public.product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_inventory_movements_variant ON public.inventory_movements(variant_id);

-- ==============================================================================
-- ATOMIC BUSINESS LOGIC FUNCTIONS (Concurrency & Stock Protection)
-- ==============================================================================

-- Atomic Stock Reservation with PostgreSQL row locking (FOR UPDATE)
CREATE OR REPLACE FUNCTION public.reserve_stock_atomic(
    p_variant_id UUID,
    p_quantity INT,
    p_order_id TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_stock_on_hand INT;
    v_stock_reserved INT;
    v_available INT;
BEGIN
    -- Acquire exclusive row lock on variant
    SELECT stock_on_hand, stock_reserved
    INTO v_stock_on_hand, v_stock_reserved
    FROM public.product_variants
    WHERE id = p_variant_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Variant not found: %', p_variant_id;
    END IF;

    v_available := v_stock_on_hand - v_stock_reserved;

    IF v_available < p_quantity THEN
        RETURN FALSE; -- Insufficient available stock
    END IF;

    -- Update reserved stock
    UPDATE public.product_variants
    SET stock_reserved = stock_reserved + p_quantity,
        updated_at = NOW()
    WHERE id = p_variant_id;

    -- Record inventory audit trail
    INSERT INTO public.inventory_movements (
        variant_id,
        movement_type,
        quantity_change,
        stock_on_hand_after,
        stock_reserved_after,
        reference_id,
        notes
    ) VALUES (
        p_variant_id,
        'order_reservation',
        p_quantity,
        v_stock_on_hand,
        v_stock_reserved + p_quantity,
        p_order_id,
        'Atomic reservation prior to payment confirmation'
    );

    RETURN TRUE;
END;
$$;

-- Atomic Release of Reserved Stock (on cancelled or expired checkout)
CREATE OR REPLACE FUNCTION public.release_stock_reservation(
    p_variant_id UUID,
    p_quantity INT,
    p_order_id TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_stock_on_hand INT;
    v_stock_reserved INT;
BEGIN
    SELECT stock_on_hand, stock_reserved
    INTO v_stock_on_hand, v_stock_reserved
    FROM public.product_variants
    WHERE id = p_variant_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Variant not found: %', p_variant_id;
    END IF;

    UPDATE public.product_variants
    SET stock_reserved = GREATEST(0, stock_reserved - p_quantity),
        updated_at = NOW()
    WHERE id = p_variant_id;

    INSERT INTO public.inventory_movements (
        variant_id,
        movement_type,
        quantity_change,
        stock_on_hand_after,
        stock_reserved_after,
        reference_id,
        notes
    ) VALUES (
        p_variant_id,
        'order_cancellation',
        -p_quantity,
        v_stock_on_hand,
        GREATEST(0, v_stock_reserved - p_quantity),
        p_order_id,
        'Released reservation due to cancellation or expiration'
    );

    RETURN TRUE;
END;
$$;

-- Commit Reserved Stock to Fulfilled Stock Deduction (upon verified payment)
CREATE OR REPLACE FUNCTION public.commit_stock_deduction(
    p_variant_id UUID,
    p_quantity INT,
    p_order_id TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_stock_on_hand INT;
    v_stock_reserved INT;
BEGIN
    SELECT stock_on_hand, stock_reserved
    INTO v_stock_on_hand, v_stock_reserved
    FROM public.product_variants
    WHERE id = p_variant_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Variant not found: %', p_variant_id;
    END IF;

    UPDATE public.product_variants
    SET stock_on_hand = GREATEST(0, stock_on_hand - p_quantity),
        stock_reserved = GREATEST(0, stock_reserved - p_quantity),
        updated_at = NOW()
    WHERE id = p_variant_id;

    INSERT INTO public.inventory_movements (
        variant_id,
        movement_type,
        quantity_change,
        stock_on_hand_after,
        stock_reserved_after,
        reference_id,
        notes
    ) VALUES (
        p_variant_id,
        'order_fulfillment',
        -p_quantity,
        GREATEST(0, v_stock_on_hand - p_quantity),
        GREATEST(0, v_stock_reserved - p_quantity),
        p_order_id,
        'Payment verified: inventory fulfilled and deducted'
    );

    RETURN TRUE;
END;
$$;

-- Manual Stock Adjustment by Administrator / Inventory Manager
CREATE OR REPLACE FUNCTION public.adjust_stock_manual(
    p_variant_id UUID,
    p_delta INT,
    p_type TEXT,
    p_notes TEXT,
    p_user_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_stock_on_hand INT;
    v_stock_reserved INT;
    v_new_stock INT;
BEGIN
    SELECT stock_on_hand, stock_reserved
    INTO v_stock_on_hand, v_stock_reserved
    FROM public.product_variants
    WHERE id = p_variant_id
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Variant not found: %', p_variant_id;
    END IF;

    v_new_stock := v_stock_on_hand + p_delta;
    IF v_new_stock < 0 THEN
        RAISE EXCEPTION 'Cannot adjust stock below 0. Current on hand: %', v_stock_on_hand;
    END IF;

    UPDATE public.product_variants
    SET stock_on_hand = v_new_stock,
        updated_at = NOW()
    WHERE id = p_variant_id;

    INSERT INTO public.inventory_movements (
        variant_id,
        movement_type,
        quantity_change,
        stock_on_hand_after,
        stock_reserved_after,
        notes,
        created_by
    ) VALUES (
        p_variant_id,
        p_type,
        p_delta,
        v_new_stock,
        v_stock_reserved,
        p_notes,
        p_user_id
    );

    RETURN TRUE;
END;
$$;

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.carts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wishlist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discount_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- Helper function to check if current user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.user_roles
        WHERE user_id = auth.uid() AND role = 'admin'
    ) OR EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND role = 'admin'
    );
$$;

-- Categories: Public read, Admin write
CREATE POLICY "Public categories are readable by everyone" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Admins can manage categories" ON public.categories FOR ALL USING (public.is_admin());

-- Products: Published are readable by everyone, Admins can view/manage all
CREATE POLICY "Published products are readable by everyone" ON public.products FOR SELECT USING (status = 'published' OR public.is_admin());
CREATE POLICY "Admins can manage products" ON public.products FOR ALL USING (public.is_admin());

-- Product Variants & Images: Readable by everyone
CREATE POLICY "Product variants readable by everyone" ON public.product_variants FOR SELECT USING (true);
CREATE POLICY "Admins can manage variants" ON public.product_variants FOR ALL USING (public.is_admin());

CREATE POLICY "Product images readable by everyone" ON public.product_images FOR SELECT USING (true);
CREATE POLICY "Admins can manage product images" ON public.product_images FOR ALL USING (public.is_admin());

-- Profiles: Users can view & edit own profile; Admins can view all
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id OR public.is_admin());
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Carts & Cart Items: Users manage own carts
CREATE POLICY "Users can view own cart" ON public.carts FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Users can create cart" ON public.carts FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Users can manage cart items" ON public.cart_items FOR ALL USING (
    EXISTS (SELECT 1 FROM public.carts WHERE carts.id = cart_items.cart_id AND (carts.user_id = auth.uid() OR carts.user_id IS NULL))
);

-- Wishlists: Users manage own wishlist
CREATE POLICY "Users can view own wishlist" ON public.wishlists FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own wishlist" ON public.wishlists FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage wishlist items" ON public.wishlist_items FOR ALL USING (
    EXISTS (SELECT 1 FROM public.wishlists WHERE wishlists.id = wishlist_items.wishlist_id AND wishlists.user_id = auth.uid())
);

-- Addresses: Users manage own addresses
CREATE POLICY "Users can manage own addresses" ON public.addresses FOR ALL USING (auth.uid() = user_id);

-- Discount Codes: Public can read active codes, Admins can manage
CREATE POLICY "Public can view active discount codes" ON public.discount_codes FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "Admins can manage discount codes" ON public.discount_codes FOR ALL USING (public.is_admin());

-- Orders: Users can read own orders; Admins can read & manage all orders
CREATE POLICY "Users can view own orders" ON public.orders FOR SELECT USING (auth.uid() = user_id OR public.is_admin());
CREATE POLICY "Users can create orders" ON public.orders FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Admins can manage orders" ON public.orders FOR ALL USING (public.is_admin());

-- Order Items: Users view items from own orders; Admins manage
CREATE POLICY "Users can view own order items" ON public.order_items FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND (orders.user_id = auth.uid() OR public.is_admin()))
);
CREATE POLICY "Order items insertable" ON public.order_items FOR INSERT WITH CHECK (true);

-- Payments: Users view own payments, Admins manage
CREATE POLICY "Users can view own payments" ON public.payments FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.orders WHERE orders.id = payments.order_id AND (orders.user_id = auth.uid() OR public.is_admin()))
);
CREATE POLICY "Payments insertable" ON public.payments FOR INSERT WITH CHECK (true);

-- Inventory movements: Admins only
CREATE POLICY "Admins can view inventory movements" ON public.inventory_movements FOR SELECT USING (public.is_admin());

-- Newsletter subscribers: Anyone can subscribe, Admins can view
CREATE POLICY "Public can subscribe to newsletter" ON public.newsletter_subscribers FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can view newsletter subscribers" ON public.newsletter_subscribers FOR SELECT USING (public.is_admin());
