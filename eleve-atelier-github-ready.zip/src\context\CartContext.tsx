import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product, ProductVariant } from '../types';
import { mockDb } from '../services/supabase';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  total: number;
  appliedCoupon: string | null;
  couponMessage: string | null;
  isCartDrawerOpen: boolean;
  setIsCartDrawerOpen: (open: boolean) => void;
  addToCart: (product: Product, variant: ProductVariant, quantity?: number) => boolean;
  updateQuantity: (variantId: string, quantity: number) => void;
  removeFromCart: (variantId: string) => void;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('eleve_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponMessage, setCouponMessage] = useState<string | null>(null);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('eleve_cart', JSON.stringify(items));
    } catch (e) {
      console.warn(e);
    }
  }, [items]);

  // Subtotal calculation based on active pricing
  const subtotal = items.reduce((sum, item) => {
    const unitPrice = item.product.sale_price_inr ?? item.product.price_inr;
    return sum + unitPrice * item.quantity;
  }, 0);

  // Free shipping above ₹3,000, otherwise ₹250
  const shippingFee = subtotal > 3000 || subtotal === 0 ? 0 : 250;

  // Recalculate discount whenever subtotal or coupon changes
  useEffect(() => {
    if (appliedCoupon && subtotal > 0) {
      const res = mockDb.validateDiscount(appliedCoupon, subtotal);
      if (res.valid) {
        setDiscountAmount(res.discountAmount);
        setCouponMessage(res.message);
      } else {
        setDiscountAmount(0);
        setCouponMessage(res.message);
      }
    } else {
      setDiscountAmount(0);
      setCouponMessage(null);
    }
  }, [appliedCoupon, subtotal]);

  const total = Math.max(0, subtotal - discountAmount + shippingFee);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  const addToCart = (product: Product, variant: ProductVariant, quantity = 1): boolean => {
    if (variant.available_stock < quantity) {
      return false;
    }

    setItems(prevItems => {
      const existingIndex = prevItems.findIndex(i => i.variant_id === variant.id);
      if (existingIndex > -1) {
        const nextItems = [...prevItems];
        const newQty = nextItems[existingIndex].quantity + quantity;
        if (newQty > variant.available_stock) {
          return prevItems;
        }
        nextItems[existingIndex] = {
          ...nextItems[existingIndex],
          quantity: newQty,
        };
        return nextItems;
      } else {
        return [
          ...prevItems,
          {
            id: `ci-${Date.now()}`,
            variant_id: variant.id,
            product,
            variant,
            quantity,
          },
        ];
      }
    });

    setIsCartDrawerOpen(true);
    return true;
  };

  const updateQuantity = (variantId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(variantId);
      return;
    }

    setItems(prevItems => 
      prevItems.map(item => {
        if (item.variant_id === variantId) {
          const validQty = Math.min(quantity, item.variant.available_stock);
          return { ...item, quantity: validQty };
        }
        return item;
      })
    );
  };

  const removeFromCart = (variantId: string) => {
    setItems(prev => prev.filter(i => i.variant_id !== variantId));
  };

  const applyCoupon = (code: string): boolean => {
    const res = mockDb.validateDiscount(code, subtotal);
    if (res.valid) {
      setAppliedCoupon(code.toUpperCase().trim());
      setDiscountAmount(res.discountAmount);
      setCouponMessage(res.message);
      return true;
    } else {
      setCouponMessage(res.message);
      return false;
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setDiscountAmount(0);
    setCouponMessage(null);
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
    setDiscountAmount(0);
  };

  return (
    <CartContext.Provider value={{
      items,
      itemCount,
      subtotal,
      discountAmount,
      shippingFee,
      total,
      appliedCoupon,
      couponMessage,
      isCartDrawerOpen,
      setIsCartDrawerOpen,
      addToCart,
      updateQuantity,
      removeFromCart,
      applyCoupon,
      removeCoupon,
      clearCart,
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
