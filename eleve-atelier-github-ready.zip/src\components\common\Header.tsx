import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Heart, Search, User, Menu, X, Shield, ArrowRight } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useAuth } from '../../context/AuthContext';

export const Header: React.FC = () => {
  const { itemCount, setIsCartDrawerOpen } = useCart();
  const { itemCount: wishlistCount } = useWishlist();
  const { user, isAdmin, loginAs } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <>
      {/* 1. TOP ANNOUNCEMENT BAR */}
      <div className="bg-charcoal text-cream text-xs py-2 px-4 text-center tracking-editorial font-light transition-all flex items-center justify-between border-b border-charcoal/20">
        <div className="hidden sm:block text-[11px] text-cream/70 uppercase tracking-widest">
          Curated in Paris & Mumbai
        </div>
        <div className="mx-auto flex items-center gap-2">
          <span>COMPLIMENTARY DOMESTIC COURIER ON ALL ORDERS OVER ₹3,000</span>
          <span className="hidden md:inline text-blush-300">• CODE: <strong className="text-white">WELCOME10</strong> FOR 10% OFF</span>
        </div>
        
        {/* Quick Role Switcher for Portfolio Reviewer */}
        <div className="flex items-center gap-2 text-[11px]">
          <span className="hidden lg:inline text-cream/60">Demo Mode:</span>
          {isAdmin ? (
            <button 
              onClick={() => loginAs('customer')}
              className="bg-blush-500 hover:bg-blush-600 text-white px-2 py-0.5 rounded text-[10px] tracking-wider uppercase transition-colors"
              title="Click to view site as Customer"
            >
              Admin View (Switch to Customer)
            </button>
          ) : (
            <button 
              onClick={() => loginAs('admin')}
              className="bg-white/10 hover:bg-white/20 text-cream px-2 py-0.5 rounded text-[10px] tracking-wider uppercase transition-colors flex items-center gap-1"
              title="Click to view Protected Admin Dashboard"
            >
              <Shield className="w-3 h-3 text-blush-300" />
              <span>Switch to Admin</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. MAIN EDITORIAL NAVIGATION */}
      <header className="sticky top-0 z-40 bg-ivory/90 backdrop-blur-md border-b border-borderSoft transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Mobile hamburger */}
          <div className="flex items-center lg:hidden">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 -ml-2 text-charcoal hover:text-blush-500 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Desktop Left Nav Links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium tracking-editorial uppercase text-charcoal/80">
            <Link to="/shop" className="hover:text-cherry-600 transition-colors relative group">
              Shop All
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-cherry-600 transition-all group-hover:w-full"></span>
            </Link>
            <Link to="/shop?newArrival=true" className="hover:text-cherry-600 transition-colors relative group">
              New Arrivals
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-cherry-600 transition-all group-hover:w-full"></span>
            </Link>
            <Link to="/shop?category=dresses" className="hover:text-cherry-600 transition-colors relative group">
              Dresses
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-cherry-600 transition-all group-hover:w-full"></span>
            </Link>
            <Link to="/#moodboard" className="hover:text-cherry-600 transition-colors relative group">
              Moodboard
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-cherry-600 transition-all group-hover:w-full"></span>
            </Link>
          </nav>

          {/* Center Brand Identity Logo */}
          <div className="flex-1 lg:flex-none text-center">
            <Link to="/" className="inline-block group text-center">
              <span className="font-editorial text-2xl sm:text-3xl lg:text-4xl tracking-[0.2em] font-medium uppercase text-charcoal transition-colors group-hover:text-cherry-600">
                ÉLÉVÉ ATELIER
              </span>
              <span className="block text-[9px] tracking-[0.35em] text-mutedGrey uppercase -mt-1 font-light">
                Haute Mode • Édition 2026
              </span>
            </Link>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-3 sm:gap-5">
            {/* Search Trigger */}
            <button 
              onClick={() => setSearchOpen(!searchOpen)} 
              className="p-2 text-charcoal hover:text-cherry-600 transition-colors"
              aria-label="Search catalogue"
            >
              <Search className="w-5 h-5 stroke-[1.5]" />
            </button>

            {/* Account / Admin Portal */}
            {isAdmin ? (
              <Link 
                to="/admin" 
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-charcoal text-cream text-xs tracking-wider uppercase hover:bg-cherry-600 transition-colors"
              >
                <Shield className="w-3.5 h-3.5 text-blush-300" />
                <span>Admin Suite</span>
              </Link>
            ) : (
              <Link 
                to="/account" 
                className="p-2 text-charcoal hover:text-cherry-600 transition-colors relative"
                aria-label="Customer account"
              >
                <User className="w-5 h-5 stroke-[1.5]" />
              </Link>
            )}

            {/* Wishlist */}
            <Link 
              to="/wishlist" 
              className="p-2 text-charcoal hover:text-cherry-600 transition-colors relative"
              aria-label="Saved wishlist"
            >
              <Heart className="w-5 h-5 stroke-[1.5]" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-blush-400 text-white text-[10px] rounded-full flex items-center justify-center font-semibold">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Shopping Bag Button */}
            <button 
              onClick={() => setIsCartDrawerOpen(true)}
              className="p-2 text-charcoal hover:text-cherry-600 transition-colors relative flex items-center gap-2 group"
              aria-label="View shopping bag"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 stroke-[1.5] group-hover:scale-105 transition-transform" />
                {itemCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-cherry-600 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                    {itemCount}
                  </span>
                )}
              </div>
              <span className="hidden md:inline text-xs font-semibold tracking-wider uppercase text-charcoal/80">
                Bag ({itemCount})
              </span>
            </button>
          </div>
        </div>

        {/* Search Bar Dropdown Overlay */}
        {searchOpen && (
          <div className="border-t border-borderSoft bg-white/95 backdrop-blur-md px-4 py-4 animate-fade-in shadow-sm">
            <form onSubmit={handleSearchSubmit} className="max-w-3xl mx-auto flex items-center gap-3">
              <Search className="w-5 h-5 text-mutedGrey" />
              <input 
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search across 50+ pieces (e.g. Corset, Juliette Silk, Bubble Skirt, Tweed Set)..."
                className="flex-1 bg-transparent border-none outline-none text-sm text-charcoal placeholder-mutedGrey/70 py-1"
                autoFocus
              />
              <button 
                type="submit"
                className="text-xs uppercase tracking-luxury font-medium px-4 py-2 bg-charcoal text-white rounded hover:bg-cherry-600 transition-colors"
              >
                Search
              </button>
              <button 
                type="button" 
                onClick={() => setSearchOpen(false)}
                className="text-mutedGrey hover:text-charcoal p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </form>
          </div>
        )}

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-borderSoft bg-cream/95 backdrop-blur-lg px-6 py-8 space-y-6 animate-fade-in">
            <div className="flex flex-col space-y-4 text-base tracking-editorial uppercase font-medium text-charcoal">
              <Link 
                to="/shop" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                Shop All Catalogue
              </Link>
              <Link 
                to="/shop?newArrival=true" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40 text-cherry-600"
              >
                New Arrivals ★
              </Link>
              <Link 
                to="/shop?category=dresses" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                Dresses & Gowns
              </Link>
              <Link 
                to="/shop?category=tops" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                Corsets & Tops
              </Link>
              <Link 
                to="/shop?category=coord" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                Co-ord Sets
              </Link>
              <Link 
                to="/shop?category=accessories" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                Accessories & Bows
              </Link>
              <Link 
                to="/account" 
                onClick={() => setMobileMenuOpen(false)}
                className="hover:text-cherry-600 py-1 border-b border-borderSoft/40"
              >
                My Account
              </Link>
              {isAdmin && (
                <Link 
                  to="/admin" 
                  onClick={() => setMobileMenuOpen(false)}
                  className="hover:text-cherry-600 py-1 text-cherry-600 font-semibold"
                >
                  Admin Management Console →
                </Link>
              )}
            </div>
            
            <div className="pt-4 border-t border-borderSoft text-xs text-mutedGrey">
              <p>Logged in as: <strong className="text-charcoal">{user?.full_name}</strong> ({user?.role})</p>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
