import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export const CampaignStory: React.FC = () => {
  return (
    <section id="campaign" className="py-24 bg-charcoal text-cream overflow-hidden relative">
      
      {/* Editorial Watermark Background Typography */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 font-editorial text-[14vw] text-white/[0.03] select-none pointer-events-none whitespace-nowrap leading-none">
        ÉLÉVÉ ATELIER 2026
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Layered Imagery */}
          <div className="lg:col-span-7 relative">
            <div className="relative rounded-3xl overflow-hidden aspect-[4/5] sm:aspect-[16/11] border border-white/10 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=85" 
                alt="Campaign Narrative Haute Mode"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-transparent" />
            </div>

            {/* Overlapping Inset Editorial Image */}
            <div className="hidden sm:block absolute -bottom-10 -right-6 w-56 aspect-[3/4] rounded-2xl overflow-hidden border-4 border-charcoal shadow-2xl bg-beige">
              <img 
                src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80" 
                alt="Corset Detail"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Right Editorial Copy */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-[11px] font-semibold tracking-luxury uppercase text-blush-300 block">
              Editorial Campaign • The Poetics of Soft Armor
            </span>

            <h2 className="font-editorial text-3xl sm:text-5xl text-cream leading-tight">
              Where fragile romance meets uncompromising structure.
            </h2>

            <p className="text-sm text-cream/70 font-light leading-relaxed">
              We design for those who wear their softness as sovereignty. Our garments 
              juxtapose gossamer French Chantilly laces, 22mm Mulberry silk slips, and hand-sculpted 
              corset boning against distressed leather bikers and oversized tailoring.
            </p>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <p className="text-xs italic text-blush-200 font-serif">
                “Clothing should feel like an heirloom discovered in a dream, engineered with modern architectural precision.”
              </p>
              <p className="text-[10px] text-cream/50 uppercase tracking-luxury">
                — ÉLÉVÉ ATELIER Creative Directorate
              </p>
            </div>

            <div className="pt-2">
              <Link 
                to="/shop"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-cream text-charcoal text-xs uppercase tracking-luxury font-semibold hover:bg-blush-300 transition-colors shadow-lg"
              >
                <span>Read The Lookbook</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
