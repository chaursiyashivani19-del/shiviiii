import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import { mockDb } from '../services/supabase';
import { ProductCard } from '../components/shop/ProductCard';
import { FilterSidebar } from '../components/shop/FilterSidebar';

export const ShopPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Search and filter state synced with URL
  const search = searchParams.get('search') || '';
  const initialCategory = searchParams.get('category') || 'all';
  const initialNewArrival = searchParams.get('newArrival') === 'true';

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'price-asc' | 'price-desc' | 'newest' | 'popularity'>('newest');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 15000]);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Filter products using local mockDb engine
  const products = useMemo(() => {
    return mockDb.getProducts({
      search: search || undefined,
      category: selectedCategory,
      size: selectedSize !== 'all' ? selectedSize : undefined,
      maxPrice: priceRange[1],
      inStockOnly,
      sortBy,
      isNewArrival: initialNewArrival ? true : undefined,
    });
  }, [search, selectedCategory, selectedSize, priceRange, inStockOnly, sortBy, initialNewArrival]);

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSelectedSize('all');
    setInStockOnly(false);
    setSortBy('newest');
    setPriceRange([0, 15000]);
    setSearchParams({});
  };

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Editorial Header */}
      <div className="mb-10 text-center lg:text-left space-y-2">
        <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600 block">
          The Full Catalogue • Édition 2026
        </span>
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <h1 className="font-editorial text-4xl sm:text-5xl text-charcoal">
              {search ? `Search results for "${search}"` : initialNewArrival ? 'New Arrivals Showcase' : 'All Silhouettes'}
            </h1>
            <p className="text-xs sm:text-sm text-mutedGrey font-light mt-1">
              Showing {products.length} couture garments with live variant stock
            </p>
          </div>

          {/* Mobile Filter Toggle */}
          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="lg:hidden inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-charcoal text-white text-xs uppercase tracking-luxury font-medium shadow-sm"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filter & Sort ({products.length})</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-28">
          <FilterSidebar 
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            selectedSize={selectedSize}
            setSelectedSize={setSelectedSize}
            inStockOnly={inStockOnly}
            setInStockOnly={setInStockOnly}
            sortBy={sortBy}
            setSortBy={setSortBy}
            priceRange={priceRange}
            setPriceRange={setPriceRange}
            onReset={handleResetFilters}
            totalFilteredCount={products.length}
          />
        </aside>

        {/* Mobile Filter Modal/Drawer */}
        {mobileFilterOpen && (
          <div className="fixed inset-0 z-50 bg-charcoal/50 backdrop-blur-sm lg:hidden flex justify-end">
            <div className="w-full max-w-sm bg-ivory h-full p-6 overflow-y-auto animate-fade-in shadow-2xl">
              <FilterSidebar 
                selectedCategory={selectedCategory}
                setSelectedCategory={(cat) => { setSelectedCategory(cat); setMobileFilterOpen(false); }}
                selectedSize={selectedSize}
                setSelectedSize={(s) => { setSelectedSize(s); setMobileFilterOpen(false); }}
                inStockOnly={inStockOnly}
                setInStockOnly={setInStockOnly}
                sortBy={sortBy}
                setSortBy={setSortBy}
                priceRange={priceRange}
                setPriceRange={setPriceRange}
                onReset={handleResetFilters}
                totalFilteredCount={products.length}
              />
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="mt-6 w-full py-3 bg-charcoal text-white text-xs uppercase tracking-luxury rounded-xl font-semibold"
              >
                Apply Filters ({products.length} Items)
              </button>
            </div>
          </div>
        )}

        {/* Product Grid Area */}
        <main className="lg:col-span-9">
          {products.length === 0 ? (
            <div className="py-24 text-center bg-white/60 rounded-3xl border border-borderSoft p-8 space-y-4">
              <span className="text-5xl block">🕊️</span>
              <h3 className="font-editorial text-2xl text-charcoal">No Silhouettes Match Your Criteria</h3>
              <p className="text-xs text-mutedGrey max-w-md mx-auto">
                Try widening your price range, clearing size filters, or exploring another category.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-6 py-2.5 rounded-full bg-charcoal text-white text-xs uppercase tracking-luxury font-medium hover:bg-cherry-600 transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </main>

      </div>

    </div>
  );
};
