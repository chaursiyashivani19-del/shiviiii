export type UserRole = 'customer' | 'admin' | 'inventory_manager';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone?: string;
  avatar_url?: string;
  created_at?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string;
  display_order: number;
  is_active: boolean;
  item_count?: number;
}

export interface ProductImage {
  id: string;
  product_id: string;
  color?: string;
  image_url: string;
  alt_text?: string;
  display_order: number;
  is_primary: boolean;
}

export interface ProductVariant {
  id: string;
  product_id: string;
  sku: string;
  size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'OS';
  color: string;
  color_hex: string;
  stock_on_hand: number;
  stock_reserved: number;
  available_stock: number;
  low_stock_threshold: number;
}

export type ProductStatus = 'draft' | 'published' | 'archived';

export interface Product {
  id: string;
  title: string;
  slug: string;
  description: string;
  category_id: string;
  category_name?: string;
  price_inr: number;
  sale_price_inr?: number;
  status: ProductStatus;
  is_featured: boolean;
  is_new_arrival: boolean;
  editorial_quote?: string;
  tags?: string[];
  care_instructions?: string;
  fabric_details?: string;
  images: ProductImage[];
  variants: ProductVariant[];
  created_at: string;
  updated_at?: string;
}

export interface CartItem {
  id: string;
  cart_id?: string;
  variant_id: string;
  product: Product;
  variant: ProductVariant;
  quantity: number;
}

export interface WishlistItem {
  id: string;
  product_id: string;
  product: Product;
  added_at: string;
}

export interface Address {
  id: string;
  user_id?: string;
  full_name: string;
  phone: string;
  street_address: string;
  apartment?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  is_default?: boolean;
}

export interface DiscountCode {
  id: string;
  code: string;
  discount_percent?: number;
  fixed_amount_inr?: number;
  min_order_amount_inr: number;
  is_active: boolean;
  starts_at?: string;
  expires_at?: string;
  usage_limit?: number;
  times_used?: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id?: string;
  variant_id?: string;
  product_title_snapshot: string;
  sku_snapshot: string;
  size_snapshot: string;
  color_snapshot: string;
  unit_price_inr_snapshot: number;
  quantity: number;
  total_price_inr: number;
  image_url?: string;
}

export interface Order {
  id: string;
  order_number: string;
  user_id?: string;
  guest_email?: string;
  shipping_address: Address;
  subtotal_inr: number;
  discount_amount_inr: number;
  shipping_fee_inr: number;
  total_inr: number;
  discount_code_applied?: string;
  status: OrderStatus;
  items: OrderItem[];
  created_at: string;
  updated_at?: string;
}

export type InventoryMovementType = 
  | 'initial_stock'
  | 'manual_addition'
  | 'manual_deduction'
  | 'order_reservation'
  | 'order_fulfillment'
  | 'order_cancellation'
  | 'return_restock'
  | 'inventory_correction';

export interface InventoryMovement {
  id: string;
  variant_id: string;
  product_title?: string;
  sku?: string;
  movement_type: InventoryMovementType;
  quantity_change: number;
  stock_on_hand_after: number;
  stock_reserved_after: number;
  reference_id?: string;
  notes?: string;
  created_by?: string;
  created_at: string;
}

export interface PaymentDetails {
  id: string;
  order_id: string;
  provider: 'razorpay' | 'demo_mock';
  provider_order_id: string;
  provider_payment_id?: string;
  amount_inr: number;
  currency: string;
  status: 'pending' | 'authorized' | 'captured' | 'failed' | 'refunded';
  error_message?: string;
  verified_at?: string;
}
