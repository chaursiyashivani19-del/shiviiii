import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Package, MapPin, Shield, Check, Clock, Truck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mockDb } from '../services/supabase';

export const AccountPage: React.FC = () => {
  const { user, loginAs, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'addresses'>('orders');

  const orders = mockDb.getOrders(user?.id);

  return (
    <div className="py-12 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header Profile Summary */}
      <div className="p-6 sm:p-8 bg-white/80 rounded-3xl border border-borderSoft/80 shadow-soft-luxury mb-10 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img 
            src={user?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'} 
            alt={user?.full_name} 
            className="w-16 h-16 rounded-full object-cover border-2 border-blush-200"
          />
          <div>
            <h1 className="font-editorial text-2xl sm:text-3xl text-charcoal">{user?.full_name}</h1>
            <p className="text-xs text-mutedGrey">{user?.email} • Role: <strong className="uppercase text-charcoal">{user?.role}</strong></p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {user?.role === 'admin' ? (
            <Link
              to="/admin"
              className="px-5 py-2.5 bg-charcoal text-white text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-cherry-600 transition-colors flex items-center gap-2"
            >
              <Shield className="w-3.5 h-3.5 text-blush-300" />
              <span>Enter Admin Dashboard</span>
            </Link>
          ) : (
            <button
              onClick={() => loginAs('admin')}
              className="px-5 py-2.5 bg-white border border-charcoal text-charcoal text-xs uppercase tracking-luxury font-semibold rounded-full hover:bg-beige transition-colors flex items-center gap-2"
            >
              <Shield className="w-3.5 h-3.5 text-cherry-600" />
              <span>Switch to Admin Mode</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-borderSoft mb-8 text-xs uppercase tracking-luxury font-semibold">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'orders' 
              ? 'border-charcoal text-charcoal' 
              : 'border-transparent text-mutedGrey hover:text-charcoal'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Order History ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`pb-3 border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'addresses' 
              ? 'border-charcoal text-charcoal' 
              : 'border-transparent text-mutedGrey hover:text-charcoal'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Addresses</span>
        </button>
      </div>

      {/* TAB CONTENT: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          {orders.length === 0 ? (
            <div className="p-12 text-center bg-white/60 rounded-3xl border border-borderSoft space-y-3">
              <span className="text-4xl">📦</span>
              <p className="font-editorial text-xl text-charcoal">No Historical Orders Yet</p>
              <p className="text-xs text-mutedGrey">Any purchases you authorize will appear here with permanent price snapshots.</p>
            </div>
          ) : (
            orders.map((order) => (
              <div 
                key={order.id} 
                className="p-6 bg-white/90 rounded-3xl border border-borderSoft/80 shadow-xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-borderSoft gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Order Reference</span>
                    <p className="font-mono font-bold text-charcoal text-sm">{order.order_number}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Date</span>
                    <p className="text-charcoal">{new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Total Paid</span>
                    <p className="text-sm font-bold text-cherry-600">₹{order.total_inr.toLocaleString('en-IN')}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Status</span>
                    <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider block mt-0.5 bg-emerald-100 text-emerald-800">
                      {order.status}
                    </span>
                  </div>
                </div>

                {/* Items */}
                <div className="space-y-3">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex items-center justify-between gap-4 text-xs">
                      <div className="flex items-center gap-3">
                        {item.image_url && (
                          <img src={item.image_url} alt="" className="w-12 h-14 object-cover rounded-xl bg-beige" />
                        )}
                        <div>
                          <p className="font-semibold text-charcoal">{item.product_title_snapshot}</p>
                          <p className="text-[11px] text-mutedGrey">
                            Size: {item.size_snapshot} • Color: {item.color_snapshot} • Qty: {item.quantity}
                          </p>
                          <p className="text-[10px] font-mono text-mutedGrey">SKU: {item.sku_snapshot}</p>
                        </div>
                      </div>
                      <span className="font-bold text-charcoal">
                        ₹{item.total_price_inr.toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-3 border-t border-borderSoft text-[11px] text-mutedGrey flex items-center justify-between">
                  <span>Shipping Address: {order.shipping_address.street_address}, {order.shipping_address.city}</span>
                  <span className="text-emerald-700 font-medium flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5" />
                    Express Dispatch
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB CONTENT: ADDRESSES */}
      {activeTab === 'addresses' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-white/90 rounded-3xl border-2 border-charcoal space-y-2 relative shadow-sm">
            <span className="absolute top-4 right-4 text-[10px] uppercase font-bold tracking-luxury px-2 py-0.5 bg-charcoal text-white rounded">
              Default Destination
            </span>
            <p className="font-bold text-charcoal text-sm">Clara Delacroix</p>
            <p className="text-xs text-mutedGrey">+91 98765 43210</p>
            <p className="text-xs text-charcoal pt-1">
              42 Rue Des Rêves, Bandra West<br />
              Mumbai, Maharashtra - 400050<br />
              India
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
