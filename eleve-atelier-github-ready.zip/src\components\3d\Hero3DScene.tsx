import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export const Hero3DScene: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [webGLFailed, setWebGLFailed] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Scene Setup
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      setWebGLFailed(true);
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.z = 6;

    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Group for objects
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. Central Couture Bow Object
    // Create an elegant bow using two tori and a central sphere/knot
    const bowMaterial = new THREE.MeshStandardMaterial({
      color: 0xF6CED7, // blush coquette pink
      roughness: 0.25,
      metalness: 0.1,
      clearcoat: 0.6,
      clearcoatRoughness: 0.2,
    });

    const chromeMaterial = new THREE.MeshStandardMaterial({
      color: 0xE8E0F0,
      metalness: 0.95,
      roughness: 0.1,
    });

    const goldMaterial = new THREE.MeshStandardMaterial({
      color: 0xE5C158,
      metalness: 0.85,
      roughness: 0.2,
    });

    // Bow loops
    const bowLoopGeo = new THREE.TorusGeometry(0.75, 0.22, 24, 48, Math.PI * 1.5);
    const leftLoop = new THREE.Mesh(bowLoopGeo, bowMaterial);
    leftLoop.position.set(-0.6, 0.1, 0);
    leftLoop.rotation.z = Math.PI * 0.25;
    leftLoop.rotation.y = Math.PI * 0.15;
    mainGroup.add(leftLoop);

    const rightLoop = new THREE.Mesh(bowLoopGeo, bowMaterial);
    rightLoop.position.set(0.6, 0.1, 0);
    rightLoop.rotation.z = -Math.PI * 0.25;
    rightLoop.rotation.y = -Math.PI * 0.15;
    mainGroup.add(rightLoop);

    // Bow knot
    const knotGeo = new THREE.SphereGeometry(0.3, 32, 32);
    const knot = new THREE.Mesh(knotGeo, chromeMaterial);
    knot.scale.set(1.2, 0.8, 1);
    mainGroup.add(knot);

    // Trailing ribbon tails
    const ribbonGeo = new THREE.CylinderGeometry(0.18, 0.05, 1.4, 24);
    const leftTail = new THREE.Mesh(ribbonGeo, bowMaterial);
    leftTail.position.set(-0.4, -0.9, 0.1);
    leftTail.rotation.z = -0.3;
    leftTail.rotation.x = 0.2;
    mainGroup.add(leftTail);

    const rightTail = new THREE.Mesh(ribbonGeo, bowMaterial);
    rightTail.position.set(0.4, -0.9, -0.1);
    rightTail.rotation.z = 0.3;
    rightTail.rotation.x = -0.2;
    mainGroup.add(rightTail);

    // 2. Floating Sculptural Chrome Accessory (Right side)
    const clutchGeo = new THREE.BoxGeometry(0.9, 0.6, 0.35);
    const clutch = new THREE.Mesh(clutchGeo, chromeMaterial);
    clutch.position.set(2.4, 0.8, -0.8);
    clutch.rotation.set(0.4, -0.5, 0.2);
    mainGroup.add(clutch);

    // Clutch clasp ring
    const ringGeo = new THREE.TorusGeometry(0.18, 0.04, 16, 32);
    const ring = new THREE.Mesh(ringGeo, goldMaterial);
    ring.position.set(2.4, 1.15, -0.75);
    ring.rotation.x = Math.PI / 2;
    mainGroup.add(ring);

    // 3. Floating Baroque Pearl Sphere (Left top)
    const pearlMaterial = new THREE.MeshStandardMaterial({
      color: 0xFCFBF7,
      roughness: 0.15,
      metalness: 0.1,
    });
    const pearlGeo = new THREE.SphereGeometry(0.4, 32, 32);
    const pearl = new THREE.Mesh(pearlGeo, pearlMaterial);
    pearl.position.set(-2.2, 1.3, -0.5);
    mainGroup.add(pearl);

    // 4. Smaller floating aesthetic beads
    const beads: THREE.Mesh[] = [];
    for (let i = 0; i < 5; i++) {
      const bead = new THREE.Mesh(
        new THREE.SphereGeometry(0.08 + Math.random() * 0.06, 16, 16),
        Math.random() > 0.5 ? goldMaterial : bowMaterial
      );
      bead.position.set(
        (Math.random() - 0.5) * 5,
        (Math.random() - 0.5) * 3,
        (Math.random() - 0.5) * 2
      );
      mainGroup.add(bead);
      beads.push(bead);
    }

    // Lights
    const ambientLight = new THREE.AmbientLight(0xfff7f0, 1.4);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 2.0);
    dirLight1.position.set(5, 5, 4);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xf6ced7, 1.5);
    dirLight2.position.set(-5, -3, 3);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0xffffff, 1.8, 10);
    pointLight.position.set(0, 2, 3);
    scene.add(pointLight);

    // Mouse Tracking for Interactive Parallax
    let targetRotationX = 0;
    let targetRotationY = 0;

    const handleMouseMove = (event: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);
      targetRotationY = x * 0.45;
      targetRotationX = -y * 0.35;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      if (!prefersReducedMotion) {
        // Subtle natural float
        mainGroup.position.y = Math.sin(elapsedTime * 0.8) * 0.12;

        // Smooth damping towards mouse position
        mainGroup.rotation.y += (targetRotationY - mainGroup.rotation.y) * 0.05;
        mainGroup.rotation.x += (targetRotationX - mainGroup.rotation.x) * 0.05;

        // Gentle secondary movements
        clutch.rotation.y = -0.5 + Math.sin(elapsedTime * 1.2) * 0.1;
        clutch.position.y = 0.8 + Math.cos(elapsedTime * 0.9) * 0.08;
        ring.position.y = clutch.position.y + 0.35;

        pearl.position.y = 1.3 + Math.sin(elapsedTime * 1.1) * 0.07;
        pearl.rotation.x = elapsedTime * 0.2;

        beads.forEach((b, idx) => {
          b.position.y += Math.sin(elapsedTime * (1 + idx * 0.2)) * 0.002;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      if (container && renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  if (webGLFailed) {
    return (
      <div className="w-full h-full flex items-center justify-center p-8 bg-blush-50/50 rounded-3xl border border-blush-100">
        <div className="text-center">
          <span className="text-7xl block mb-4 animate-bounce">🎀</span>
          <p className="font-editorial text-2xl text-charcoal tracking-wide">Couture Atelier Edition</p>
          <p className="text-xs text-mutedGrey mt-2 uppercase tracking-luxury">Tactile 3D Sculpture Active</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full min-h-[440px] lg:min-h-[580px] relative pointer-events-auto cursor-grab active:cursor-grabbing select-none"
      aria-label="Interactive 3D Fashion Bow & Accessories Showcase"
    />
  );
};
