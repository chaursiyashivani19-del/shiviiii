import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { CATEGORIES } from '../../data/categories';

export const CategoryShowcase: React.FC = () => {
  return (
    <section className="py-20 bg-cream/50 border-y border-borderSoft/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-[11px] font-semibold tracking-luxury uppercase text-mutedGrey block">
            The Atelier Categories
          </span>
          <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl text-charcoal">
            Curated Wardrobe Disciplines
          </h2>
          <p className="text-xs sm:text-sm text-mutedGrey font-light">
            Distinct design directions bridging soft coquette romanticism, sharp tailoring, and evening glamour.
          </p>
        </div>

        {/* Asymmetrical Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Large Hero Category (Dresses) */}
          <div className="md:col-span-8 group relative rounded-3xl overflow-hidden aspect-[16/10] bg-beige/30 border border-borderSoft/60">
            <img 
              src={CATEGORIES[1].image_url} 
              alt={CATEGORIES[1].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent flex flex-col justify-end p-8 text-cream">
              <span className="text-[10px] tracking-luxury uppercase text-blush-200">10 Curated Silhouettes</span>
              <h3 className="font-editorial text-3xl sm:text-4xl mt-1 mb-2">{CATEGORIES[1].name}</h3>
              <p className="text-xs text-cream/80 max-w-md font-light mb-4 line-clamp-2">
                {CATEGORIES[1].description}
              </p>
              <Link 
                to={`/shop?category=${CATEGORIES[1].slug}`}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-white hover:text-blush-200 transition-colors"
              >
                <span>Shop Dresses</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Medium Category (Tops & Corsets) */}
          <div className="md:col-span-4 group relative rounded-3xl overflow-hidden aspect-[4/5] bg-beige/30 border border-borderSoft/60">
            <img 
              src={CATEGORIES[0].image_url} 
              alt={CATEGORIES[0].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent flex flex-col justify-end p-6 text-cream">
              <span className="text-[10px] tracking-luxury uppercase text-blush-200">Boning & Ribbons</span>
              <h3 className="font-editorial text-2xl mt-1 mb-2">{CATEGORIES[0].name}</h3>
              <Link 
                to={`/shop?category=${CATEGORIES[0].slug}`}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-white hover:text-blush-200 transition-colors"
              >
                <span>Explore Tops</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Row of 3 Categories (Co-ords, Streetwear, Accessories) */}
          <div className="md:col-span-4 group relative rounded-3xl overflow-hidden aspect-[4/5] bg-beige/30 border border-borderSoft/60">
            <img 
              src={CATEGORIES[4].image_url} 
              alt={CATEGORIES[4].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent flex flex-col justify-end p-6 text-cream">
              <h3 className="font-editorial text-2xl mb-1">{CATEGORIES[4].name}</h3>
              <p className="text-xs text-cream/70 font-light mb-3 line-clamp-1">{CATEGORIES[4].description}</p>
              <Link 
                to={`/shop?category=${CATEGORIES[4].slug}`}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-white hover:text-blush-200 transition-colors"
              >
                <span>Explore Co-ords</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="md:col-span-4 group relative rounded-3xl overflow-hidden aspect-[4/5] bg-beige/30 border border-borderSoft/60">
            <img 
              src={CATEGORIES[5].image_url} 
              alt={CATEGORIES[5].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent flex flex-col justify-end p-6 text-cream">
              <h3 className="font-editorial text-2xl mb-1">{CATEGORIES[5].name}</h3>
              <p className="text-xs text-cream/70 font-light mb-3 line-clamp-1">{CATEGORIES[5].description}</p>
              <Link 
                to={`/shop?category=${CATEGORIES[5].slug}`}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-white hover:text-blush-200 transition-colors"
              >
                <span>Explore Streetwear</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="md:col-span-4 group relative rounded-3xl overflow-hidden aspect-[4/5] bg-beige/30 border border-borderSoft/60">
            <img 
              src={CATEGORIES[6].image_url} 
              alt={CATEGORIES[6].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent flex flex-col justify-end p-6 text-cream">
              <h3 className="font-editorial text-2xl mb-1">{CATEGORIES[6].name}</h3>
              <p className="text-xs text-cream/70 font-light mb-3 line-clamp-1">{CATEGORIES[6].description}</p>
              <Link 
                to={`/shop?category=${CATEGORIES[6].slug}`}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-luxury font-semibold text-white hover:text-blush-200 transition-colors"
              >
                <span>Explore Accessories</span>
                <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
