import React from 'react';
import { X, RotateCcw } from 'lucide-react';
import { CATEGORIES } from '../../data/categories';

interface FilterSidebarProps {
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedSize: string;
  setSelectedSize: (size: string) => void;
  inStockOnly: boolean;
  setInStockOnly: (inStock: boolean) => void;
  sortBy: 'price-asc' | 'price-desc' | 'newest' | 'popularity';
  setSortBy: (sort: 'price-asc' | 'price-desc' | 'newest' | 'popularity') => void;
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;
  onReset: () => void;
  totalFilteredCount: number;
}

const SIZES = ['all', 'XS', 'S', 'M', 'L', 'XL', 'OS'];

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  selectedCategory,
  setSelectedCategory,
  selectedSize,
  setSelectedSize,
  inStockOnly,
  setInStockOnly,
  sortBy,
  setSortBy,
  priceRange,
  setPriceRange,
  onReset,
  totalFilteredCount,
}) => {
  return (
    <div className="space-y-8 bg-white/60 p-6 rounded-3xl border border-borderSoft/60 backdrop-blur-sm">
      
      {/* Header & Reset */}
      <div className="flex items-center justify-between pb-4 border-b border-borderSoft">
        <div>
          <h2 className="font-editorial text-lg text-charcoal tracking-wide">Refine Pieces</h2>
          <p className="text-[11px] text-mutedGrey mt-0.5">{totalFilteredCount} styles found</p>
        </div>
        <button
          onClick={onReset}
          className="text-xs text-mutedGrey hover:text-cherry-600 transition-colors flex items-center gap-1 font-medium"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Sort By Dropdown */}
      <div className="space-y-2">
        <label className="text-xs uppercase tracking-luxury font-semibold text-charcoal block">
          Sort By
        </label>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as 'price-asc' | 'price-desc' | 'newest' | 'popularity')}
          className="w-full bg-ivory border border-borderSoft rounded-xl px-3 py-2.5 text-xs text-charcoal focus:outline-none focus:border-charcoal"
        >
          <option value="newest">Newest Arrivals</option>
          <option value="popularity">Featured & Most Coveted</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
        </select>
      </div>

      {/* Categories */}
      <div className="space-y-3">
        <label className="text-xs uppercase tracking-luxury font-semibold text-charcoal block">
          Category
        </label>
        <div className="space-y-1">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-colors flex items-center justify-between ${
              selectedCategory === 'all' 
                ? 'bg-charcoal text-white font-medium' 
                : 'text-charcoal/80 hover:bg-beige/60'
            }`}
          >
            <span>All Categories</span>
            <span className="text-[10px] opacity-70">53</span>
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-colors flex items-center justify-between ${
                selectedCategory === cat.slug 
                  ? 'bg-charcoal text-white font-medium' 
                  : 'text-charcoal/80 hover:bg-beige/60'
              }`}
            >
              <span>{cat.name}</span>
              <span className="text-[10px] opacity-70">{cat.item_count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Size Filter */}
      <div className="space-y-3">
        <label className="text-xs uppercase tracking-luxury font-semibold text-charcoal block">
          Size
        </label>
        <div className="flex flex-wrap gap-2">
          {SIZES.map((size) => (
            <button
              key={size}
              onClick={() => setSelectedSize(size)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                selectedSize === size
                  ? 'bg-charcoal text-white border-charcoal shadow-sm'
                  : 'bg-ivory text-charcoal border-borderSoft hover:border-charcoal'
              }`}
            >
              {size === 'all' ? 'All' : size}
            </button>
          ))}
        </div>
      </div>

      {/* Max Price Range Slider */}
      <div className="space-y-3">
        <div className="flex justify-between items-center text-xs">
          <label className="uppercase tracking-luxury font-semibold text-charcoal">
            Max Budget
          </label>
          <span className="font-bold text-cherry-600">₹{priceRange[1].toLocaleString('en-IN')}</span>
        </div>
        <input 
          type="range"
          min={1500}
          max={15000}
          step={500}
          value={priceRange[1]}
          onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
          className="w-full accent-charcoal cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-mutedGrey">
          <span>₹1,500</span>
          <span>₹15,000+</span>
        </div>
      </div>

      {/* Stock Availability Toggle */}
      <div className="pt-2 border-t border-borderSoft">
        <label className="flex items-center gap-3 cursor-pointer select-none">
          <input 
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
            className="w-4 h-4 rounded border-borderSoft text-charcoal focus:ring-0 accent-charcoal cursor-pointer"
          />
          <span className="text-xs font-medium text-charcoal">In-Stock Only</span>
        </label>
      </div>

    </div>
  );
};
