import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Heart, 
  ShoppingBag, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Sparkles, 
  Check, 
  Ruler, 
  X, 
  ArrowLeft 
} from 'lucide-react';
import { mockDb } from '../services/supabase';
import { Product, ProductVariant } from '../types';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { ProductCard } from '../components/shop/ProductCard';

export const ProductDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();

  const [product, setProduct] = useState<Product | null>(null);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  useEffect(() => {
    if (slug) {
      const p = mockDb.getProductBySlug(slug);
      if (p) {
        setProduct(p);
        const primary = p.images.find(img => img.is_primary) || p.images[0];
        setSelectedImage(primary.image_url);

        // Default to first variant
        if (p.variants.length > 0) {
          const firstInStock = p.variants.find(v => v.available_stock > 0) || p.variants[0];
          setSelectedColor(firstInStock.color);
          setSelectedSize(firstInStock.size);
          setSelectedVariant(firstInStock);
        }
      }
    }
    window.scrollTo(0, 0);
  }, [slug]);

  // When color or size changes, update selectedVariant
  useEffect(() => {
    if (!product) return;
    const match = product.variants.find(
      v => v.color.toLowerCase() === selectedColor.toLowerCase() && v.size === selectedSize
    );
    if (match) {
      setSelectedVariant(match);
      // If color image exists, switch to it
      const colorImg = product.images.find(img => img.color?.toLowerCase() === selectedColor.toLowerCase());
      if (colorImg) {
        setSelectedImage(colorImg.image_url);
      }
    } else {
      // Find any variant with this size
      const fallback = product.variants.find(v => v.size === selectedSize) || null;
      setSelectedVariant(fallback);
    }
  }, [selectedColor, selectedSize, product]);

  if (!product) {
    return (
      <div className="py-24 text-center max-w-md mx-auto px-4 space-y-4">
        <span className="text-5xl">🕊️</span>
        <h2 className="font-editorial text-2xl text-charcoal">Silhouette Not Found</h2>
        <p className="text-xs text-mutedGrey">
          The requested couture piece may have been archived or moved to private salon viewing.
        </p>
        <Link 
          to="/shop" 
          className="inline-block px-6 py-3 bg-charcoal text-white text-xs uppercase tracking-luxury rounded-full"
        >
          Return to Catalogue
        </Link>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);
  const uniqueColors = Array.from(new Set(product.variants.map(v => v.color)));
  const availableSizes = Array.from(new Set(product.variants.map(v => v.size)));
  const relatedProducts = mockDb.getProducts({ category: product.category_id, limit: 4 }).filter(p => p.id !== product.id);

  const handleAddToCart = () => {
    if (!selectedVariant) return;
    const ok = addToCart(product, selectedVariant, quantity);
    if (ok) {
      setAddedSuccess(true);
      setTimeout(() => setAddedSuccess(false), 2000);
    }
  };

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Breadcrumb Navigation */}
      <nav className="mb-8 flex items-center gap-2 text-xs text-mutedGrey uppercase tracking-wider">
        <Link to="/" className="hover:text-charcoal transition-colors">Home</Link>
        <span>/</span>
        <Link to={`/shop?category=${product.category_id}`} className="hover:text-charcoal transition-colors">
          {product.category_name}
        </Link>
        <span>/</span>
        <span className="text-charcoal font-medium line-clamp-1">{product.title}</span>
      </nav>

      {/* Main Product Showcase Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
        
        {/* Left: Interactive Image Gallery */}
        <div className="lg:col-span-7 flex flex-col-reverse sm:flex-row gap-4">
          
          {/* Thumbnails */}
          <div className="flex sm:flex-col gap-3 overflow-x-auto sm:overflow-visible pb-2 sm:pb-0">
            {product.images.map((img) => (
              <button
                key={img.id}
                onClick={() => setSelectedImage(img.image_url)}
                className={`relative w-16 sm:w-20 aspect-[3/4] rounded-xl overflow-hidden border-2 transition-all flex-shrink-0 ${
                  selectedImage === img.image_url 
                    ? 'border-charcoal shadow-sm' 
                    : 'border-borderSoft/60 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={img.image_url} alt={product.title} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>

          {/* Main Large Image Frame */}
          <div className="flex-1 relative aspect-[3/4] rounded-3xl overflow-hidden bg-beige/30 border border-borderSoft/60 shadow-soft-luxury cursor-zoom-in group">
            <img 
              src={selectedImage} 
              alt={product.title}
              onClick={() => setIsZoomOpen(true)}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <button
              onClick={() => setIsZoomOpen(true)}
              className="absolute bottom-4 right-4 bg-white/80 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] tracking-luxury uppercase font-semibold text-charcoal shadow-sm"
            >
              Click to Zoom
            </button>
          </div>

        </div>

        {/* Right: Product Details, Variant Selection, Stock Information */}
        <div className="lg:col-span-5 space-y-6">
          
          <div>
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-luxury uppercase text-cherry-600">
                {product.category_name}
              </span>
              <span className="text-xs text-mutedGrey tracking-widest font-mono">
                SKU: {selectedVariant?.sku || 'PENDING'}
              </span>
            </div>
            
            <h1 className="font-editorial text-3xl sm:text-4xl text-charcoal mt-1 leading-tight">
              {product.title}
            </h1>

            {product.editorial_quote && (
              <p className="text-xs italic text-charcoal/70 font-serif mt-2 border-l-2 border-blush-300 pl-3">
                “{product.editorial_quote}”
              </p>
            )}

            {/* Price in INR */}
            <div className="mt-4 flex items-baseline gap-3">
              {product.sale_price_inr ? (
                <>
                  <span className="text-2xl font-bold text-cherry-600">
                    ₹{product.sale_price_inr.toLocaleString('en-IN')}
                  </span>
                  <span className="text-sm text-mutedGrey line-through font-light">
                    ₹{product.price_inr.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-cherry-50 text-cherry-600 tracking-wider uppercase">
                    Save ₹{(product.price_inr - product.sale_price_inr).toLocaleString('en-IN')}
                  </span>
                </>
              ) : (
                <span className="text-2xl font-bold text-charcoal">
                  ₹{product.price_inr.toLocaleString('en-IN')}
                </span>
              )}
            </div>
          </div>

          <p className="text-xs sm:text-sm text-charcoal/80 font-light leading-relaxed">
            {product.description}
          </p>

          {/* Color Selector */}
          <div className="space-y-2 pt-2 border-t border-borderSoft/60">
            <div className="flex justify-between items-center text-xs">
              <span className="uppercase tracking-luxury font-semibold text-charcoal">Color</span>
              <span className="text-mutedGrey">{selectedColor}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {uniqueColors.map((color) => {
                const variantForColor = product.variants.find(v => v.color === color);
                const isSelected = selectedColor.toLowerCase() === color.toLowerCase();
                return (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-2 transition-all ${
                      isSelected 
                        ? 'border-charcoal bg-charcoal text-white shadow-xs' 
                        : 'border-borderSoft bg-ivory text-charcoal hover:border-charcoal'
                    }`}
                  >
                    <span 
                      className="w-3 h-3 rounded-full border border-black/10 inline-block"
                      style={{ backgroundColor: variantForColor?.color_hex || '#ccc' }}
                    />
                    <span>{color}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Size Selector & Size Guide */}
          <div className="space-y-2 pt-2 border-t border-borderSoft/60">
            <div className="flex justify-between items-center text-xs">
              <span className="uppercase tracking-luxury font-semibold text-charcoal">Size</span>
              <button 
                onClick={() => setIsSizeGuideOpen(true)}
                className="text-mutedGrey hover:text-charcoal flex items-center gap-1 transition-colors"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span className="underline">Bespoke Size Guide</span>
              </button>
            </div>
            
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {availableSizes.map((size) => {
                const v = product.variants.find(item => item.color === selectedColor && item.size === size);
                const isOutOfStock = !v || v.available_stock <= 0;
                const isSelected = selectedSize === size;

                return (
                  <button
                    key={size}
                    disabled={isOutOfStock}
                    onClick={() => setSelectedSize(size)}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                      isSelected
                        ? 'bg-charcoal text-white border-charcoal shadow-sm'
                        : isOutOfStock
                        ? 'border-dashed border-gray-300 text-gray-300 cursor-not-allowed line-through bg-gray-50'
                        : 'bg-ivory text-charcoal border-borderSoft hover:border-charcoal'
                    }`}
                  >
                    {size}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Variant Stock Availability Indicator */}
          <div className="p-3.5 rounded-2xl bg-white/70 border border-borderSoft/60 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                !selectedVariant || selectedVariant.available_stock <= 0
                  ? 'bg-red-500'
                  : selectedVariant.available_stock <= selectedVariant.low_stock_threshold
                  ? 'bg-amber-500 animate-pulse'
                  : 'bg-emerald-500'
              }`} />
              <span className="font-medium text-charcoal">
                {!selectedVariant || selectedVariant.available_stock <= 0
                  ? 'Out of Stock in this variant'
                  : selectedVariant.available_stock <= selectedVariant.low_stock_threshold
                  ? `Low Stock — Only ${selectedVariant.available_stock} pieces remaining!`
                  : `In Stock (${selectedVariant.available_stock} pieces available)`
                }
              </span>
            </div>
            <span className="text-[10px] text-mutedGrey uppercase tracking-luxury">Live Inventory</span>
          </div>

          {/* Quantity and Actions */}
          <div className="space-y-3 pt-2">
            <div className="flex gap-3">
              {/* Add to Bag Button */}
              <button
                disabled={!selectedVariant || selectedVariant.available_stock <= 0}
                onClick={handleAddToCart}
                className="flex-1 py-4 px-6 bg-charcoal hover:bg-cherry-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white text-xs uppercase tracking-luxury font-semibold rounded-full shadow-md transition-all flex items-center justify-center gap-2"
              >
                {addedSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-blush-300" />
                    <span>Added to Shopping Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>
                      {!selectedVariant || selectedVariant.available_stock <= 0
                        ? 'Unavailable'
                        : 'Add to Bag'}
                    </span>
                  </>
                )}
              </button>

              {/* Wishlist Toggle */}
              <button
                onClick={() => toggleWishlist(product)}
                className={`p-4 rounded-full border transition-all ${
                  isWishlisted 
                    ? 'bg-cherry-600 text-white border-cherry-600 shadow-sm' 
                    : 'border-borderSoft bg-white text-charcoal hover:border-charcoal hover:text-cherry-600'
                }`}
                aria-label="Save to Wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : 'stroke-[1.5]'}`} />
              </button>
            </div>
          </div>

          {/* Value Badges */}
          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-borderSoft/60 text-[11px] text-mutedGrey text-center">
            <div className="p-2.5 rounded-xl bg-white/40 border border-borderSoft/40 space-y-1">
              <Truck className="w-4 h-4 mx-auto text-charcoal" />
              <span>Complimentary Domestic Courier</span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/40 border border-borderSoft/40 space-y-1">
              <RotateCcw className="w-4 h-4 mx-auto text-charcoal" />
              <span>7-Day Effortless Returns</span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/40 border border-borderSoft/40 space-y-1">
              <ShieldCheck className="w-4 h-4 mx-auto text-charcoal" />
              <span>100% Genuine Atelier Craft</span>
            </div>
          </div>

          {/* Fabric & Care Accordions */}
          <div className="pt-4 border-t border-borderSoft/60 space-y-3 text-xs">
            {product.fabric_details && (
              <div>
                <strong className="uppercase tracking-luxury text-charcoal block mb-0.5">Fabric & Composition</strong>
                <p className="text-mutedGrey font-light">{product.fabric_details}</p>
              </div>
            )}
            {product.care_instructions && (
              <div>
                <strong className="uppercase tracking-luxury text-charcoal block mb-0.5">Care Instructions</strong>
                <p className="text-mutedGrey font-light">{product.care_instructions}</p>
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Full Screen Image Zoom Modal */}
      {isZoomOpen && (
        <div 
          className="fixed inset-0 z-50 bg-charcoal/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setIsZoomOpen(false)}
        >
          <button 
            onClick={() => setIsZoomOpen(false)}
            className="absolute top-6 right-6 text-white p-2 rounded-full hover:bg-white/20 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <img 
            src={selectedImage} 
            alt={product.title} 
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-2xl shadow-2xl" 
          />
        </div>
      )}

      {/* Size Guide Modal */}
      {isSizeGuideOpen && (
        <div 
          className="fixed inset-0 z-50 bg-charcoal/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setIsSizeGuideOpen(false)}
        >
          <div 
            className="bg-ivory max-w-lg w-full rounded-3xl p-6 border border-borderSoft shadow-2xl space-y-4"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center pb-3 border-b border-borderSoft">
              <h3 className="font-editorial text-2xl text-charcoal">Atelier Size Dimensions</h3>
              <button onClick={() => setIsSizeGuideOpen(false)} className="p-1 text-mutedGrey hover:text-charcoal">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <p className="text-xs text-mutedGrey font-light">
              Measurements in inches. Garments cut with tailored couture fit.
            </p>

            <table className="w-full text-xs text-charcoal text-left border-collapse">
              <thead>
                <tr className="border-b border-borderSoft uppercase text-[10px] tracking-wider text-mutedGrey font-semibold">
                  <th className="py-2">Size</th>
                  <th className="py-2">Bust</th>
                  <th className="py-2">Waist</th>
                  <th className="py-2">Hips</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-borderSoft/60">
                <tr><td className="py-2 font-bold">XS</td><td>32 - 33</td><td>24 - 25</td><td>34 - 35</td></tr>
                <tr><td className="py-2 font-bold">S</td><td>34 - 35</td><td>26 - 27</td><td>36 - 37</td></tr>
                <tr><td className="py-2 font-bold">M</td><td>36 - 37</td><td>28 - 29</td><td>38 - 39</td></tr>
                <tr><td className="py-2 font-bold">L</td><td>38 - 39</td><td>30 - 31</td><td>40 - 41</td></tr>
                <tr><td className="py-2 font-bold">XL</td><td>40 - 42</td><td>32 - 34</td><td>42 - 44</td></tr>
              </tbody>
            </table>

            <button 
              onClick={() => setIsSizeGuideOpen(false)}
              className="w-full py-2.5 bg-charcoal text-white text-xs uppercase tracking-luxury font-medium rounded-xl"
            >
              Close Guide
            </button>
          </div>
        </div>
      )}

      {/* Related Silhouettes Section */}
      {relatedProducts.length > 0 && (
        <section className="mt-24 pt-16 border-t border-borderSoft">
          <div className="mb-8">
            <span className="text-[11px] font-semibold tracking-luxury uppercase text-mutedGrey">
              Coordinating Suggestions
            </span>
            <h2 className="font-editorial text-3xl text-charcoal mt-1">
              Complete The Look
            </h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((rel) => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </section>
      )}

    </div>
  );
};
